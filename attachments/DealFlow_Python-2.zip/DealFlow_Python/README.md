# DealFlow Approval Agents — Python

Two trees. Only the first one is what the live demo calls.

## runtime/

`dealflow_graph.py` is the LangGraph service the live app at
https://bird-lunar-falcon-timber.grok.me/ calls.

- GET /health
- POST /hop on port 8091
- Graph: orchestrator_plan → discount_agent ∥ payment_agent → orchestrator_combine → output_guardrail
- Rules: R1 any Reject, R2 any Escalate, R3 both Approve and confidence ≥ threshold, R4 both Approve but under threshold, G-OUT no citation or a note that tries to force Approve
- Dependencies: langgraph==0.4.8, pydantic==2.11.7

The commercial book (ceilings, history, dues) is scored before this graph is called. The graph owns the hop: one cited label, or a hold.

```
python dealflow_graph.py
```

## dealflow_agents/

The earlier multi-file crew. Not what the live demo calls.

- agents/discount_agent.py — discount matrix by segment and quote type
- agents/payment_terms_agent.py — preferred / elevated / high-risk terms
- agents/orchestrator.py — stricter label, threshold, assignment
- models.py — Quote and decision contracts
- data/quotes.py — sample quotes
- policies/ — DISC and PAY books plus the company pack
- app.py — Streamlit demo
- test_agents.py — smoke checks

```
pip install -r requirements.txt
streamlit run app.py
```
