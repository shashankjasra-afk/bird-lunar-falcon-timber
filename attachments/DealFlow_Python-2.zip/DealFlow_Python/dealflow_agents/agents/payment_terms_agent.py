"""
DealFlow Agents - Payment Terms & Billing Agent
Loads the official Payment Terms & Billing Policy Book and evaluates quotes against it.
"""

import json
from pathlib import Path
from models import Quote, AgentDecision


POLICY_PATH = Path(__file__).parent.parent / "policies" / "payment_terms_policy.json"


class PaymentTermsBillingAgent:
    name = "Payment Terms & Billing Agent"

    def __init__(self):
        with open(POLICY_PATH, "r", encoding="utf-8") as f:
            self.policy = json.load(f)

    def review(self, quote: Quote) -> AgentDecision:
        terms = quote.payment_terms
        billing = quote.billing_frequency
        reasoning = []
        flags = []
        cited_rules = []
        confidence = 90

        # 1. Load policy
        reasoning.append(
            f"Loaded policy '{self.policy['policy_name']}' (v{self.policy['version']})."
        )
        cited_rules.append(self.policy["policy_id"])

        # 2. Evaluate payment terms
        pt = self.policy["payment_terms"]
        if terms in pt["preferred"]["values"]:
            reasoning.append(f"Payment terms '{terms}' are in the Preferred category (Low risk).")
            cited_rules.append("Preferred payment terms")
        elif terms in pt["acceptable"]["values"]:
            reasoning.append(f"Payment terms '{terms}' are Acceptable (Medium-Low risk). Soft flag only.")
            flags.append(f"Non-preferred payment terms ({terms})")
            cited_rules.append("Acceptable payment terms (Net-45)")
            confidence -= 8
        elif terms in pt["elevated"]["values"]:
            reasoning.append(f"Payment terms '{terms}' are Elevated risk. Increases DSO.")
            flags.append(f"Elevated payment terms ({terms})")
            cited_rules.append("Elevated payment terms (Net-60)")
            confidence -= 22
        else:
            reasoning.append(f"Payment terms '{terms}' are High-Risk and generally outside policy.")
            flags.append(f"High-risk payment terms ({terms})")
            cited_rules.append("High-risk payment terms (Net-90)")
            confidence -= 40

        # 3. Evaluate billing frequency
        bf = self.policy["billing_frequency"]
        if billing in bf["preferred"]["values"]:
            reasoning.append(f"Billing frequency '{billing}' is Preferred (supports healthy cash flow).")
            if billing == "Multi-Year Prepay":
                reasoning.append("Multi-Year Prepay is strongly positive for cash and retention.")
                confidence = min(97, confidence + 6)
            cited_rules.append("Preferred billing frequency")
        elif billing in bf["acceptable"]["values"]:
            reasoning.append(f"Billing frequency '{billing}' is Acceptable.")
            confidence -= 5
        else:
            reasoning.append(f"Billing frequency '{billing}' is High-Risk (higher overhead + delayed cash).")
            flags.append(f"High-risk billing frequency ({billing})")
            cited_rules.append("High-risk billing (Monthly)")
            confidence -= 20

        # 4. Change rules (renewals)
        if quote.historical:
            prev_terms = quote.historical.previous_payment_terms
            if prev_terms and prev_terms != terms:
                reasoning.append(f"Payment terms changing from {prev_terms} → {terms}.")
                if self._is_worse(prev_terms, terms):
                    flags.append("Worsening of payment terms vs previous contract")
                    cited_rules.append("Change Rule CR-01: Worsening on renewal (mandatory escalate)")
                    confidence -= 18
                    reasoning.append(
                        "Change Rule CR-01 triggered: any renewal that moves to longer payment terms "
                        "must be escalated."
                    )

        # 5. High value + high risk
        net_value = quote.total_net_value
        if net_value > 200000 and terms in self.policy["payment_terms"]["high_risk"]["values"]:
            flags.append("High value + high-risk terms")
            cited_rules.append("Change Rule CR-03: High value + high risk terms")
            confidence -= 12
            reasoning.append(
                "Change Rule CR-03: deals > $200k with Net-90 require VP-level review."
            )

        # 6. Decision
        confidence = max(5, min(97, confidence))
        high_risk_count = sum(1 for f in flags if "High-risk" in f or "Worsening" in f)

        if high_risk_count >= 2 or (
            terms in self.policy["payment_terms"]["high_risk"]["values"]
            and billing in self.policy["billing_frequency"]["high_risk"]["values"]
        ):
            decision = "Reject"
            comments = (
                f"Reject. Combination of {terms} and {billing} creates unacceptable cash-flow risk "
                f"per {self.policy['policy_id']}. Requires VP Finance exception."
            )
        elif flags and confidence < 70:
            decision = "Escalate"
            comments = (
                f"Escalate. Payment terms ({terms}) and/or billing ({billing}) deviate from preferred "
                f"standards or worsen prior contract terms. Cited rules: {', '.join(cited_rules[:3])}."
            )
        elif flags:
            decision = "Escalate"
            comments = (
                f"Escalate. Terms are not a hard violation but carry risk flags that require "
                f"Deal Desk review per {self.policy['policy_id']}."
            )
        else:
            decision = "Approve"
            comments = (
                f"Approve. Payment terms ({terms}) and billing frequency ({billing}) are within "
                f"preferred or acceptable standards defined in {self.policy['policy_id']}."
            )
            confidence = max(confidence, 85)

        reasoning.append("Policy citations: " + " | ".join(cited_rules))

        return AgentDecision(
            agent_name=self.name,
            decision=decision,
            confidence=confidence,
            reasoning=reasoning,
            comments=comments,
            flags=flags
        )

    def _is_worse(self, previous: str, current: str) -> bool:
        order = ["Due on Receipt", "Net-30", "Net-45", "Net-60", "Net-90"]
        try:
            return order.index(current) > order.index(previous)
        except ValueError:
            return True
