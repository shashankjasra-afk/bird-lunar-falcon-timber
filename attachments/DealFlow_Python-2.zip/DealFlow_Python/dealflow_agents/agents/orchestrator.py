"""
DealFlow Agents - Orchestrator / Deal Desk Agent
Routes quote to specialist agents, aggregates results, applies final decision logic.
"""

from models import Quote, AgentDecision, FinalDecision
from agents.discount_agent import DiscountPricingAgent
from agents.payment_terms_agent import PaymentTermsBillingAgent


class Orchestrator:
    name = "Orchestrator / Deal Desk Agent"

    def __init__(self, confidence_threshold: int = 75):
        self.discount_agent = DiscountPricingAgent()
        self.payment_agent = PaymentTermsBillingAgent()
        self.confidence_threshold = confidence_threshold

    def process(self, quote: Quote) -> FinalDecision:
        audit = []
        audit.append(f"[{self.name}] Received quote {quote.quote_id} ({quote.quote_type}) for {quote.account.name}")
        audit.append(f"[{self.name}] Routing to specialist agents in parallel...")

        # Run specialists (conceptually parallel)
        discount_result = self.discount_agent.review(quote)
        audit.append(
            f"[{discount_result.agent_name}] → {discount_result.decision} "
            f"(confidence {discount_result.confidence}%)"
        )

        payment_result = self.payment_agent.review(quote)
        audit.append(
            f"[{payment_result.agent_name}] → {payment_result.decision} "
            f"(confidence {payment_result.confidence}%)"
        )

        specialist_decisions = [discount_result, payment_result]

        # Aggregation logic
        decisions = [d.decision for d in specialist_decisions]
        confidences = [d.confidence for d in specialist_decisions]
        all_flags = []
        for d in specialist_decisions:
            all_flags.extend(d.flags)

        # Final decision rules (strict and transparent)
        if "Reject" in decisions:
            overall_decision = "Reject"
            overall_confidence = min(confidences)
            reason_summary = "One or more specialist agents recommended Reject."
        elif "Escalate" in decisions:
            overall_decision = "Escalate"
            overall_confidence = min(confidences)
            reason_summary = "One or more specialist agents recommended Escalate."
        else:
            # All Approve — still check confidence threshold
            avg_conf = sum(confidences) // len(confidences)
            if avg_conf >= self.confidence_threshold:
                overall_decision = "Approve"
                overall_confidence = avg_conf
                reason_summary = "All specialist agents approved with sufficient confidence."
            else:
                overall_decision = "Escalate"
                overall_confidence = avg_conf
                reason_summary = (
                    f"Specialists approved but average confidence ({avg_conf}%) "
                    f"is below threshold ({self.confidence_threshold}%)."
                )

        # Consolidated reasoning
        consolidated = [reason_summary]
        for d in specialist_decisions:
            consolidated.append(f"{d.agent_name}: {d.comments}")

        # Recommended actions
        actions = []
        if overall_decision == "Approve":
            actions.append("Proceed to generate order form / send for e-signature.")
            actions.append("Notify seller of approval.")
        elif overall_decision == "Escalate":
            actions.append("Route to human Deal Desk / Sales Ops for review.")
            actions.append("Include full agent reasoning and flags in the escalation ticket.")
            if all_flags:
                actions.append(f"Key flags to review: {', '.join(all_flags[:4])}")
        else:  # Reject
            actions.append("Return to seller with clear rejection reasons.")
            actions.append("Suggest revised commercial terms that would meet policy.")
            if all_flags:
                actions.append(f"Primary issues: {', '.join(all_flags[:3])}")

        # Final comments
        final_comments = (
            f"Overall recommendation: {overall_decision} "
            f"(confidence {overall_confidence}%). {reason_summary}"
        )

        audit.append(f"[{self.name}] Final decision: {overall_decision} (confidence {overall_confidence}%)")
        audit.append(f"[{self.name}] Processing complete for {quote.quote_id}")

        return FinalDecision(
            quote_id=quote.quote_id,
            overall_decision=overall_decision,
            overall_confidence=overall_confidence,
            specialist_decisions=specialist_decisions,
            consolidated_reasoning=consolidated,
            final_comments=final_comments,
            audit_trail=audit,
            recommended_actions=actions
        )
