"""
DealFlow Agents - Discount & Pricing Agent
Loads the official Discount Policy Book and evaluates quotes against real policy rules.
"""

import json
from pathlib import Path
from models import Quote, AgentDecision


POLICY_PATH = Path(__file__).parent.parent / "policies" / "discount_policy.json"


class DiscountPricingAgent:
    name = "Discount & Pricing Agent"

    def __init__(self):
        with open(POLICY_PATH, "r", encoding="utf-8") as f:
            self.policy = json.load(f)

    def review(self, quote: Quote) -> AgentDecision:
        overall_discount = quote.overall_discount_pct
        segment = quote.account.segment
        qtype = quote.quote_type.lower().replace("-", "").replace(" ", "")
        if qtype == "addon":
            qtype_key = "addon"
        elif qtype == "expansion":
            qtype_key = "expansion"
        elif qtype == "renewal":
            qtype_key = "renewal"
        else:
            qtype_key = "new_business"

        reasoning = []
        flags = []
        cited_rules = []
        confidence = 88

        # 1. Load applicable policy section
        segment_policy = self.policy["segments"].get(segment, self.policy["segments"]["Enterprise"])
        type_policy = segment_policy.get(qtype_key, segment_policy.get("new_business", {}))

        max_standard = type_policy.get("max_standard_discount_pct", 20)
        max_exception = type_policy.get("max_with_exception_pct", max_standard + 7)
        max_increase_vs_prev = type_policy.get("max_increase_vs_previous_pct", 5)

        reasoning.append(
            f"Loaded policy '{self.policy['policy_name']}' (v{self.policy['version']}). "
            f"Applying {segment} / {quote.quote_type} rules."
        )
        reasoning.append(
            f"Policy max standard discount: {max_standard}% | "
            f"Max with exception: {max_exception}%."
        )
        cited_rules.append(f"{self.policy['policy_id']} → {segment}.{qtype_key}")

        # 2. Compare against standard & exception limits
        if overall_discount <= max_standard:
            reasoning.append(
                f"Proposed discount {overall_discount}% is within the standard policy limit of {max_standard}%."
            )
            cited_rules.append(f"Within standard limit ({max_standard}%)")
        elif overall_discount <= max_exception:
            delta = round(overall_discount - max_standard, 1)
            reasoning.append(
                f"Proposed discount {overall_discount}% exceeds standard limit by {delta} pts "
                f"but is still under the exception ceiling of {max_exception}%."
            )
            flags.append(f"Above standard discount (by {delta} pts)")
            cited_rules.append(f"Between standard ({max_standard}%) and exception ({max_exception}%)")
            confidence -= 18
        else:
            delta = round(overall_discount - max_exception, 1)
            reasoning.append(
                f"Proposed discount {overall_discount}% exceeds the maximum exception limit "
                f"of {max_exception}% by {delta} pts."
            )
            flags.append("Exceeds maximum exception discount")
            cited_rules.append(f"Above exception ceiling ({max_exception}%)")
            confidence -= 45

        # 3. Historical comparison
        if quote.historical and quote.historical.previous_discount_pct is not None:
            prev = quote.historical.previous_discount_pct
            jump = round(overall_discount - prev, 1)
            reasoning.append(f"Previous contract discount was {prev}%. Current request is {jump:+} pts vs history.")

            if jump > max_increase_vs_prev:
                flags.append(f"Discount jump vs history exceeds policy ({jump} pts > {max_increase_vs_prev} pts)")
                cited_rules.append(f"Special Rule SR-02: Large jump vs historical (limit {max_increase_vs_prev} pts)")
                confidence -= 15
                reasoning.append(
                    f"Policy Special Rule SR-02 triggered: increase of more than {max_increase_vs_prev} pts "
                    f"versus previous contract requires Deal Desk review."
                )
            elif jump > 3:
                flags.append("Notable increase vs historical discount")
                confidence -= 8

        # 4. Volume tier check
        net_value = quote.total_net_value
        volume_tiers = type_policy.get("volume_tiers", [])
        if volume_tiers:
            applicable_tier = None
            for tier in volume_tiers:
                if tier["min_acv"] <= net_value < tier["max_acv"]:
                    applicable_tier = tier
                    break
            if applicable_tier:
                tier_max = applicable_tier["max_discount_pct"]
                reasoning.append(
                    f"Deal net value ${net_value:,.0f} falls into volume tier "
                    f"with max discount {tier_max}%."
                )
                if overall_discount > tier_max + 3:
                    flags.append(f"Above volume-tier maximum ({tier_max}%)")
                    confidence -= 12

        # 5. Special rules
        if net_value < 50000 and overall_discount > 25:
            flags.append("High discount on small deal (< $50k)")
            cited_rules.append("Special Rule SR-03: Small deal high discount")
            confidence -= 15
            reasoning.append(
                "Special Rule SR-03 triggered: deals under $50k requesting >25% discount are escalated by default."
            )

        if any(x in quote.submission_date for x in ["-28", "-29", "-30", "-31"]) or "-09-" in quote.submission_date:
            if overall_discount >= max_standard - 2:
                flags.append("Near period-end with elevated discount")
                cited_rules.append("Special Rule SR-01: Quarter-end elevated scrutiny")
                confidence -= 10
                reasoning.append(
                    "Special Rule SR-01: submission near period close combined with elevated discount "
                    "triggers additional scrutiny."
                )

        # 6. Decision
        confidence = max(5, min(97, confidence))

        if "Exceeds maximum exception discount" in flags:
            decision = "Reject"
            comments = (
                f"Reject. Discount of {overall_discount}% exceeds the maximum exception limit "
                f"of {max_exception}% defined in {self.policy['policy_id']} for {segment} {quote.quote_type} deals. "
                f"Requires VP-level exception."
            )
        elif flags and confidence < 68:
            decision = "Escalate"
            comments = (
                f"Escalate to Deal Desk. Discount of {overall_discount}% is above the standard "
                f"{max_standard}% limit and/or triggers policy special rules. "
                f"Cited: {', '.join(cited_rules[:3])}."
            )
        elif flags:
            decision = "Escalate"
            comments = (
                f"Escalate. While not a hard policy violation, the discount profile carries risk flags "
                f"that require human review per {self.policy['policy_id']}."
            )
        else:
            decision = "Approve"
            comments = (
                f"Approve. Proposed discount of {overall_discount}% is within the standard policy limit "
                f"of {max_standard}% for {segment} {quote.quote_type} deals "
                f"({self.policy['policy_id']})."
            )
            confidence = max(confidence, 84)

        reasoning.append("Policy citations: " + " | ".join(cited_rules))

        return AgentDecision(
            agent_name=self.name,
            decision=decision,
            confidence=confidence,
            reasoning=reasoning,
            comments=comments,
            flags=flags
        )
