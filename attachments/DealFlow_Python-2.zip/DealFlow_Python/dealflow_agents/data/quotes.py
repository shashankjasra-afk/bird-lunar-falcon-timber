"""
DealFlow Agents - Sample Quotes (Golden Set)
Realistic Salesforce-style subscription, renewal, and add-on quotes.
"""

from models import Quote, LineItem, Account, Seller, Historical

SAMPLE_QUOTES = [
    # ------------------------------------------------------------------
    # 1. Clean Renewal - should AUTO-APPROVE (high confidence)
    # ------------------------------------------------------------------
    Quote(
        quote_id="Q-2026-1001",
        quote_type="Renewal",
        account=Account(
            name="Acme Manufacturing",
            segment="Enterprise",
            region="North America",
            existing_acv=185000
        ),
        seller=Seller(id="S-1102", name="Jordan Lee"),
        submission_date="2026-10-10",
        contract_length_months=12,
        payment_terms="Net-30",
        billing_frequency="Annual",
        line_items=[
            LineItem(
                product="Sales Cloud - Enterprise Edition",
                quantity=120,
                list_price=1650,
                proposed_discount_pct=18,
                net_price=1353
            ),
            LineItem(
                product="Sales Cloud - Einstein AI Add-on",
                quantity=120,
                list_price=50,
                proposed_discount_pct=10,
                net_price=45
            )
        ],
        historical=Historical(
            previous_discount_pct=17,
            previous_payment_terms="Net-30",
            previous_billing_frequency="Annual"
        ),
        notes="Standard annual renewal. Slight discount increase requested due to volume growth."
    ),

    # ------------------------------------------------------------------
    # 2. Aggressive Expansion Discount - should ESCALATE or REJECT
    # ------------------------------------------------------------------
    Quote(
        quote_id="Q-2026-1002",
        quote_type="Expansion",
        account=Account(
            name="Globex Corporation",
            segment="Enterprise",
            region="North America",
            existing_acv=420000
        ),
        seller=Seller(id="S-2208", name="Priya Patel"),
        submission_date="2026-10-14",
        contract_length_months=12,
        payment_terms="Net-30",
        billing_frequency="Annual",
        line_items=[
            LineItem(
                product="Service Cloud - Unlimited",
                quantity=200,
                list_price=300,
                proposed_discount_pct=42,
                net_price=174
            ),
            LineItem(
                product="Field Service Lightning",
                quantity=80,
                list_price=150,
                proposed_discount_pct=38,
                net_price=93
            )
        ],
        historical=Historical(
            previous_discount_pct=22,
            previous_payment_terms="Net-30"
        ),
        notes="Large expansion. Seller requesting deep discount to win competitive displacement."
    ),

    # ------------------------------------------------------------------
    # 3. Worsened Payment Terms on Renewal - should ESCALATE
    # ------------------------------------------------------------------
    Quote(
        quote_id="Q-2026-1003",
        quote_type="Renewal",
        account=Account(
            name="Initech Solutions",
            segment="Mid-Market",
            region="EMEA",
            existing_acv=96000
        ),
        seller=Seller(id="S-3315", name="Marcus Chen"),
        submission_date="2026-10-12",
        contract_length_months=24,
        payment_terms="Net-90",
        billing_frequency="Annual",
        line_items=[
            LineItem(
                product="Sales Cloud - Professional",
                quantity=45,
                list_price=100,
                proposed_discount_pct=15,
                net_price=85
            ),
            LineItem(
                product="Platform - Force.com",
                quantity=45,
                list_price=25,
                proposed_discount_pct=10,
                net_price=22.5
            )
        ],
        historical=Historical(
            previous_discount_pct=12,
            previous_payment_terms="Net-30",
            previous_billing_frequency="Annual"
        ),
        notes="Customer requesting Net-90 and 24-month term. Discount remains reasonable."
    ),

    # ------------------------------------------------------------------
    # 4. Clean New Business - should APPROVE
    # ------------------------------------------------------------------
    Quote(
        quote_id="Q-2026-1004",
        quote_type="New",
        account=Account(
            name="Stark Industries",
            segment="Enterprise",
            region="North America",
            existing_acv=None
        ),
        seller=Seller(id="S-1102", name="Jordan Lee"),
        submission_date="2026-10-08",
        contract_length_months=12,
        payment_terms="Net-30",
        billing_frequency="Annual",
        line_items=[
            LineItem(
                product="Sales Cloud - Enterprise Edition",
                quantity=250,
                list_price=1650,
                proposed_discount_pct=22,
                net_price=1287
            ),
            LineItem(
                product="Tableau CRM",
                quantity=50,
                list_price=70,
                proposed_discount_pct=15,
                net_price=59.5
            )
        ],
        historical=None,
        notes="New logo. Competitive situation but discount within enterprise guidelines."
    ),

    # ------------------------------------------------------------------
    # 5. Borderline Add-on with elevated discount - ESCALATE
    # ------------------------------------------------------------------
    Quote(
        quote_id="Q-2026-1005",
        quote_type="Add-on",
        account=Account(
            name="Wayne Enterprises",
            segment="Enterprise",
            region="North America",
            existing_acv=610000
        ),
        seller=Seller(id="S-4419", name="Sam Rivera"),
        submission_date="2026-10-15",
        contract_length_months=12,
        payment_terms="Net-45",
        billing_frequency="Annual",
        line_items=[
            LineItem(
                product="Marketing Cloud - Engagement",
                quantity=100,
                list_price=1250,
                proposed_discount_pct=32,
                net_price=850
            )
        ],
        historical=Historical(
            previous_discount_pct=20,
            previous_payment_terms="Net-30"
        ),
        notes="Add-on to existing large account. Discount higher than historical but within max for add-ons."
    ),

    # ------------------------------------------------------------------
    # 6. Clear Reject - Extreme discount + poor terms
    # ------------------------------------------------------------------
    Quote(
        quote_id="Q-2026-1006",
        quote_type="New",
        account=Account(
            name="Oscorp",
            segment="Mid-Market",
            region="North America",
            existing_acv=None
        ),
        seller=Seller(id="S-5521", name="Alex Kim"),
        submission_date="2026-10-16",
        contract_length_months=12,
        payment_terms="Net-90",
        billing_frequency="Monthly",
        line_items=[
            LineItem(
                product="Sales Cloud - Enterprise Edition",
                quantity=30,
                list_price=1650,
                proposed_discount_pct=48,
                net_price=858
            )
        ],
        historical=None,
        notes="Small deal size with extremely aggressive discount and unfavorable billing/payment terms."
    ),

    # ------------------------------------------------------------------
    # 7. Multi-year prepay renewal - strong Approve
    # ------------------------------------------------------------------
    Quote(
        quote_id="Q-2026-1007",
        quote_type="Renewal",
        account=Account(
            name="Umbrella Corp",
            segment="Enterprise",
            region="APAC",
            existing_acv=275000
        ),
        seller=Seller(id="S-2208", name="Priya Patel"),
        submission_date="2026-10-09",
        contract_length_months=36,
        payment_terms="Net-30",
        billing_frequency="Multi-Year Prepay",
        line_items=[
            LineItem(
                product="Sales Cloud - Unlimited",
                quantity=180,
                list_price=300,
                proposed_discount_pct=25,
                net_price=225
            ),
            LineItem(
                product="Service Cloud - Unlimited",
                quantity=180,
                list_price=300,
                proposed_discount_pct=25,
                net_price=225
            )
        ],
        historical=Historical(
            previous_discount_pct=20,
            previous_payment_terms="Net-30",
            previous_billing_frequency="Annual"
        ),
        notes="Customer willing to prepay 3 years. Discount increase justified by multi-year commitment and cash benefit."
    ),

    # ------------------------------------------------------------------
    # 8. Quarter-end style aggressive ask (gaming signal)
    # ------------------------------------------------------------------
    Quote(
        quote_id="Q-2026-1008",
        quote_type="Expansion",
        account=Account(
            name="Cyberdyne Systems",
            segment="Enterprise",
            region="North America",
            existing_acv=890000
        ),
        seller=Seller(id="S-1102", name="Jordan Lee"),
        submission_date="2026-09-28",  # near quarter end
        contract_length_months=12,
        payment_terms="Net-60",
        billing_frequency="Annual",
        line_items=[
            LineItem(
                product="Sales Cloud - Enterprise Edition",
                quantity=300,
                list_price=1650,
                proposed_discount_pct=35,
                net_price=1072.5
            )
        ],
        historical=Historical(
            previous_discount_pct=19,
            previous_payment_terms="Net-30"
        ),
        notes="Submitted near quarter close. Significant discount jump and payment term change."
    ),
]


def get_quote_by_id(quote_id: str) -> Quote | None:
    for q in SAMPLE_QUOTES:
        if q.quote_id == quote_id:
            return q
    return None


def get_all_quotes() -> list[Quote]:
    return SAMPLE_QUOTES
