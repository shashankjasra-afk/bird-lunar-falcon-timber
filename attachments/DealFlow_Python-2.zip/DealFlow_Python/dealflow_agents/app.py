"""
DealFlow Agents - Streamlit Demo UI
Multi-Agent CPQ Approval System for SaaS Subscription Quotes
"""

import streamlit as st
from models import Quote
from data.quotes import get_all_quotes, get_quote_by_id
from agents.orchestrator import Orchestrator

# Page config
st.set_page_config(
    page_title="DealFlow Agents",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        color: #1F4E79;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.1rem;
        color: #5B5B5B;
        margin-bottom: 1.5rem;
    }
    .decision-approve {
        background-color: #E2EFDA;
        border-left: 6px solid #548235;
        padding: 1rem 1.2rem;
        border-radius: 6px;
        margin: 0.8rem 0;
    }
    .decision-escalate {
        background-color: #FFF2CC;
        border-left: 6px solid #BF8F00;
        padding: 1rem 1.2rem;
        border-radius: 6px;
        margin: 0.8rem 0;
    }
    .decision-reject {
        background-color: #FCE4D6;
        border-left: 6px solid #C65911;
        padding: 1rem 1.2rem;
        border-radius: 6px;
        margin: 0.8rem 0;
    }
    .agent-card {
        background-color: #F8F9FA;
        border: 1px solid #DEE2E6;
        border-radius: 8px;
        padding: 1rem;
        margin-bottom: 0.8rem;
    }
    .metric-label {
        font-size: 0.85rem;
        color: #666;
    }
    .stButton>button {
        width: 100%;
    }
</style>
""", unsafe_allow_html=True)


def decision_badge(decision: str) -> str:
    colors = {
        "Approve": ("#548235", "#E2EFDA"),
        "Escalate": ("#BF8F00", "#FFF2CC"),
        "Reject": ("#C65911", "#FCE4D6")
    }
    fg, bg = colors.get(decision, ("#333", "#EEE"))
    return f"""<span style="background-color:{bg}; color:{fg}; padding:4px 12px; 
                border-radius:12px; font-weight:600; font-size:0.95rem;">{decision}</span>"""


def render_agent_result(agent_decision):
    st.markdown(f"### {agent_decision.agent_name}")
    col1, col2 = st.columns([1, 1])
    with col1:
        st.markdown(f"**Decision:** {decision_badge(agent_decision.decision)}", unsafe_allow_html=True)
    with col2:
        st.metric("Confidence", f"{agent_decision.confidence}%")

    st.markdown(f"**Comments:** {agent_decision.comments}")

    with st.expander("View detailed reasoning"):
        for r in agent_decision.reasoning:
            st.markdown(f"- {r}")
        if agent_decision.flags:
            st.markdown("**Flags raised:**")
            for f in agent_decision.flags:
                st.markdown(f"- 🚩 {f}")


def main():
    st.markdown('<p class="main-header">⚡ DealFlow Agents</p>', unsafe_allow_html=True)
    st.markdown(
        '<p class="sub-header">Multi-Agent CPQ Approval System for SaaS Subscription & Renewal Quotes</p>',
        unsafe_allow_html=True
    )

    # Sidebar
    with st.sidebar:
        st.header("Controls")
        confidence_threshold = st.slider(
            "Confidence Threshold for Auto-Approve",
            min_value=50,
            max_value=95,
            value=75,
            step=5,
            help="If all agents approve but average confidence is below this value, the quote is escalated."
        )
        st.markdown("---")
        st.markdown("**How it works**")
        st.markdown("""
        1. Select a quote  
        2. Two specialist agents review in parallel  
        3. Orchestrator aggregates & decides  
        4. Full audit trail provided
        """)
        st.markdown("---")
        st.caption("Capstone Demo • Salesforce-style CPQ")

    # Quote selection
    quotes = get_all_quotes()
    quote_options = {
        f"{q.quote_id} | {q.quote_type} | {q.account.name} | {q.overall_discount_pct}% disc": q.quote_id
        for q in quotes
    }

    selected_label = st.selectbox("Select a Quote to Review", options=list(quote_options.keys()))
    selected_id = quote_options[selected_label]
    quote = get_quote_by_id(selected_id)

    if not quote:
        st.error("Quote not found.")
        return

    # Quote summary
    st.subheader("Quote Summary")
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Type", quote.quote_type)
    c2.metric("Segment", quote.account.segment)
    c3.metric("Net Value", f"${quote.total_net_value:,.0f}")
    c4.metric("Overall Discount", f"{quote.overall_discount_pct}%")
    c5.metric("Payment Terms", quote.payment_terms)

    with st.expander("Full Quote Details", expanded=False):
        col_a, col_b = st.columns(2)
        with col_a:
            st.markdown(f"**Account:** {quote.account.name}")
            st.markdown(f"**Region:** {quote.account.region}")
            st.markdown(f"**Seller:** {quote.seller.name}")
            st.markdown(f"**Submission Date:** {quote.submission_date}")
            st.markdown(f"**Contract Length:** {quote.contract_length_months} months")
            st.markdown(f"**Billing Frequency:** {quote.billing_frequency}")
            if quote.account.existing_acv:
                st.markdown(f"**Existing ACV:** ${quote.account.existing_acv:,.0f}")
        with col_b:
            if quote.historical:
                st.markdown("**Historical**")
                st.markdown(f"- Previous Discount: {quote.historical.previous_discount_pct}%")
                st.markdown(f"- Previous Terms: {quote.historical.previous_payment_terms}")
                if quote.historical.previous_billing_frequency:
                    st.markdown(f"- Previous Billing: {quote.historical.previous_billing_frequency}")
            if quote.notes:
                st.markdown(f"**Notes:** {quote.notes}")

        st.markdown("**Line Items**")
        for item in quote.line_items:
            st.markdown(
                f"- {item.product} × {item.quantity} | "
                f"List ${item.list_price:,.0f} → Net ${item.net_price:,.0f} "
                f"({item.proposed_discount_pct}% off)"
            )

    st.markdown("---")

    # Run button
    if st.button("▶ Run Multi-Agent Review", type="primary"):
        with st.spinner("Agents reviewing quote in parallel..."):
            orchestrator = Orchestrator(confidence_threshold=confidence_threshold)
            result = orchestrator.process(quote)

        # Final Decision Banner
        st.subheader("Final Decision")
        decision_class = {
            "Approve": "decision-approve",
            "Escalate": "decision-escalate",
            "Reject": "decision-reject"
        }.get(result.overall_decision, "")

        st.markdown(f"""
        <div class="{decision_class}">
            <h2 style="margin:0 0 0.4rem 0;">{result.overall_decision}</h2>
            <p style="margin:0; font-size:1.05rem;">
                Overall Confidence: <strong>{result.overall_confidence}%</strong><br>
                {result.final_comments}
            </p>
        </div>
        """, unsafe_allow_html=True)

        # Specialist Agents side-by-side
        st.subheader("Specialist Agent Results")
        col1, col2 = st.columns(2)
        with col1:
            render_agent_result(result.specialist_decisions[0])
        with col2:
            render_agent_result(result.specialist_decisions[1])

        # Recommended Actions
        st.subheader("Recommended Next Actions")
        for action in result.recommended_actions:
            st.markdown(f"- {action}")

        # Audit Trail
        with st.expander("Full Audit Trail"):
            for entry in result.audit_trail:
                st.text(entry)

        # Consolidated Reasoning
        with st.expander("Consolidated Reasoning"):
            for r in result.consolidated_reasoning:
                st.markdown(f"- {r}")


if __name__ == "__main__":
    main()
