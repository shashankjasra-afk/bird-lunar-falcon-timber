"""
DealFlow Agents - Data Models
Pydantic schemas for quotes, agent decisions, and final results.
"""

from typing import List, Optional, Literal
from pydantic import BaseModel, Field
from datetime import date


class LineItem(BaseModel):
    product: str
    quantity: int
    list_price: float
    proposed_discount_pct: float
    net_price: float


class Account(BaseModel):
    name: str
    segment: Literal["Enterprise", "Mid-Market", "SMB"]
    region: str
    existing_acv: Optional[float] = None


class Seller(BaseModel):
    id: str
    name: str


class Historical(BaseModel):
    previous_discount_pct: Optional[float] = None
    previous_payment_terms: Optional[str] = None
    previous_billing_frequency: Optional[str] = None


class Quote(BaseModel):
    quote_id: str
    quote_type: Literal["New", "Renewal", "Add-on", "Expansion"]
    account: Account
    seller: Seller
    submission_date: str
    contract_length_months: int
    payment_terms: Literal["Net-30", "Net-45", "Net-60", "Net-90", "Due on Receipt"]
    billing_frequency: Literal["Monthly", "Quarterly", "Annual", "Multi-Year Prepay"]
    line_items: List[LineItem]
    historical: Optional[Historical] = None
    notes: Optional[str] = None

    @property
    def total_list_value(self) -> float:
        return sum(item.list_price * item.quantity for item in self.line_items)

    @property
    def total_net_value(self) -> float:
        return sum(item.net_price * item.quantity for item in self.line_items)

    @property
    def overall_discount_pct(self) -> float:
        if self.total_list_value == 0:
            return 0.0
        return round((1 - self.total_net_value / self.total_list_value) * 100, 1)


class AgentDecision(BaseModel):
    agent_name: str
    decision: Literal["Approve", "Escalate", "Reject"]
    confidence: int = Field(ge=0, le=100, description="Confidence score 0-100")
    reasoning: List[str] = Field(description="Key factors that drove the decision")
    comments: str = Field(description="Human-readable summary comment")
    flags: List[str] = Field(default_factory=list, description="Risk or policy flags")


class FinalDecision(BaseModel):
    quote_id: str
    overall_decision: Literal["Approve", "Escalate", "Reject"]
    overall_confidence: int
    specialist_decisions: List[AgentDecision]
    consolidated_reasoning: List[str]
    final_comments: str
    audit_trail: List[str]
    recommended_actions: List[str] = Field(default_factory=list)
