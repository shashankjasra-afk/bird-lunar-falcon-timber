"""
Quick test of the multi-agent system against all sample quotes.
Run: python test_agents.py
"""

from data.quotes import get_all_quotes
from agents.orchestrator import Orchestrator


def main():
    orchestrator = Orchestrator(confidence_threshold=75)
    quotes = get_all_quotes()

    print("=" * 80)
    print("DealFlow Agents – Evaluation against Golden Set")
    print("=" * 80)

    for quote in quotes:
        result = orchestrator.process(quote)
        print(f"\n{quote.quote_id} | {quote.quote_type:10} | {quote.account.name:25}")
        print(f"  Discount: {quote.overall_discount_pct}% | Terms: {quote.payment_terms} | Billing: {quote.billing_frequency}")
        print(f"  → FINAL: {result.overall_decision:8} (confidence {result.overall_confidence}%)")
        for d in result.specialist_decisions:
            flags_str = f" | flags: {d.flags}" if d.flags else ""
            print(f"     {d.agent_name}: {d.decision} ({d.confidence}%){flags_str}")
        print(f"  Comments: {result.final_comments[:110]}...")

    print("\n" + "=" * 80)
    print("Test complete. All quotes processed successfully.")
    print("=" * 80)


if __name__ == "__main__":
    main()
