# DealFlow Agents

**Multi-Agent CPQ Approval System for SaaS Subscription & Renewal Quotes**

Capstone-ready demo of an agentic AI system that automates routine approvals in the Salesforce-style CPQ process.

## What it does

Instead of quotes waiting in Sales Ops / RevOps / Deal Desk queues, three specialized agents review the quote in parallel and decide to **Approve**, **Escalate**, or **Reject** — with confidence scores, clear reasoning, and a full audit trail.

### Agent Team

| Agent | Responsibility |
|-------|----------------|
| **Discount & Pricing Agent** | Discount levels, list-to-net, volume, renewal vs new-business norms, historical comparison, soft gaming signals |
| **Payment Terms & Billing Agent** | Payment terms (Net-30/60/90), billing frequency, multi-year prepay, changes from prior contract |
| **Orchestrator / Deal Desk Agent** | Routes quote, aggregates specialist decisions, applies confidence threshold & final policy rules |

## Quick Start

```bash
# From the dealflow_agents directory
cd dealflow_agents

# Install dependencies (if needed)
pip install streamlit pydantic

# Run the interactive demo
streamlit run app.py

# Or run the batch evaluation
python test_agents.py
```

## Sample Quotes (Golden Set)

8 realistic scenarios covering:

1. Clean Renewal → Auto-Approve
2. Aggressive Expansion Discount → Escalate / Reject
3. Worsened Payment Terms on Renewal → Escalate
4. Clean New Business → Approve
5. Borderline Add-on → Escalate
6. Extreme Discount + Poor Terms → Reject
7. Multi-Year Prepay Renewal → Strong Approve
8. Near Quarter-End Aggressive Ask → Escalate (gaming signal)

## Project Structure

```
dealflow_agents/
├── app.py                  # Streamlit UI
├── models.py               # Pydantic schemas (Quote, AgentDecision, FinalDecision)
├── test_agents.py          # Batch evaluation script
├── agents/
│   ├── discount_agent.py
│   ├── payment_terms_agent.py
│   └── orchestrator.py
└── data/
    └── quotes.py           # Sample quotes + helpers
```

## Key Design Decisions

- **Structured, deterministic agents** for reliable demos (no external LLM dependency required)
- Easy to swap in LLM-based reasoning later (same input/output contracts)
- Configurable confidence threshold in the UI
- Full audit trail for every decision
- Integration-ready data contract (same payload shape works with Salesforce CPQ, DealHub, etc.)

## Future Integration Path

The system accepts a clean structured quote payload. In production it can sit on top of:

- Salesforce CPQ / Revenue Cloud
- DealHub, Conga, Oracle CPQ, Zuora, etc.

via webhooks or APIs — both inbound (quote submitted) and outbound (decision written back).

## Capstone Narrative

**Problem** → Manual multi-queue approvals slow deals and waste high-value time.  
**Solution** → Parallel specialist agents + confidence-based auto-approve / escalate.  
**Demo** → Live review of 4–5 realistic quotes showing different decision paths.  
**Metrics** → Auto-approval rate, decision accuracy, time saved, explanation quality.  
**Roadmap** → CRM/CPQ connectors, human-in-the-loop learning, more specialist agents.
