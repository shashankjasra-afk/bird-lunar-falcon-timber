//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-dOl69vv9.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/desk"
		],
		preloads: [
			"/assets/index-DLajpncD.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/createLucideIcon-DuDp1Ei6.js",
			"/assets/createClientRpc-Dksv_hWB.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DLajpncD.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CurarbQL.js",
			"/assets/trace-row-mBergT5h.js",
			"/assets/shell-U4noUVZn.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-Db7w-yky.js",
			"/assets/trace-row-mBergT5h.js",
			"/assets/shell-U4noUVZn.js"
		]
	},
	"/desk": {
		filePath: "/workspace/src/routes/desk.tsx",
		children: void 0,
		preloads: ["/assets/desk-iYOHxxR0.js", "/assets/shell-U4noUVZn.js"]
	}
} });
//#endregion
export { tsrStartManifest };
