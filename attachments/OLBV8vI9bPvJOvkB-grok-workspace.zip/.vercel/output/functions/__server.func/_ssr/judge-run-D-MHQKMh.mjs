import { t as createServerFn } from "./ssr.mjs";
import { n as gradeCase, t as JUDGE_PROMPT } from "./judge-ueJCXWdp.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/judge-run-D-MHQKMh.js
function isDecision(value) {
	return value === "Approve" || value === "Escalate" || value === "Reject";
}
function asCase(value) {
	if (!value || typeof value !== "object") return null;
	const row = value;
	if (typeof row.id !== "string" || !isDecision(row.actual)) return null;
	return {
		id: row.id.slice(0, 40),
		expected: isDecision(row.expected) ? row.expected : null,
		actual: row.actual,
		confidence: Number(row.confidence) || 0,
		threshold: Number(row.threshold) || 0,
		cited: Array.isArray(row.cited) ? row.cited.map(String).slice(0, 8) : [],
		noteAttack: typeof row.noteAttack === "string" ? row.noteAttack.slice(0, 220) : null,
		specialistDecisions: Array.isArray(row.specialistDecisions) ? row.specialistDecisions.filter(isDecision).slice(0, 2) : [],
		assignee: typeof row.assignee === "string" ? row.assignee.slice(0, 80) : null,
		slaHours: typeof row.slaHours === "number" ? row.slaHours : null
	};
}
var runLlmJudge_createServerFn_handler = createServerRpc({
	id: "bfd9988a7188a14f8de341821909b54a94064a0954c7065a3dca93153e1497b5",
	name: "runLlmJudge",
	filename: "src/lib/dealflow/judge-run.ts"
}, (opts) => runLlmJudge.__executeServer(opts));
var runLlmJudge = createServerFn({ method: "POST" }).validator((input) => {
	return { cases: (Array.isArray(input?.cases) ? input.cases.map(asCase).filter((row) => Boolean(row)) : []).slice(0, 12) };
}).handler(runLlmJudge_createServerFn_handler, async ({ data }) => {
	const rubric = data.cases.map(gradeCase);
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey || data.cases.length === 0) return {
		source: "rubric",
		note: apiKey ? "Nothing to grade." : "The model is not configured here. The same five checks ran on-box. The decision hop did not wait on a model.",
		cases: rubric,
		inputTokens: 0,
		outputTokens: 0,
		traceId: null
	};
	try {
		const messages = [{
			role: "system",
			content: JUDGE_PROMPT
		}, {
			role: "user",
			content: JSON.stringify({ cases: data.cases.map((row) => ({
				id: row.id,
				expected: row.expected,
				actual: row.actual,
				confidence: row.confidence,
				threshold: row.threshold,
				cited: row.cited,
				noteAttack: row.noteAttack,
				assignee: row.assignee,
				slaHours: row.slaHours
			})) })
		}];
		const { runTracedModel } = await import("./langfuse.server-BNIsxa3R.mjs");
		const traced = await runTracedModel({
			name: "llm-judge",
			userId: "revops",
			sessionId: data.cases.map((row) => row.id).join(",").slice(0, 200),
			segment: "eval",
			model: "grok-4.5",
			messages,
			run: async () => {
				const res = await fetch("https://api.x.ai/v1/chat/completions", {
					method: "POST",
					signal: AbortSignal.timeout(25e3),
					headers: {
						"Content-Type": "application/json",
						Authorization: `Bearer ${apiKey}`
					},
					body: JSON.stringify({
						model: "grok-4.5",
						temperature: 0,
						max_tokens: 1200,
						response_format: { type: "json_object" },
						messages
					})
				});
				if (!res.ok) return {
					output: `HTTP ${res.status}`,
					inputTokens: 0,
					outputTokens: 0,
					value: null
				};
				const body = await res.json();
				return {
					output: body.choices?.[0]?.message?.content ?? "",
					inputTokens: body.usage?.prompt_tokens ?? 0,
					outputTokens: body.usage?.completion_tokens ?? 0,
					value: body
				};
			}
		});
		if (!traced.value) return {
			source: "rubric",
			note: "The model did not return a grade. The on-box judge scored the same checks.",
			cases: rubric,
			inputTokens: 0,
			outputTokens: 0,
			traceId: traced.traceId
		};
		const body = traced.value;
		const cleaned = (body.choices?.[0]?.message?.content ?? "").replace(/^```json\s*/i, "").replace(/```$/i, "").trim();
		const parsed = JSON.parse(cleaned);
		const byId = new Map((parsed.cases ?? []).map((row) => [row.id, row]));
		return {
			source: "grok",
			note: "Grok graded the engine output. It did not decide the quotes.",
			cases: data.cases.map((row) => {
				const local = gradeCase(row);
				const model = byId.get(row.id);
				if (!model || typeof model.pass !== "boolean") return local;
				const failed = new Set(model.failed ?? []);
				return {
					id: row.id,
					pass: failed.size === 0 && local.pass && model.pass !== false,
					checks: local.checks.map((check) => ({
						...check,
						pass: failed.has(check.id) ? false : check.pass,
						detail: failed.has(check.id) ? `${check.detail} The model failed this check.` : check.detail
					}))
				};
			}),
			inputTokens: body.usage?.prompt_tokens ?? 0,
			outputTokens: body.usage?.completion_tokens ?? 0,
			traceId: traced.traceId
		};
	} catch {
		return {
			source: "rubric",
			note: "The model could not be reached. The on-box judge scored the same checks.",
			cases: rubric,
			inputTokens: 0,
			outputTokens: 0,
			traceId: null
		};
	}
});
//#endregion
export { runLlmJudge_createServerFn_handler };
