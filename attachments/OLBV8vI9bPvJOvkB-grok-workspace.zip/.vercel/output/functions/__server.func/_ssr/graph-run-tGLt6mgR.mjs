import { t as createServerFn } from "./ssr.mjs";
import { u as reviewQuote } from "./engine-Av8XULO8.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/graph-run-tGLt6mgR.js
function isDecision(value) {
	return value === "Approve" || value === "Escalate" || value === "Reject";
}
async function callGraph(quote, discountPolicy, paymentPolicy, settings) {
	const grounded = reviewQuote(quote, discountPolicy, paymentPolicy, settings);
	const [discount, payment] = grounded.specialists;
	if (!discount || !payment) return null;
	const payload = {
		quote_id: quote.id,
		account: quote.account.name,
		segment: quote.account.segment,
		quote_type: quote.type,
		threshold: settings.confidenceThreshold,
		respect_reject: settings.respectReject,
		note_attack: grounded.noteAttack,
		discount_decision: discount.decision,
		discount_confidence: discount.confidence,
		discount_thought: discount.comments,
		discount_cited: discount.cited,
		payment_decision: payment.decision,
		payment_confidence: payment.confidence,
		payment_thought: payment.comments,
		payment_cited: payment.cited
	};
	try {
		const res = await fetch("http://127.0.0.1:8091/hop", {
			method: "POST",
			signal: AbortSignal.timeout(4e3),
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(payload)
		});
		if (!res.ok) return null;
		const body = await res.json();
		if (!isDecision(body.overall) || !Array.isArray(body.nodes)) return null;
		return {
			stack: Array.isArray(body.stack) ? body.stack.map(String) : [
				"Python",
				"LangGraph",
				"Pydantic"
			],
			quoteId: String(body.quote_id ?? quote.id),
			overall: body.overall,
			confidence: Number(body.confidence) || 0,
			rule: String(body.rule ?? ""),
			guardrail: String(body.guardrail ?? ""),
			plan: String(body.plan ?? ""),
			nodes: body.nodes.map((node) => ({
				node: String(node.node ?? ""),
				summary: String(node.summary ?? "")
			}))
		};
	} catch {
		return null;
	}
}
var runLangGraph_createServerFn_handler = createServerRpc({
	id: "fa1ed507b8486eca373f2739b1db32044d5ca5317f2a23cd3bccfde2de8f3654",
	name: "runLangGraph",
	filename: "src/lib/dealflow/graph-run.ts"
}, (opts) => runLangGraph.__executeServer(opts));
var runLangGraph = createServerFn({ method: "POST" }).validator((input) => input).handler(runLangGraph_createServerFn_handler, async ({ data }) => {
	const graph = await callGraph(data.quote, data.discountPolicy, data.paymentPolicy, data.settings);
	if (!graph) return {
		ok: false,
		note: "The Python graph is not answering on port 8091. The page is still using the in-app reading.",
		graph: null
	};
	return {
		ok: true,
		note: "LangGraph finished. Each node returned a Pydantic object.",
		graph
	};
});
//#endregion
export { runLangGraph_createServerFn_handler };
