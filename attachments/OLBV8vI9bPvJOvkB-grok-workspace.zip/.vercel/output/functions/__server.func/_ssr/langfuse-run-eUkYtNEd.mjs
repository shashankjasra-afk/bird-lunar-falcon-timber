import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/langfuse-run-eUkYtNEd.js
function isDecision(value) {
	return value === "Approve" || value === "Escalate" || value === "Reject";
}
function asRow(value) {
	if (!value || typeof value !== "object") return null;
	const row = value;
	if (row.kind !== "decision" && row.kind !== "judge" || typeof row.quoteId !== "string" || !isDecision(row.decision)) return null;
	return {
		kind: row.kind,
		quoteId: row.quoteId.slice(0, 40),
		account: String(row.account ?? "").slice(0, 80),
		sellerId: String(row.sellerId ?? "").slice(0, 80),
		segment: String(row.segment ?? "").slice(0, 40),
		decision: row.decision,
		confidence: Number(row.confidence) || 0,
		rule: String(row.rule ?? "").slice(0, 160),
		engineMs: Number(row.engineMs) || 0,
		noteAttack: typeof row.noteAttack === "string" ? row.noteAttack.slice(0, 220) : null,
		cited: Array.isArray(row.cited) ? row.cited.map(String).slice(0, 6) : [],
		expected: isDecision(row.expected) ? row.expected : null,
		assignee: typeof row.assignee === "string" ? row.assignee.slice(0, 80) : null,
		slaHours: typeof row.slaHours === "number" ? row.slaHours : null,
		specialists: Array.isArray(row.specialists) ? row.specialists.filter((item) => item && (item.name === "discount-pricing" || item.name === "payment-terms")).slice(0, 2).map((item) => ({
			name: item.name,
			decision: isDecision(item.decision) ? item.decision : row.decision,
			confidence: Number(item.confidence) || 0,
			cited: Array.isArray(item.cited) ? item.cited.map(String).slice(0, 4) : []
		})) : [],
		judgeSource: row.judgeSource === "grok" || row.judgeSource === "rubric" ? row.judgeSource : null,
		judgePass: typeof row.judgePass === "boolean" ? row.judgePass : null,
		inputTokens: Number(row.inputTokens) || 0,
		outputTokens: Number(row.outputTokens) || 0
	};
}
var getLangfuseStatus_createServerFn_handler = createServerRpc({
	id: "bd10c42693c07bb55162abd9f622357f09116a13e7c2f31fb77e1288c94f1526",
	name: "getLangfuseStatus",
	filename: "src/lib/dealflow/langfuse-run.ts"
}, (opts) => getLangfuseStatus.__executeServer(opts));
var getLangfuseStatus = createServerFn({ method: "GET" }).handler(getLangfuseStatus_createServerFn_handler, async () => {
	const { langfuseStatus } = await import("./langfuse.server-BNIsxa3R.mjs");
	return langfuseStatus();
});
var recordTraces_createServerFn_handler = createServerRpc({
	id: "4b1ab22e937fb0110d19d221b7aa5f38bed215dc6b3470f719dff59404922f06",
	name: "recordTraces",
	filename: "src/lib/dealflow/langfuse-run.ts"
}, (opts) => recordTraces.__executeServer(opts));
var recordTraces = createServerFn({ method: "POST" }).validator((input) => {
	return { rows: (Array.isArray(input?.rows) ? input.rows.map(asRow).filter((row) => Boolean(row)) : []).slice(0, 12) };
}).handler(recordTraces_createServerFn_handler, async ({ data }) => {
	const { emitDealflowTraces } = await import("./langfuse.server-BNIsxa3R.mjs");
	return emitDealflowTraces(data.rows);
});
//#endregion
export { getLangfuseStatus_createServerFn_handler, recordTraces_createServerFn_handler };
