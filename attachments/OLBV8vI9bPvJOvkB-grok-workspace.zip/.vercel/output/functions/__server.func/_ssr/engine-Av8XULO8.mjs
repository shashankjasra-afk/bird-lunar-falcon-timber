import { u as defaultAssignmentRules } from "./policies-nD2AkcDb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-Av8XULO8.js
function named(rule, cash) {
	if (cash && rule.assigneeCash) return {
		assignee: rule.assigneeCash,
		externalId: rule.externalIdCash || rule.externalId
	};
	return {
		assignee: rule.assignee,
		externalId: rule.externalId
	};
}
function assignCase(quote, discount, payment, overall, rules, net) {
	if (overall === "Approve") return null;
	const flags = [...discount.flags, ...payment.flags];
	const hardViolation = overall === "Reject" || flags.some((flag) => flag.startsWith("Exceeds maximum") || flag.includes("High value + high-risk"));
	const poorTerms = payment.flags.some((flag) => /High-risk|Elevated|Worsening/.test(flag));
	const highDiscount = discount.flags.length > 0;
	const gaming = flags.some((flag) => flag.includes("period-end"));
	const material = flags.some((flag) => flag.includes("jump") || flag.includes("Worsening") || flag.includes("Elevated") || flag.includes("Above standard"));
	let ruleId = "mild";
	if (hardViolation) ruleId = "violation";
	else if (highDiscount && poorTerms || net > 2e5 && poorTerms) ruleId = "severe";
	else if (gaming) ruleId = "gaming";
	else if (material || highDiscount || poorTerms) ruleId = "material";
	const rule = rules.find((item) => item.id === ruleId) ?? rules.find((item) => item.id === "mild");
	if (!rule) return null;
	const discountHit = discount.decision !== "Approve";
	const cashHit = payment.decision !== "Approve";
	let picked = named(rule, false);
	if (rule.assigneeCash && (ruleId === "material" || ruleId === "violation")) {
		if (cashHit && !discountHit) picked = named(rule, true);
		else if (cashHit && discountHit) picked = {
			assignee: `${rule.assignee} + ${rule.assigneeCash}`,
			externalId: [rule.externalId, rule.externalIdCash].filter(Boolean).join(" + ")
		};
	}
	const reason = ruleId === "violation" ? `Clear policy violation on ${quote.id}. ${flags.slice(0, 2).join("; ") || "A specialist rejected."}` : ruleId === "severe" ? `High discount with weak cash terms, or a large deal on weak terms. Net ${Math.round(net).toLocaleString("en-US")}.` : ruleId === "gaming" ? "Quarter-end elevated discount. Tighter SLA so the period-close queue sees it first." : ruleId === "material" ? cashHit && !discountHit ? `Payment terms moved past the standard book. ${flags[0] ?? "Cash exception needs Finance."}` : `Discount moved past the standard book. ${flags[0] ?? "Exception needs an owner."}` : "Mild exception inside the ceiling. A manager can clear it without an executive.";
	return {
		ruleId,
		assignee: picked.assignee,
		queue: rule.queue,
		slaHours: rule.slaHours,
		reason,
		externalId: picked.externalId,
		integration: rule.integration
	};
}
var moneyFmt = new Intl.NumberFormat("en-US", {
	style: "currency",
	currency: "USD",
	maximumFractionDigits: 0
});
var moneyExact = new Intl.NumberFormat("en-US", {
	style: "currency",
	currency: "USD",
	minimumFractionDigits: 0,
	maximumFractionDigits: 2
});
function money(n) {
	return moneyFmt.format(Math.round(n));
}
function moneyExactFmt(n) {
	return moneyExact.format(n);
}
function pct(n) {
	return `${n.toFixed(1)}%`;
}
function round1(n) {
	return Math.round(n * 10) / 10;
}
function round2(n) {
	return Math.round(n * 100) / 100;
}
function lineNet(listPrice, discountPct) {
	return round2(listPrice * (1 - discountPct / 100));
}
function quoteTotals(quote) {
	const list = quote.lineItems.reduce((sum, item) => sum + item.listPrice * item.quantity, 0);
	const net = quote.lineItems.reduce((sum, item) => sum + lineNet(item.listPrice, item.discountPct) * item.quantity, 0);
	return {
		list,
		net,
		discount: list === 0 ? 0 : round1((1 - net / list) * 100)
	};
}
function typeKey(type) {
	if (type === "New") return "new_business";
	if (type === "Renewal") return "renewal";
	if (type === "Expansion") return "expansion";
	return "addon";
}
function typeLabel(key) {
	if (key === "new_business") return "New business";
	if (key === "renewal") return "Renewal";
	if (key === "expansion") return "Expansion";
	return "Add-on";
}
var STAGE_LABEL = {
	draft: "Draft",
	submitted: "Submit for approval",
	approved: "Approved",
	sent: "Sent to customer",
	signed: "Signed by customer",
	converted: "Converted",
	rejected: "Rejected"
};
function stageLabel(stage) {
	return STAGE_LABEL[stage];
}
function formatWhen(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return iso;
	return date.toLocaleString("en-GB", {
		day: "numeric",
		month: "short",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit"
	});
}
function formatDay(iso) {
	const date = new Date(iso.includes("T") ? iso : `${iso}T00:00:00`);
	if (Number.isNaN(date.getTime())) return iso;
	return date.toLocaleDateString("en-GB", {
		day: "numeric",
		month: "short",
		year: "numeric"
	});
}
function toPayload(quote) {
	const totals = quoteTotals(quote);
	return {
		quote_id: quote.id,
		quote_type: quote.type,
		account: {
			name: quote.account.name,
			segment: quote.account.segment,
			region: quote.account.region,
			existing_acv: quote.account.existingAcv
		},
		seller: {
			id: quote.seller.id,
			name: quote.seller.name
		},
		submission_date: quote.quoteDate,
		contract_length_months: quote.contractMonths,
		payment_terms: quote.paymentTerms,
		billing_frequency: quote.billingFrequency,
		line_items: quote.lineItems.map((item) => ({
			product: item.product,
			quantity: item.quantity,
			list_price: item.listPrice,
			proposed_discount_pct: item.discountPct,
			net_price: lineNet(item.listPrice, item.discountPct)
		})),
		historical: quote.historical ? {
			previous_discount_pct: quote.historical.previousDiscountPct,
			previous_payment_terms: quote.historical.previousPaymentTerms,
			previous_billing_frequency: quote.historical.previousBillingFrequency
		} : null,
		totals: {
			list: Math.round(totals.list),
			net: Math.round(totals.net),
			discount_pct: totals.discount
		},
		notes: quote.notes
	};
}
var FILES = {
	"Northwind Fabrication": {
		posture: "Renewal file",
		years: [
			{
				year: "FY2023",
				discountPct: 15,
				terms: "Net-30",
				billing: "Annual",
				acv: 162e3
			},
			{
				year: "FY2024",
				discountPct: 16,
				terms: "Net-30",
				billing: "Annual",
				acv: 174e3
			},
			{
				year: "FY2025",
				discountPct: 17,
				terms: "Net-30",
				billing: "Annual",
				acv: 185e3
			}
		],
		credit: {
			band: "Strong",
			onTimePct: 98,
			dso: 18,
			openAr: 0,
			overdue: 0,
			daysPastDue: 0,
			note: "Every invoice in the last eight quarters was collected inside terms."
		},
		contracts: [{
			name: "FY2025 renewal",
			term: "12 months",
			discountPct: 17,
			status: "Closed"
		}],
		peers: [],
		discountLook: "I opened three closed years before the live band. Discount stepped 15, then 16, then 17. This ask is about one point over last year, which is inside a normal renewal step.",
		cashLook: "Credit is Strong. Open receivables are zero, so dues do not argue against the renewal."
	},
	"Harbor & Co.": {
		posture: "Renewal file",
		years: [
			{
				year: "FY2023",
				discountPct: 11,
				terms: "Net-30",
				billing: "Annual",
				acv: 82e3
			},
			{
				year: "FY2024",
				discountPct: 12,
				terms: "Net-30",
				billing: "Annual",
				acv: 91e3
			},
			{
				year: "FY2025",
				discountPct: 12,
				terms: "Net-30",
				billing: "Annual",
				acv: 96e3
			}
		],
		credit: {
			band: "Watch",
			onTimePct: 81,
			dso: 41,
			openAr: 31200,
			overdue: 18400,
			daysPastDue: 22,
			note: "One invoice is 22 days past due. Collections has not written it off."
		},
		contracts: [{
			name: "FY2025 renewal",
			term: "12 months",
			discountPct: 12,
			status: "Closed"
		}, {
			name: "This quote",
			term: "24 months",
			discountPct: 15,
			status: "Open"
		}],
		peers: [],
		discountLook: "The price history is quiet: 11, then 12, then 12. The discount itself is not the story. They are also asking to turn an annual renewal into a 24-month term.",
		cashLook: "I read the receivables file, not just the term names. $18,400 is already past due and the new ask is Net-90. That is a worse cash position than the last three years."
	},
	"Pinnacle Health": {
		posture: "Renewal file",
		years: [
			{
				year: "FY2023",
				discountPct: 18,
				terms: "Net-30",
				billing: "Annual",
				acv: 36e4
			},
			{
				year: "FY2024",
				discountPct: 20,
				terms: "Net-30",
				billing: "Annual",
				acv: 39e4
			},
			{
				year: "FY2025",
				discountPct: 22,
				terms: "Net-30",
				billing: "Annual",
				acv: 42e4
			}
		],
		credit: {
			band: "Strong",
			onTimePct: 96,
			dso: 21,
			openAr: 0,
			overdue: 0,
			daysPastDue: 0,
			note: "Credit would support an expansion. The discount step does not."
		},
		contracts: [{
			name: "FY2025 enterprise",
			term: "12 months",
			discountPct: 22,
			status: "Closed"
		}],
		peers: [],
		discountLook: "Last three closed discounts were 18, 20, and 22. Credit is clean. The expansion ask jumps well past both that history and the exception ceiling, so the file does not support an approval.",
		cashLook: "Dues are current. Cash is not why this one fails."
	},
	"Sable Energy": {
		posture: "Renewal file",
		years: [
			{
				year: "FY2023",
				discountPct: 18,
				terms: "Net-30",
				billing: "Annual",
				acv: 24e4
			},
			{
				year: "FY2024",
				discountPct: 19,
				terms: "Net-30",
				billing: "Annual",
				acv: 258e3
			},
			{
				year: "FY2025",
				discountPct: 20,
				terms: "Net-30",
				billing: "Annual",
				acv: 275e3
			}
		],
		credit: {
			band: "Strong",
			onTimePct: 99,
			dso: 14,
			openAr: 0,
			overdue: 0,
			daysPastDue: 0,
			note: "Prepaid the last annual invoice 11 days early."
		},
		contracts: [{
			name: "FY2025 annual",
			term: "12 months",
			discountPct: 20,
			status: "Closed"
		}, {
			name: "Proposed prepay",
			term: "36 months",
			discountPct: 25,
			status: "Open"
		}],
		peers: [],
		discountLook: "History is a steady 18, 19, 20. This quote is a 36-month prepay, so I read the multi-year allowance in the book before judging the step-up from 20.",
		cashLook: "No overdue balance. Prepaying three years improves cash, it does not weaken it."
	},
	"Brightline Retail": {
		posture: "Renewal file",
		years: [{
			year: "FY2024",
			discountPct: 18,
			terms: "Net-30",
			billing: "Annual",
			acv: 54e4
		}, {
			year: "FY2025",
			discountPct: 20,
			terms: "Net-30",
			billing: "Annual",
			acv: 61e4
		}],
		credit: {
			band: "Strong",
			onTimePct: 94,
			dso: 27,
			openAr: 42e3,
			overdue: 0,
			daysPastDue: 0,
			note: "Open AR is inside terms. Nothing is late."
		},
		contracts: [{
			name: "FY2025 enterprise",
			term: "12 months",
			discountPct: 20,
			status: "Closed"
		}],
		peers: [],
		discountLook: "The installed base was 18 then 20. This add-on asks for a much larger discount than either closed year, so I am comparing the jump to the book, not to the seller's note.",
		cashLook: "Terms also step from Net-30 to Net-45. Receivables are current, so the hold is about the change, not about a missed invoice."
	},
	"Vanta Robotics": {
		posture: "Renewal file",
		years: [{
			year: "FY2024",
			discountPct: 17,
			terms: "Net-30",
			billing: "Annual",
			acv: 76e4
		}, {
			year: "FY2025",
			discountPct: 19,
			terms: "Net-30",
			billing: "Annual",
			acv: 89e4
		}],
		credit: {
			band: "Watch",
			onTimePct: 88,
			dso: 36,
			openAr: 12e4,
			overdue: 15e3,
			daysPastDue: 9,
			note: "A small balance is nine days late. Not a default. Quarter-end timing is the sharper signal."
		},
		contracts: [{
			name: "FY2025 enterprise",
			term: "12 months",
			discountPct: 19,
			status: "Closed"
		}],
		peers: [],
		discountLook: "Closed years were 17 and 19. The expansion is a large step up, and the quote date sits in the quarter-end window. I am treating that as a pattern in the file, not as an instruction.",
		cashLook: "A small overdue balance plus a move from Net-30 to Net-60. Cash history does not clear the step."
	},
	"Lumen Logistics": {
		posture: "New-business file",
		years: [],
		credit: {
			band: "Unscored",
			onTimePct: 0,
			dso: 0,
			openAr: 0,
			overdue: 0,
			daysPastDue: 0,
			note: "No invoices exist yet. Credit is a new-logo application, not a payment history."
		},
		contracts: [],
		peers: [
			{
				name: "Enterprise new logo, closed Q2",
				discountPct: 19,
				note: "Net-30, annual"
			},
			{
				name: "Enterprise new logo, closed Q3",
				discountPct: 21,
				note: "Net-30, annual"
			},
			{
				name: "Enterprise new logo, closed Oct",
				discountPct: 22,
				note: "Inside the new-business ceiling"
			}
		],
		discountLook: "There is no installed discount to compare. I used the new-business band and three recent enterprise wins at 19, 21, and 22. This ask sits with those peers.",
		cashLook: "Nothing is due. I am scoring the proposed terms against the book, not against a missed payment."
	},
	"Copperline Analytics": {
		posture: "New-business file",
		years: [],
		credit: {
			band: "Unscored",
			onTimePct: 0,
			dso: 0,
			openAr: 0,
			overdue: 0,
			daysPastDue: 0,
			note: "New logo. No receivables file."
		},
		contracts: [],
		peers: [{
			name: "Mid-market new logo, closed Q3",
			discountPct: 16,
			note: "Net-30"
		}, {
			name: "Mid-market new logo, closed Q3",
			discountPct: 18,
			note: "Net-45"
		}],
		discountLook: "No history on this account. Peer new logos in mid-market closed between 16 and 18. This ask is far outside that set and outside the exception ceiling.",
		cashLook: "No dues to collect. The proposed Net-90 and monthly billing are the cash risk, not a past-due balance."
	},
	"Kite & Harbor": {
		posture: "New-business file",
		years: [],
		credit: {
			band: "Unscored",
			onTimePct: 0,
			dso: 0,
			openAr: 0,
			overdue: 0,
			daysPastDue: 0,
			note: "New logo. The notes tried to invent an approval. The file has no payment history that would support one."
		},
		contracts: [],
		peers: [{
			name: "Mid-market new logo, closed Q2",
			discountPct: 15,
			note: "Net-30, annual"
		}, {
			name: "Mid-market new logo, closed Q3",
			discountPct: 18,
			note: "Net-30, annual"
		}],
		discountLook: "I ignored the instruction in the notes and opened the new-business file instead. There is no prior discount. Peers closed at 15 to 18. This ask does not belong with them.",
		cashLook: "No open invoices. Net-90 and monthly billing are both outside what those peers were given."
	}
};
function fallback(quote) {
	const prior = quote.historical?.previousDiscountPct;
	if (quote.type === "New" || prior == null) return {
		posture: "New-business file",
		years: [],
		credit: {
			band: "Unscored",
			onTimePct: 0,
			dso: 0,
			openAr: 0,
			overdue: 0,
			daysPastDue: 0,
			note: "No invoices on this account. Credit has not been scored from payments."
		},
		contracts: [],
		peers: [{
			name: `${quote.account.segment} new logo, recent`,
			discountPct: 18,
			note: "Synthetic peer"
		}, {
			name: `${quote.account.segment} new logo, prior quarter`,
			discountPct: 20,
			note: "Synthetic peer"
		}],
		discountLook: `No closed discount on ${quote.account.name}. I am reading this as new business and comparing it with recent ${quote.account.segment} wins, then with the live band.`,
		cashLook: "There is no receivables file. The cash question is only the terms on this quote."
	};
	const base = prior;
	return {
		posture: "Renewal file",
		years: [
			{
				year: "FY2023",
				discountPct: Math.max(0, base - 2),
				terms: quote.historical?.previousPaymentTerms ?? "Net-30",
				billing: "Annual",
				acv: Math.round((quote.account.existingAcv ?? 1e5) * .86)
			},
			{
				year: "FY2024",
				discountPct: Math.max(0, base - 1),
				terms: quote.historical?.previousPaymentTerms ?? "Net-30",
				billing: "Annual",
				acv: Math.round((quote.account.existingAcv ?? 1e5) * .93)
			},
			{
				year: "FY2025",
				discountPct: base,
				terms: quote.historical?.previousPaymentTerms ?? "Net-30",
				billing: quote.historical?.previousBillingFrequency ?? "Annual",
				acv: quote.account.existingAcv ?? 1e5
			}
		],
		credit: {
			band: "Strong",
			onTimePct: 95,
			dso: 22,
			openAr: 0,
			overdue: 0,
			daysPastDue: 0,
			note: "Synthetic file. No overdue balance on record."
		},
		contracts: quote.contractMonths > 12 ? [{
			name: "Proposed term",
			term: `${quote.contractMonths} months`,
			discountPct: base,
			status: "Open"
		}] : [{
			name: "Prior annual",
			term: "12 months",
			discountPct: base,
			status: "Closed"
		}],
		peers: [],
		discountLook: `I built the discount trail from the last contract at ${base}% and two earlier years. The live band is the second thing I open, not the first.`,
		cashLook: "The synthetic receivables file shows no overdue balance."
	};
}
function commercialFile(quote) {
	return FILES[quote.account.name] ?? fallback(quote);
}
function discountInvestigation(quote) {
	const file = commercialFile(quote);
	const trail = file.years.length > 0 ? `Closed discounts: ${file.years.map((year) => `${year.year} ${pct(year.discountPct)}`).join(", ")}.` : `No closed discounts. Peers: ${file.peers.map((peer) => `${peer.discountPct}%`).join(", ")}.`;
	return `${file.discountLook} ${trail}`;
}
function cashInvestigation(quote) {
	const file = commercialFile(quote);
	if (!file.credit || file.credit.band === "Unscored") return file.cashLook;
	return `${file.cashLook} On-time ${file.credit.onTimePct}%, DSO ${file.credit.dso} days, overdue ${money(file.credit.overdue)}.`;
}
var TERM_ORDER = [
	"Due on Receipt",
	"Net-30",
	"Net-45",
	"Net-60",
	"Net-90"
];
var NOTE_ATTACK = [
	/ignore (?:all |the |your )?(?:discount |payment |commercial )?(?:policy|book|rules)/i,
	/you are now/i,
	/admin mode/i,
	/do not escalate/i,
	/mark (?:this |the )?quote approved/i,
	/override (?:the |all )?(?:policy|book|rules)/i,
	/disregard (?:the |all )?(?:policy|book|rules)/i,
	/\bsystem\s*:/i
];
function detectNoteAttack(notes) {
	const line = notes.split("\n").map((row) => row.trim()).find((row) => NOTE_ATTACK.some((pattern) => pattern.test(row)));
	if (!line) return null;
	return line.slice(0, 220);
}
function clamp(n) {
	return Math.max(5, Math.min(97, Math.round(n)));
}
function isWorse(previous, current) {
	const a = TERM_ORDER.indexOf(previous);
	const b = TERM_ORDER.indexOf(current);
	if (a === -1 || b === -1) return true;
	return b > a;
}
function nearQuarterEnd(quoteDate, maxStandard, discount) {
	const [yearRaw, monthRaw, dayRaw] = quoteDate.split("-").map(Number);
	if (!yearRaw || !monthRaw || !dayRaw) return false;
	if (![
		1,
		4,
		7,
		10
	].includes(monthRaw)) return false;
	return dayRaw >= new Date(Date.UTC(yearRaw, monthRaw, 0)).getUTCDate() - 4 && discount >= maxStandard - 2;
}
function reviewDiscount(quote, policy, settings) {
	const totals = quoteTotals(quote);
	const key = typeKey(quote.type);
	const segmentPolicy = policy.segments[quote.account.segment] ?? policy.segments.Enterprise;
	const band = segmentPolicy[key] ?? segmentPolicy.new_business;
	const credit = quote.billingFrequency === "Multi-Year Prepay" ? settings.prepayCreditPts : 0;
	const maxStandard = band.maxStandard + credit;
	const maxException = band.maxException + credit;
	const maxJump = (band.maxIncreaseVsPrevious ?? 5) + credit;
	const reasoning = [];
	const flags = [];
	const cited = [`${policy.policyId} → ${quote.account.segment}.${key}`];
	let confidence = 88;
	const cuts = [];
	reasoning.unshift(discountInvestigation(quote));
	if (credit > 0) {
		reasoning.push(`CR-02: Multi-year prepay adds ${credit} pts. Standard ceiling ${band.maxStandard}% → ${maxStandard}%. Exception ceiling ${band.maxException}% → ${maxException}%.`);
		cited.push("CR-02 multi-year prepay allowance");
	} else reasoning.push(`Standard ceiling ${maxStandard}%. Exception ceiling ${maxException}%.`);
	const discount = totals.discount;
	if (discount <= maxStandard) {
		reasoning.push(`Proposed discount ${discount}% is inside the standard ceiling of ${maxStandard}%.`);
		cited.push(`Within standard (${maxStandard}%)`);
	} else if (discount <= maxException) {
		const delta = round1(discount - maxStandard);
		reasoning.push(`Proposed discount ${discount}% is ${delta} pts over standard and still under the exception ceiling of ${maxException}%.`);
		flags.push(`Above standard discount (by ${delta} pts)`);
		cited.push(`Between standard (${maxStandard}%) and exception (${maxException}%)`);
		confidence -= 18;
		cuts.push("−18 above the standard ceiling");
	} else {
		const delta = round1(discount - maxException);
		reasoning.push(`Proposed discount ${discount}% exceeds the exception ceiling of ${maxException}% by ${delta} pts.`);
		flags.push("Exceeds maximum exception discount");
		cited.push(`Above exception ceiling (${maxException}%)`);
		confidence -= 45;
		cuts.push("−45 past the exception ceiling");
	}
	if (quote.historical?.previousDiscountPct != null) {
		const prev = quote.historical.previousDiscountPct;
		const jump = round1(discount - prev);
		reasoning.push(`Previous contract discount was ${prev}%. This ask is ${jump >= 0 ? "+" : ""}${jump} pts.`);
		if (jump > maxJump) {
			flags.push(`Discount jump vs history exceeds policy (${jump} pts > ${maxJump} pts)`);
			cited.push(`SR-02 historical jump (limit ${maxJump} pts)`);
			confidence -= 15;
			cuts.push(`−15 jump above the ${maxJump} pt step`);
			reasoning.push(`SR-02: an increase above ${maxJump} pts versus the prior contract goes to Deal Desk.`);
		} else if (jump > 0) reasoning.push(`The ${jump} pt change is inside the allowed ${maxJump} pt band.`);
	}
	const tiers = band.volumeTiers;
	if (tiers?.length) {
		const tier = tiers.find((row) => totals.net >= row.minAcv && totals.net < row.maxAcv);
		if (tier && discount > tier.maxDiscount + 3) {
			reasoning.push(`Net ${Math.round(totals.net).toLocaleString("en-US")} sits in a volume tier capped at ${tier.maxDiscount}%.`);
			flags.push(`Above volume-tier maximum (${tier.maxDiscount}%)`);
			confidence -= 12;
			cuts.push("−12 above the volume tier");
		} else if (tier) reasoning.push(`Net value sits in the ${tier.maxDiscount}% volume tier. Discount is inside that band.`);
	}
	if (totals.net < 5e4 && discount > 25) {
		flags.push("High discount on small deal (< $50k)");
		cited.push("SR-03 small deal high discount");
		confidence -= 15;
		cuts.push("−15 small deal above 25%");
		reasoning.push("SR-03: under $50k net and above 25% off is escalated by default.");
	}
	if (nearQuarterEnd(quote.quoteDate, maxStandard, discount)) {
		flags.push("Near period-end with elevated discount");
		cited.push("SR-01 quarter-end elevated scrutiny");
		confidence -= 10;
		cuts.push("−10 quarter-end window");
		reasoning.push("SR-01: quote date is in the last 5 days of a fiscal quarter and the discount is within 2 pts of the standard ceiling.");
	}
	const clamped = clamp(confidence);
	confidence = clamped;
	let decision;
	let comments;
	let floorNote = "";
	if (flags.includes("Exceeds maximum exception discount")) {
		decision = "Reject";
		comments = `Reject. ${discount}% exceeds the ${maxException}% exception ceiling in ${policy.policyId} for ${quote.account.segment} ${quote.type}. This needs a VP exception.`;
	} else if (flags.length && confidence < 68) {
		decision = "Escalate";
		comments = `Escalate to Deal Desk. ${discount}% is over the ${maxStandard}% standard and/or trips a special rule. Cited: ${cited.slice(0, 3).join(", ")}.`;
	} else if (flags.length) {
		decision = "Escalate";
		comments = `Escalate. Not a hard breach, but the discount profile has risk flags under ${policy.policyId}.`;
	} else {
		decision = "Approve";
		comments = `Approve. ${discount}% is inside the ${maxStandard}% standard for ${quote.account.segment} ${quote.type} (${policy.policyId}).`;
		const floored = Math.max(confidence, 84);
		floorNote = floored === confidence ? " Clean approve keeps the score. The floor is 84." : " Clean approve lifts the score to the 84 floor.";
		confidence = floored;
	}
	const formula = `Start 88${cuts.length ? " " + cuts.join(" ") : ""}. Clamp 5–97 → ${clamped}.${floorNote} = ${confidence}%.`;
	reasoning.push(formula);
	return {
		agentName: "Discount & Pricing",
		decision,
		confidence,
		reasoning,
		comments,
		flags,
		cited,
		formula
	};
}
function reviewPayment(quote, policy) {
	const totals = quoteTotals(quote);
	const reasoning = [];
	const flags = [];
	const cited = [policy.policyId];
	let confidence = 90;
	const cuts = [];
	const terms = quote.paymentTerms;
	const billing = quote.billingFrequency;
	const termBucket = policy.terms[terms] ?? "high_risk";
	const billBucket = policy.billing[billing] ?? "high_risk";
	reasoning.push(`Loaded ${policy.policyName} ${policy.version} (${policy.policyId}).`);
	if (termBucket === "preferred") {
		reasoning.push(`${terms} is a preferred payment term.`);
		cited.push("Preferred payment terms");
	} else if (termBucket === "acceptable") {
		reasoning.push(`${terms} is acceptable. Soft flag only.`);
		flags.push(`Non-preferred payment terms (${terms})`);
		cited.push("Acceptable payment terms");
		confidence -= 8;
		cuts.push("−8 acceptable terms");
	} else if (termBucket === "elevated") {
		reasoning.push(`${terms} is elevated risk and stretches DSO.`);
		flags.push(`Elevated payment terms (${terms})`);
		cited.push("Elevated payment terms");
		confidence -= 22;
		cuts.push("−22 elevated terms");
	} else {
		reasoning.push(`${terms} is high-risk and outside ordinary policy.`);
		flags.push(`High-risk payment terms (${terms})`);
		cited.push("High-risk payment terms");
		confidence -= 40;
		cuts.push("−40 high-risk terms");
	}
	if (billBucket === "preferred") {
		reasoning.push(`${billing} is a preferred billing frequency.`);
		if (billing === "Multi-Year Prepay") {
			reasoning.push("Multi-year prepay is a cash and retention positive.");
			const lifted = Math.min(97, confidence + 6);
			cuts.push(`+6 multi-year prepay → ${lifted}`);
			confidence = lifted;
		}
		cited.push("Preferred billing frequency");
	} else if (billBucket === "acceptable") {
		reasoning.push(`${billing} billing is acceptable.`);
		confidence -= 5;
		cuts.push("−5 acceptable billing");
	} else {
		reasoning.push(`${billing} billing is high-risk: more overhead and slower cash.`);
		flags.push(`High-risk billing frequency (${billing})`);
		cited.push("High-risk billing");
		confidence -= 20;
		cuts.push("−20 high-risk billing");
	}
	const prev = quote.historical?.previousPaymentTerms;
	if (prev && prev !== terms) {
		reasoning.push(`Payment terms move from ${prev} to ${terms}.`);
		if (isWorse(prev, terms)) {
			flags.push("Worsening of payment terms vs previous contract");
			cited.push("CR-01 worsening on renewal");
			confidence -= 18;
			cuts.push("−18 worse than the last contract");
			reasoning.push("CR-01: a longer payment term than the prior contract must be escalated.");
		} else reasoning.push("The new terms are shorter than the prior contract. No worsening flag.");
	}
	if (totals.net > 2e5 && termBucket === "high_risk") {
		flags.push("High value + high-risk terms");
		cited.push("CR-03 high value + high risk");
		confidence -= 12;
		cuts.push("−12 high value with high-risk terms");
		reasoning.push("CR-03: above $200k net with high-risk terms needs VP Finance.");
	}
	const payClamped = clamp(confidence);
	confidence = payClamped;
	const bothHighRisk = termBucket === "high_risk" && billBucket === "high_risk";
	let decision;
	let comments;
	let floorNote = "";
	if (bothHighRisk) {
		decision = "Reject";
		comments = `Reject. ${terms} together with ${billing} is an unacceptable cash position under ${policy.policyId}. Needs a VP Finance exception.`;
	} else if (flags.length && confidence < 70) {
		decision = "Escalate";
		comments = `Escalate. Terms (${terms}) and/or billing (${billing}) leave preferred standards or worsen the prior contract. Cited: ${cited.slice(0, 3).join(", ")}.`;
	} else if (flags.length) {
		decision = "Escalate";
		comments = `Escalate. Not a hard cash breach, but flags require Deal Desk under ${policy.policyId}.`;
	} else {
		decision = "Approve";
		comments = `Approve. ${terms} and ${billing} sit in preferred or acceptable standards (${policy.policyId}).`;
		const floored = Math.max(confidence, 85);
		floorNote = floored === confidence ? " Clean approve keeps the score. The floor is 85." : " Clean approve lifts the score to the 85 floor.";
		confidence = floored;
	}
	const formula = `Start 90${cuts.length ? " " + cuts.join(" ") : ""}. Clamp 5–97 → ${payClamped}.${floorNote} = ${confidence}%.`;
	reasoning.push(formula);
	reasoning.unshift(cashInvestigation(quote));
	return {
		agentName: "Payment Terms & Billing",
		decision,
		confidence,
		reasoning,
		comments,
		flags,
		cited,
		formula
	};
}
function stageFor(decision) {
	if (decision === "Approve") return "approved";
	if (decision === "Reject") return "rejected";
	return "submitted";
}
function writebackFor(decision, assignment) {
	if (decision === "Approve") return "The agents wrote the stage from Submit for approval to Approved. No person is in the queue. The seller can send the quote.";
	if (!assignment) return decision === "Reject" ? "The agents rejected the quote and returned it to the seller." : "The agents held the quote at Submit for approval.";
	return `${decision === "Reject" ? "The agents rejected the quote." : "The agents held the quote on Submit for approval."} Assigned to: ${assignment.assignee} | SLA: ${assignment.slaHours}h | Reason: ${assignment.reason}`;
}
function reviewQuote(quote, discountPolicy, paymentPolicy, settings) {
	const started = performance.now();
	const totals = quoteTotals(quote);
	const discount = reviewDiscount(quote, discountPolicy, settings);
	const payment = reviewPayment(quote, paymentPolicy);
	const decisions = [discount.decision, payment.decision];
	const confidences = [discount.confidence, payment.confidence];
	const flags = [...discount.flags, ...payment.flags];
	let overall;
	let confidence;
	let reason;
	let rule;
	if (decisions.includes("Reject")) {
		if (settings.respectReject) {
			overall = "Reject";
			confidence = Math.min(...confidences);
			reason = "A specialist rejected. The orchestrator is set to respect Reject.";
			rule = "R1 · any Reject → Reject";
		} else {
			overall = "Escalate";
			confidence = Math.min(...confidences);
			reason = "A specialist rejected, but the orchestrator is set to escalate instead of hard-reject.";
			rule = "R1b · Reject downgraded to Escalate";
		}
	} else if (decisions.includes("Escalate")) {
		overall = "Escalate";
		confidence = Math.min(...confidences);
		reason = "A specialist escalated. Overall decision follows the stricter agent.";
		rule = "R2 · any Escalate → Escalate";
	} else {
		const avg = Math.floor(confidences.reduce((sum, n) => sum + n, 0) / confidences.length);
		if (avg >= settings.confidenceThreshold) {
			overall = "Approve";
			confidence = avg;
			reason = "Both specialists approved, and average confidence clears the threshold.";
			rule = `R3 · all Approve and confidence ≥ ${settings.confidenceThreshold}`;
		} else {
			overall = "Escalate";
			confidence = avg;
			reason = `Both specialists approved, but average confidence ${avg}% is under the ${settings.confidenceThreshold}% threshold.`;
			rule = `R4 · all Approve but confidence < ${settings.confidenceThreshold}`;
		}
	}
	const scoreHow = decisions.includes("Reject") || decisions.includes("Escalate") ? `min(${discount.confidence}, ${payment.confidence}) = ${Math.min(...confidences)}` : `floor((${discount.confidence} + ${payment.confidence}) / 2) = ${Math.floor((discount.confidence + payment.confidence) / 2)}`;
	const beforeGuard = confidence;
	const noteAttack = detectNoteAttack(quote.notes);
	if (discount.cited.length + payment.cited.length === 0) {
		overall = "Escalate";
		reason = "Output guardrail. Neither book cited a policy rule, so a person writes the stage.";
		rule = "G-OUT · no citation, hold";
	} else if (noteAttack && overall === "Approve") {
		overall = "Escalate";
		confidence = Math.min(confidence, settings.confidenceThreshold - 1);
		reason = "Output guardrail. The notes tried to steer an approval, so the quote is held even if the books were clean.";
		rule = "G-OUT · a note cannot produce Approve";
	}
	const confidenceFormula = beforeGuard === confidence ? `Orchestrator confidence = ${scoreHow}.` : `Orchestrator confidence = ${scoreHow}. The note cap is min(${beforeGuard}, ${settings.confidenceThreshold - 1}) = ${confidence}.`;
	const resultingStage = stageFor(overall);
	const assignment = assignCase(quote, discount, payment, overall, settings.assignmentRules?.length ? settings.assignmentRules : defaultAssignmentRules, totals.net);
	const writeback = writebackFor(overall, assignment);
	const actions = overall === "Approve" ? ["Seller can send the order form to the customer.", "Notify the seller that the approval agents approved the quote."] : [
		assignment ? `Assigned to: ${assignment.assignee} | SLA: ${assignment.slaHours}h | Reason: ${assignment.reason}` : "Route the quote to a person.",
		assignment ? `Queue: ${assignment.queue}.` : "",
		flags.length ? `Flags: ${flags.slice(0, 3).join(", ")}.` : ""
	].filter(Boolean);
	const audit = [
		`Orchestrator received ${quote.id} (${quote.type}) for ${quote.account.name}.`,
		"Discount agent and payment agent each called a policy tool. Quote notes were not an input.",
		`${discount.agentName} → ${discount.decision} (${discount.confidence}%).`,
		`${payment.agentName} → ${payment.decision} (${payment.confidence}%).`,
		`Orchestrator applied ${rule}.`,
		`Cited ${discountPolicy.policyId} and ${paymentPolicy.policyId}.`,
		`Final ${overall} at ${confidence}%. ${writeback}`
	];
	if (noteAttack) audit.push(`Notes tried to steer the agents ("${noteAttack}"). The agents did not follow them.`);
	if (assignment) audit.push(`Assigned to: ${assignment.assignee} | SLA: ${assignment.slaHours}h | Reason: ${assignment.reason} Resolves to ${assignment.externalId}.`);
	const beats = [
		{
			id: "receive",
			kind: "think",
			title: "Orchestrator planned the hop",
			body: `Read the quote through tools, ask the discount agent, ask the payment agent, then write one label. ${quote.id} · ${quote.type} · ${quote.account.name}.`
		},
		{
			id: "parallel",
			kind: "tool",
			title: "Agents called the policy tools",
			body: `Discount & Pricing loaded ${discountPolicy.policyId}. Payment Terms & Billing loaded ${paymentPolicy.policyId}. Notes stayed out of both calls.${noteAttack ? " A note tried to give an instruction and was flagged, not obeyed." : ""}`
		},
		{
			id: "aggregate",
			kind: "think",
			title: "Orchestrator combined the specialists",
			body: `${rule}. ${reason}`
		},
		{
			id: "write",
			kind: "write",
			title: "Stage write-back",
			body: writeback
		}
	];
	const engineMs = Math.max(1, Math.round(performance.now() - started));
	return {
		quoteId: quote.id,
		overallDecision: overall,
		overallConfidence: confidence,
		specialists: [discount, payment],
		consolidated: [
			reason,
			`${discount.agentName}: ${discount.comments}`,
			`${payment.agentName}: ${payment.comments}`
		],
		finalComments: `${overall} at ${confidence}% confidence. ${reason}`,
		audit,
		actions,
		beats,
		engineMs,
		threshold: settings.confidenceThreshold,
		rule,
		confidenceFormula,
		resultingStage,
		writeback,
		assignment,
		noteAttack,
		hop: "tools",
		model: null,
		inputTokens: 0,
		outputTokens: 0
	};
}
//#endregion
export { lineNet as a, pct as c, stageLabel as d, toPayload as f, formatWhen as i, quoteTotals as l, typeLabel as m, commercialFile as n, money as o, typeKey as p, formatDay as r, moneyExactFmt as s, assignCase as t, reviewQuote as u };
