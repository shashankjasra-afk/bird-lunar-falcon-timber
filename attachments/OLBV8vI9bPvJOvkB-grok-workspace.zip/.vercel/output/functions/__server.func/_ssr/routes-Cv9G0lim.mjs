import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as createServerFn } from "./ssr.mjs";
import { n as CATALOG } from "./policies-nD2AkcDb.mjs";
import { a as lineNet, c as pct, d as stageLabel, f as toPayload, i as formatWhen, l as quoteTotals, n as commercialFile, o as money, r as formatDay, s as moneyExactFmt } from "./engine-Av8XULO8.mjs";
import { t as createSsrRpc } from "./createSsrRpc-C1p7zOu_.mjs";
import { a as DecisionBadge, c as previewDecision, l as useDealflow, n as AgentTheater, o as Shell, r as AssignmentBanner, s as cn, t as AgentCard } from "./shell-5MLv66mP.mjs";
import { i as traceFromDecision, n as recordTraces, r as rememberTraces } from "./trace-row-Ct90qLEU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cv9G0lim.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STEPS = [
	{
		stage: "draft",
		label: "Draft"
	},
	{
		stage: "submitted",
		label: "Submit for approval"
	},
	{
		stage: "approved",
		label: "Approved"
	},
	{
		stage: "sent",
		label: "Sent to customer"
	},
	{
		stage: "signed",
		label: "Signed by customer"
	},
	{
		stage: "converted",
		label: "Converted"
	}
];
function pathIndex(stage) {
	if (stage === "rejected") return 1;
	const index = STEPS.findIndex((step) => step.stage === stage);
	return index === -1 ? 0 : index;
}
function QuotePath({ stage, hold = "none" }) {
	const current = pathIndex(stage);
	const caption = hold === "running" ? "Agents are writing the stage. Approve moves the quote to Approved. Escalate leaves it on Submit for approval for Deal Desk. Reject stops the path." : hold === "rejected" ? "Agents stopped this quote. It never reached Approved. The seller can revise and submit again." : hold === "desk" ? "Agents held this quote on Submit for approval. Deal Desk has to write the next stage." : "The seller presses Submit for approval. Agents write the next stage. Sending, signing, and converting stay with the seller.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "space-y-1 sm:hidden",
			"aria-label": "Quote stage",
			children: STEPS.map((step, index) => {
				const tone = toneFor(index, current, hold);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [index === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "my-1 rounded-md border border-teal bg-teal-soft px-3 py-2 text-xs font-semibold text-teal-deep",
					children: "Agents write this hop — Submit for approval to Approved"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-current": index === current ? "step" : void 0,
					className: cn("flex h-11 items-center rounded-md px-3 text-sm font-semibold", tone),
					children: step.label
				})] }, step.stage);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "hidden overflow-x-auto pb-1 sm:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex min-w-full",
				"aria-label": "Quote stage",
				children: STEPS.map((step, index) => {
					const tone = toneFor(index, current, hold);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						"aria-current": index === current ? "step" : void 0,
						className: cn("flex h-16 min-w-0 flex-1 items-center justify-center px-4 text-center text-sm font-semibold leading-tight", index === 0 ? "stage-chevron-first" : "stage-chevron -ml-2", tone),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "max-w-36",
							children: step.label
						})
					}, step.stage);
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 hidden sm:grid sm:grid-cols-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "col-span-2 col-start-2 rounded-md border border-teal bg-teal-soft px-2 py-2 text-center text-xs font-semibold text-teal-deep",
				children: "Agents write this hop"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-pretty text-muted",
			children: caption
		})
	] });
}
function toneFor(index, current, hold) {
	if (index === current && hold === "rejected") return "bg-rust text-paper";
	if (index === current && hold === "desk") return "bg-brass text-paper";
	if (index === current && hold === "running") return "stage-running bg-teal text-paper";
	if (index === current) return "bg-teal-deep text-paper";
	if (index < current) return "bg-teal text-paper";
	return "bg-paper-2 text-muted";
}
var runAgentHop = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("da851302270e64bdbfdf2a9b13f84b0844b069aa7435682d84b87a5d8a83d908"));
var DEMOS = [
	["Q-2026-1001", "Clean approve"],
	["Q-2026-1002", "Hard reject"],
	["Q-2026-1003", "Desk hold"],
	["Q-2026-1008", "Quarter-end"]
];
var STAGES = [
	"draft",
	"submitted",
	"approved",
	"sent",
	"signed",
	"converted",
	"rejected"
];
var TYPES = [
	"New",
	"Renewal",
	"Add-on",
	"Expansion"
];
var SEGMENTS = [
	"Enterprise",
	"Mid-Market",
	"SMB"
];
var TERMS = [
	"Due on Receipt",
	"Net-30",
	"Net-45",
	"Net-60",
	"Net-90"
];
var BILLING = [
	"Annual",
	"Multi-Year Prepay",
	"Quarterly",
	"Monthly"
];
var field = "h-11 w-full rounded-md border border-line bg-card px-3 text-sm text-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal";
var btn = "inline-flex h-11 items-center justify-center rounded-md px-4 text-sm font-semibold transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-50";
function stageChip(stage) {
	if (stage === "rejected") return "bg-rust-soft text-rust";
	if (stage === "submitted") return "bg-brass-soft text-brass";
	if (stage === "draft") return "bg-paper-2 text-ink-soft";
	return "bg-ok-soft text-ok";
}
function QuotesWorkspace() {
	const quotes = useDealflow((state) => state.quotes);
	const selectedId = useDealflow((state) => state.selectedId);
	const select = useDealflow((state) => state.select);
	const createDraft = useDealflow((state) => state.createDraft);
	const [query, setQuery] = (0, import_react.useState)("");
	const [stage, setStage] = (0, import_react.useState)("all");
	const [pane, setPane] = (0, import_react.useState)("list");
	const counts = (0, import_react.useMemo)(() => {
		const map = Object.fromEntries(STAGES.map((item) => [item, 0]));
		for (const quote of quotes) map[quote.stage] += 1;
		return map;
	}, [quotes]);
	const visible = quotes.filter((quote) => {
		const hay = `${quote.id} ${quote.account.name} ${quote.seller.name} ${quote.type}`.toLowerCase();
		if (query && !hay.includes(query.toLowerCase())) return false;
		if (stage !== "all" && quote.stage !== stage) return false;
		return true;
	});
	const selected = quotes.find((quote) => quote.id === selectedId) ?? visible[0] ?? quotes[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl text-ink",
					children: "Quotes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-sm text-pretty text-muted",
					children: "Select a quote. Submit for approval is the only step the agents write. Everything after Approved is the seller."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn(btn, "bg-card text-ink ring-1 ring-line"),
					onClick: () => {
						createDraft();
						setPane("detail");
					},
					children: "New draft"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				role: "tablist",
				"aria-label": "Golden quotes",
				children: DEMOS.map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn(btn, "shrink-0 bg-teal-soft text-teal-deep", selected?.id === id && "ring-2 ring-teal"),
					onClick: () => {
						select(id);
						setStage("all");
						setPane("detail");
					},
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7",
				children: STAGES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setStage(stage === item ? "all" : item),
					className: cn("rounded-lg border px-3 py-2 text-left", stage === item ? "border-teal bg-teal-soft" : "border-line bg-card"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: stageLabel(item)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl tabular-nums text-ink",
						children: counts[item]
					})]
				}, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[20rem_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: cn("min-w-0 space-y-3", pane === "detail" && "hidden lg:block"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: field,
						placeholder: "Search account, seller, quote",
						value: query,
						onChange: (event) => setQuery(event.target.value),
						"aria-label": "Search quotes"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "space-y-2",
						children: [visible.map((quote) => {
							const totals = quoteTotals(quote);
							const active = quote.id === selected?.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									select(quote.id);
									setPane("detail");
								},
								className: cn("w-full rounded-lg border px-3 py-3 text-left", active ? "border-teal bg-teal-soft" : "border-line bg-card"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold text-ink",
											children: quote.account.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: cn("shrink-0 rounded-full px-2 py-1 text-xs font-semibold", stageChip(quote.stage)),
											children: stageLabel(quote.stage)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-xs text-muted",
										children: [
											quote.id,
											" · ",
											quote.type,
											" · ",
											quote.seller.name
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-2 text-sm tabular-nums text-ink-soft",
										children: [
											money(totals.net),
											" net · ",
											pct(totals.discount),
											" off"
										]
									})
								]
							}) }, quote.id);
						}), visible.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm text-muted",
							children: "No quotes in this view."
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: cn("min-w-0", pane === "list" && "hidden lg:block"),
					children: selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteDetail, {
						quote: selected,
						onBack: () => setPane("list")
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Select a quote to open it."
					})
				})]
			})
		]
	});
}
function QuoteDetail({ quote, onBack }) {
	const updateQuote = useDealflow((state) => state.updateQuote);
	const updateAccount = useDealflow((state) => state.updateAccount);
	const updateLine = useDealflow((state) => state.updateLine);
	const addLine = useDealflow((state) => state.addLine);
	const removeLine = useDealflow((state) => state.removeLine);
	const commitDecision = useDealflow((state) => state.commitDecision);
	const advance = useDealflow((state) => state.advance);
	const revise = useDealflow((state) => state.revise);
	const [script, setScript] = (0, import_react.useState)(null);
	const [mode, setMode] = (0, import_react.useState)("preview");
	const [sku, setSku] = (0, import_react.useState)(CATALOG[0]?.sku ?? "");
	const [asking, setAsking] = (0, import_react.useState)(false);
	const [showReasoning, setShowReasoning] = (0, import_react.useState)(false);
	const committed = (0, import_react.useRef)(null);
	const totals = quoteTotals(quote);
	const editable = quote.stage === "draft";
	const running = Boolean(script && mode === "commit" && quote.stage === "draft");
	(0, import_react.useEffect)(() => {
		setScript(null);
		committed.current = null;
		setShowReasoning(false);
	}, [quote.id]);
	function start(next) {
		if (next === "preview") {
			committed.current = null;
			setMode(next);
			setScript(previewDecision(quote));
			return;
		}
		setAsking(true);
		const state = useDealflow.getState();
		runAgentHop({ data: {
			quote,
			discountPolicy: state.discountPolicy,
			paymentPolicy: state.paymentPolicy,
			settings: state.settings
		} }).then((result) => {
			committed.current = null;
			setMode("commit");
			setScript(result.decision);
		}).catch(() => {
			committed.current = null;
			setMode("commit");
			setScript(previewDecision(quote));
		}).finally(() => setAsking(false));
	}
	function finish() {
		if (mode !== "commit" || !script) return;
		const key = `${script.quoteId}:${script.rule}:${script.overallDecision}`;
		if (committed.current === key) return;
		committed.current = key;
		commitDecision(quote.id, script);
		const row = traceFromDecision(quote, script);
		recordTraces({ data: { rows: [row] } }).then((result) => rememberTraces(result, [row], useDealflow.getState().pushLangfuse)).catch(() => void 0);
	}
	const hold = running ? "running" : quote.stage === "rejected" ? "rejected" : quote.stage === "submitted" ? "desk" : "none";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-sm font-semibold text-teal lg:hidden",
				onClick: onBack,
				children: "Back to quotes"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-teal uppercase",
						children: quote.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl text-ink",
						children: quote.account.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-pretty text-muted",
						children: quote.scenario
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("inline-flex h-8 items-center self-start rounded-full px-3 text-xs font-semibold", stageChip(quote.stage)),
					children: stageLabel(quote.stage)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuotePath, {
				stage: running ? "submitted" : quote.stage,
				hold
			}),
			script && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentTheater, {
					decision: script,
					onDone: finish
				}, `${quote.id}-${mode}-${script.overallDecision}-${script.overallConfidence}`), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-sm font-semibold text-muted",
					onClick: () => setScript(null),
					children: "Close agent run"
				})]
			}),
			!script && quote.decision && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DecisionPanel, { quote }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Net",
						value: money(totals.net)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "List",
						value: money(totals.list)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Discount",
						value: pct(totals.discount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Terms",
						value: quote.paymentTerms
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 rounded-lg border border-line bg-card p-4 lg:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Account",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: field,
							disabled: !editable,
							value: quote.account.name,
							onChange: (event) => updateAccount(quote.id, { name: event.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Segment",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: field,
							disabled: !editable,
							value: quote.account.segment,
							onChange: (event) => updateAccount(quote.id, { segment: event.target.value }),
							children: SEGMENTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Region",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: field,
							disabled: !editable,
							value: quote.account.region,
							onChange: (event) => updateAccount(quote.id, { region: event.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Quote type",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: field,
							disabled: !editable,
							value: quote.type,
							onChange: (event) => updateQuote(quote.id, { type: event.target.value }),
							children: TYPES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Quote date",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: field,
							type: "date",
							disabled: !editable,
							value: quote.quoteDate,
							onChange: (event) => updateQuote(quote.id, { quoteDate: event.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Contract months",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: field,
							type: "number",
							min: 1,
							disabled: !editable,
							value: quote.contractMonths,
							onChange: (event) => updateQuote(quote.id, { contractMonths: Number(event.target.value) || 1 })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Payment terms",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: field,
							disabled: !editable,
							value: quote.paymentTerms,
							onChange: (event) => updateQuote(quote.id, { paymentTerms: event.target.value }),
							children: TERMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Billing",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: field,
							disabled: !editable,
							value: quote.billingFrequency,
							onChange: (event) => updateQuote(quote.id, { billingFrequency: event.target.value }),
							children: BILLING.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
							label: "Notes",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: "min-h-20 w-full rounded-md border border-line bg-card px-3 py-2 text-sm",
								disabled: !editable,
								value: quote.notes,
								onChange: (event) => updateQuote(quote.id, { notes: event.target.value })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-xs text-muted",
								children: "People can read this. The agents cannot use it as an instruction. Text pasted here cannot approve, reject, or escalate."
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted lg:col-span-2",
						children: [
							"Seller ",
							quote.seller.name,
							". Existing ACV",
							" ",
							quote.account.existingAcv == null ? "none" : money(quote.account.existingAcv),
							".",
							quote.historical ? ` Prior discount ${quote.historical.previousDiscountPct ?? "—"}%, prior terms ${quote.historical.previousPaymentTerms ?? "—"}.` : " No prior contract."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overflow-x-auto rounded-lg border border-line bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-max text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b border-line text-xs tracking-widest text-muted uppercase",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-semibold",
								children: "Product"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-semibold",
								children: "Qty"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-semibold",
								children: "List"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-semibold",
								children: "Discount"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-semibold",
								children: "Net"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-semibold",
								children: "Extended"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-3 py-3 font-semibold" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: quote.lineItems.map((item) => {
						const net = lineNet(item.listPrice, item.discountPct);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-line last:border-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3 font-medium",
									children: item.product
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "h-11 w-20 rounded-md border border-line bg-paper px-2 tabular-nums",
										type: "number",
										min: 1,
										disabled: !editable,
										value: item.quantity,
										"aria-label": `Quantity for ${item.product}`,
										onChange: (event) => updateLine(quote.id, item.id, { quantity: Math.max(1, Number(event.target.value) || 1) })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3 tabular-nums",
									children: moneyExactFmt(item.listPrice)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "h-11 w-20 rounded-md border border-line bg-paper px-2 tabular-nums",
										type: "number",
										min: 0,
										max: 90,
										disabled: !editable,
										value: item.discountPct,
										"aria-label": `Discount for ${item.product}`,
										onChange: (event) => updateLine(quote.id, item.id, { discountPct: Math.min(90, Math.max(0, Number(event.target.value) || 0)) })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3 tabular-nums",
									children: moneyExactFmt(net)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3 tabular-nums",
									children: money(net * item.quantity)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3 text-right",
									children: editable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "text-sm font-semibold text-rust",
										onClick: () => removeLine(quote.id, item.id),
										children: "Remove"
									})
								})
							]
						}, item.id);
					}) })]
				}), editable && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 border-t border-line p-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: field,
						value: sku,
						onChange: (event) => setSku(event.target.value),
						"aria-label": "Product to add",
						children: CATALOG.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: item.sku,
							children: [
								item.name,
								" · ",
								money(item.listPrice)
							]
						}, item.sku))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn(btn, "shrink-0 bg-paper-2 text-ink"),
						onClick: () => {
							const item = CATALOG.find((row) => row.sku === sku);
							if (!item) return;
							addLine(quote.id, {
								id: crypto.randomUUID(),
								product: item.name,
								quantity: 1,
								listPrice: item.listPrice,
								discountPct: 0
							});
						},
						children: "Add product"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row sm:flex-wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn(btn, "bg-card text-ink ring-1 ring-line"),
						"aria-expanded": showReasoning,
						onClick: () => setShowReasoning((open) => !open),
						children: showReasoning ? "Hide agent reasoning" : "Show agent reasoning"
					}),
					editable && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn(btn, "bg-card text-ink ring-1 ring-line"),
						onClick: () => start("preview"),
						children: "Preview the book"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn(btn, "bg-teal text-paper"),
						onClick: () => start("commit"),
						disabled: running || asking,
						children: asking ? "Agents are thinking…" : "Submit for approval"
					})] }),
					quote.stage === "rejected" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn(btn, "bg-teal text-paper"),
						onClick: () => revise(quote.id),
						children: "Revise quote"
					}),
					quote.stage === "approved" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn(btn, "bg-teal text-paper"),
						onClick: () => advance(quote.id),
						children: "Send to customer"
					}),
					quote.stage === "sent" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn(btn, "bg-teal text-paper"),
						onClick: () => advance(quote.id),
						children: "Mark signed by customer"
					}),
					quote.stage === "signed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn(btn, "bg-teal text-paper"),
						onClick: () => advance(quote.id),
						children: "Convert to subscription"
					}),
					quote.stage === "submitted" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/desk",
						className: cn(btn, "bg-brass text-paper"),
						children: "Open in Deal Desk"
					}),
					quote.stage === "converted" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "self-center text-sm text-ok",
						children: "Subscription is live. Agents cleared this before it was sent."
					})
				]
			}),
			showReasoning && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReasoningPanel, { quote }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "rounded-lg border border-line bg-card p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer font-semibold",
						children: "Quote payload and stage history"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-3 space-y-2",
						children: quote.stageHistory.map((event, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: stageLabel(event.stage)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: [
									" · ",
									event.by,
									" · ",
									formatWhen(event.at)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-ink-soft",
								children: event.note
							})
						] }, `${event.at}-${event.stage}-${index}`))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-4 overflow-x-auto rounded-md bg-paper p-3 text-xs leading-relaxed text-ink-soft",
						children: JSON.stringify(toPayload(quote), null, 2)
					})
				]
			})
		]
	});
}
function ReasoningPanel({ quote }) {
	const discountPolicy = useDealflow((state) => state.discountPolicy);
	const paymentPolicy = useDealflow((state) => state.paymentPolicy);
	const decision = previewDecision(quote);
	const file = commercialFile(quote);
	const sources = [
		`${discountPolicy.policyName} ${discountPolicy.version} (${discountPolicy.policyId}), owned by ${discountPolicy.owner}`,
		`${paymentPolicy.policyName} ${paymentPolicy.version} (${paymentPolicy.policyId}), owned by ${paymentPolicy.owner}`,
		file.years.length ? `Closed discount years: ${file.years.map((year) => year.year).join(", ")}` : "No installed discount. Peer new-logo deals are the comparison set.",
		file.credit ? file.credit.band === "Unscored" ? "Credit application. No invoices, so no dues file." : `Receivables file: ${file.credit.band}, overdue ${money(file.credit.overdue)}` : "No credit file",
		file.contracts.length ? `Contracts: ${file.contracts.map((row) => row.name).join(", ")}` : "No multi-year contract on file",
		"Quote notes are visible to people. They are not a data source for the label."
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-line bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl text-ink",
						children: "Data sources"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2 text-sm text-ink-soft",
						children: sources.map((source) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-l-2 border-teal pl-3",
							children: source
						}, source))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm text-ink",
						children: [
							"Orchestrator: ",
							decision.rule,
							". ",
							decision.overallDecision,
							" at ",
							decision.overallConfidence,
							"%."
						]
					}),
					decision.confidenceFormula && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-pretty text-ink",
						children: decision.confidenceFormula
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiscountDossier, { quote }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 lg:grid-cols-2",
				children: decision.specialists.map((agent) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentCard, {
					agent,
					open: true
				}, agent.agentName))
			})
		]
	});
}
function DiscountDossier({ quote }) {
	const file = commercialFile(quote);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-4 rounded-lg border border-teal bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-teal uppercase",
					children: "Discount & Pricing · looked this up"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-1 font-display text-2xl text-ink",
					children: file.posture
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-pretty text-ink-soft",
					children: file.discountLook
				})
			] }),
			file.years.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-x-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-muted uppercase",
					children: "Historical discounts"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "mt-2 w-full min-w-max text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-xs text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 pr-3 font-semibold",
								children: "Year"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 pr-3 font-semibold",
								children: "Discount"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 pr-3 font-semibold",
								children: "Terms"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 pr-3 font-semibold",
								children: "Billing"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 font-semibold",
								children: "ACV"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: file.years.map((year) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 pr-3",
								children: year.year
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 pr-3 tabular-nums",
								children: pct(year.discountPct)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 pr-3",
								children: year.terms
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 pr-3",
								children: year.billing
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 tabular-nums",
								children: money(year.acv)
							})
						]
					}, year.year)) })]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-widest text-muted uppercase",
				children: "No installed discount · peer new logos"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 space-y-1 text-sm text-ink-soft",
				children: file.peers.map((peer) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					peer.name,
					" · ",
					pct(peer.discountPct),
					" · ",
					peer.note
				] }, peer.name))
			})] }),
			file.credit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-muted uppercase",
					children: file.credit.band === "Unscored" ? "Credit · new business" : "Credit and dues"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-ink",
					children: [file.credit.band, file.credit.band !== "Unscored" && ` · on time ${file.credit.onTimePct}% · DSO ${file.credit.dso} days · overdue ${money(file.credit.overdue)}`]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-ink-soft",
					children: file.credit.note
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-widest text-muted uppercase",
				children: "Multi-year contracts"
			}), file.contracts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-ink-soft",
				children: "None. This is not a multi-year relationship yet."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 space-y-1 text-sm text-ink-soft",
				children: file.contracts.map((contract) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					contract.name,
					" · ",
					contract.term,
					" · ",
					pct(contract.discountPct),
					" · ",
					contract.status
				] }, contract.name))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border-l-2 border-teal pl-3 text-sm text-ink-soft",
				children: file.cashLook
			})
		]
	});
}
function DecisionPanel({ quote }) {
	const decision = quote.decision;
	if (!decision) return null;
	const human = quote.humanActions.at(-1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl text-ink",
						children: "Latest decision"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DecisionBadge, { decision: decision.overallDecision }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted tabular-nums",
						children: [
							decision.overallConfidence,
							"% · ",
							decision.engineMs,
							" ms"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-pretty text-ink-soft",
				children: decision.finalComments
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink",
				children: decision.rule
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssignmentBanner, { assignment: decision.assignment }),
			decision.noteAttack && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-md border border-rust bg-rust-soft px-3 py-3 text-sm text-ink",
				children: [
					"Notes tried to steer the agents: “",
					decision.noteAttack,
					"” They did not follow it. The label comes from the book and the guardrail."
				]
			}),
			human && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-md bg-paper-2 px-3 py-2 text-sm text-ink-soft",
				children: [
					human.actor,
					" ",
					human.action === "approve" ? "approved" : human.action === "reject" ? "rejected" : "returned",
					" this after the agents. ",
					human.comment
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 lg:grid-cols-2",
				children: decision.specialists.map((agent) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentCard, {
					agent,
					open: false
				}, agent.agentName))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer font-semibold text-teal",
						children: "Audit trail"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-1 text-ink-soft",
						children: decision.audit.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
					}),
					quote.quoteDate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted",
						children: [
							"Policy date on the quote: ",
							formatDay(quote.quoteDate),
							"."
						]
					})
				]
			})
		]
	});
}
function Metric({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-card px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs tracking-widest text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-display text-2xl tabular-nums text-ink",
			children: value
		})]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-xs font-semibold tracking-widest text-muted uppercase",
			children: label
		}), children]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuotesWorkspace, {}) });
}
//#endregion
export { Home as component };
