import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as pct, d as stageLabel, i as formatWhen, l as quoteTotals, o as money } from "./engine-Av8XULO8.mjs";
import { a as DecisionBadge, i as DESK_LEAD, l as useDealflow, o as Shell, r as AssignmentBanner, s as cn, t as AgentCard } from "./shell-5MLv66mP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desk-Bx6pAfyC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		id: "desk",
		label: "Needs a person"
	},
	{
		id: "approved",
		label: "Approved by agents"
	},
	{
		id: "rejected",
		label: "Rejected by agents"
	},
	{
		id: "later",
		label: "Sent, signed, converted"
	}
];
function inTab(quote, tab) {
	if (tab === "desk") return quote.stage === "submitted";
	if (tab === "approved") return quote.stage === "approved";
	if (tab === "rejected") return quote.stage === "rejected";
	return quote.stage === "sent" || quote.stage === "signed" || quote.stage === "converted";
}
function companyPulse(quotes) {
	const reviewed = quotes.filter((quote) => quote.decision);
	const sum = reviewed.reduce((total, quote) => total + (quote.decision?.engineMs ?? 0), 0);
	return {
		reviewed: reviewed.length,
		approved: reviewed.filter((quote) => quote.decision?.overallDecision === "Approve").length,
		escalated: reviewed.filter((quote) => quote.decision?.overallDecision === "Escalate").length,
		rejected: reviewed.filter((quote) => quote.decision?.overallDecision === "Reject").length,
		human: quotes.filter((quote) => quote.humanActions.length > 0).length,
		avgMs: reviewed.length ? Math.round(sum / reviewed.length) : 0
	};
}
var btn = "inline-flex h-11 items-center justify-center rounded-md px-4 text-sm font-semibold transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-50";
function DeskWorkspace() {
	const quotes = useDealflow((state) => state.quotes);
	const humanDecide = useDealflow((state) => state.humanDecide);
	const select = useDealflow((state) => state.select);
	const navigate = useNavigate();
	const [tab, setTab] = (0, import_react.useState)("desk");
	const [activeId, setActiveId] = (0, import_react.useState)("Q-2026-1013");
	const [comment, setComment] = (0, import_react.useState)("Terms are acceptable for this account. Approving the cash exception.");
	const rows = quotes.filter((quote) => inTab(quote, tab));
	const active = rows.find((quote) => quote.id === activeId) ?? rows[0];
	const pulse = companyPulse(quotes);
	const writes = quotes.filter((quote) => quote.decision).slice().sort((a, b) => (b.submittedAt ?? "").localeCompare(a.submittedAt ?? ""));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl text-ink",
				children: "Approvals"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 max-w-2xl text-sm text-pretty text-muted",
				children: [
					"What ",
					DESK_LEAD,
					" and the rest of the company see after agents write a stage. Auto-approvals never enter a human queue. Escalations do."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pulse, {
						label: "Reviewed",
						value: String(pulse.reviewed)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pulse, {
						label: "Agent approved",
						value: String(pulse.approved)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pulse, {
						label: "Held for desk",
						value: String(pulse.escalated)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pulse, {
						label: "Agent rejected",
						value: String(pulse.rejected)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pulse, {
						label: "Human actions",
						value: String(pulse.human)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pulse, {
						label: "Avg engine",
						value: `${pulse.avgMs} ms`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				role: "tablist",
				"aria-label": "Approval queue",
				children: TABS.map((item) => {
					const count = quotes.filter((quote) => inTab(quote, item.id)).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: cn(btn, "touch-manipulation", tab === item.id ? "bg-teal text-paper" : "bg-card text-ink ring-1 ring-line"),
						onClick: () => setTab(item.id),
						children: [
							item.label,
							" · ",
							count
						]
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[18rem_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-2",
					children: [rows.map((quote) => {
						const totals = quoteTotals(quote);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setActiveId(quote.id),
							className: cn("w-full rounded-lg border px-3 py-3 text-left", active?.id === quote.id ? "border-teal bg-teal-soft" : "border-line bg-card"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: quote.account.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										quote.id,
										" · ",
										stageLabel(quote.stage)
									]
								}),
								quote.decision?.assignment && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-xs font-semibold text-brass",
									children: [
										quote.decision.assignment.assignee,
										" · ",
										quote.decision.assignment.slaHours,
										"h"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm tabular-nums text-ink-soft",
									children: [
										money(totals.net),
										" · ",
										pct(totals.discount)
									]
								})
							]
						}) }, quote.id);
					}), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm text-muted",
						children: "Nothing in this queue."
					})]
				}), active?.decision ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold tracking-widest text-teal uppercase",
									children: active.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-3xl",
									children: active.account.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted",
									children: [
										active.type,
										" · ",
										active.seller.name,
										" · ",
										active.paymentTerms,
										" · ",
										active.billingFrequency
									]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DecisionBadge, { decision: active.decision.overallDecision })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-pretty text-ink-soft",
							children: active.decision.finalComments
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssignmentBanner, { assignment: active.decision.assignment }),
						active.decision.noteAttack && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "rounded-md border border-rust bg-rust-soft px-3 py-3 text-sm text-ink",
							children: [
								"Notes tried to steer the agents: “",
								active.decision.noteAttack,
								"” They did not follow it."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-3 lg:grid-cols-2",
							children: active.decision.specialists.map((agent) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentCard, { agent }, agent.agentName))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-1 text-sm text-ink-soft",
							children: active.decision.actions.map((action) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: action }, action))
						}),
						tab === "desk" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "space-y-3 rounded-lg border border-line bg-card p-4",
							onSubmit: (event) => {
								event.preventDefault();
								humanDecide(active.id, "approve", comment);
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold",
									children: active.decision.assignment ? `Decision on the ${active.decision.assignment.assignee} queue` : "Deal Desk decision"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-1 block text-xs font-semibold tracking-widest text-muted uppercase",
										children: "Note"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										className: "min-h-20 w-full rounded-md border border-line bg-paper px-3 py-2",
										value: comment,
										onChange: (event) => setComment(event.target.value)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-2 sm:flex-row",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "submit",
											className: cn(btn, "bg-teal text-paper"),
											children: "Approve override"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: cn(btn, "bg-rust text-paper"),
											onClick: () => humanDecide(active.id, "reject", comment),
											children: "Reject"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: cn(btn, "bg-card text-ink ring-1 ring-line"),
											onClick: () => humanDecide(active.id, "return", comment),
											children: "Return to seller"
										})
									]
								})
							]
						}),
						active.humanActions.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2 text-sm",
							children: active.humanActions.map((action) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-md bg-paper-2 px-3 py-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: action.actor
									}),
									" ",
									action.action,
									" · ",
									formatWhen(action.at),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: action.comment })
								]
							}, action.at))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-sm font-semibold text-teal",
							onClick: () => {
								select(active.id);
								navigate({ to: "/" });
							},
							children: "Open the quote record"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Select a quote that agents have already reviewed."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "overflow-x-auto rounded-lg border border-line bg-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-max text-left text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("caption", {
							className: "px-3 py-3 text-left text-xs font-semibold tracking-widest text-muted uppercase",
							children: "Agent write-backs on the book"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-b border-line text-xs tracking-widest text-muted uppercase",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-semibold",
									children: "Quote"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-semibold",
									children: "Account"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-semibold",
									children: "Agents"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-semibold",
									children: "Stage now"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-semibold",
									children: "Written by"
								})
							] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [writes.map((quote) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-line last:border-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3 font-medium",
									children: quote.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3",
									children: quote.account.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3",
									children: quote.decision ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DecisionBadge, { decision: quote.decision.overallDecision }) : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3",
									children: stageLabel(quote.stage)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3 text-ink-soft",
									children: "DealFlow Orchestrator"
								})
							]
						}, quote.id)), writes.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-3 text-muted",
							colSpan: 5,
							children: "No agent write-backs yet. Submit a draft from Quotes."
						}) })] })
					]
				})
			})
		]
	});
}
function Pulse({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-card px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs tracking-widest text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-display text-2xl tabular-nums text-ink",
			children: value
		})]
	});
}
function DeskPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskWorkspace, {}) });
}
//#endregion
export { DeskPage as component };
