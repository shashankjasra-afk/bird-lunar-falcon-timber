import { o as __toESM, t as __commonJSMin } from "../../_runtime.mjs";
//#region node_modules/@opentelemetry/api/build/src/version.js
var require_version = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.VERSION = void 0;
	exports.VERSION = "1.9.1";
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/internal/semver.js
var require_semver = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isCompatible = exports._makeCompatibilityCheck = void 0;
	var version_1 = require_version();
	var re = /^(\d+)\.(\d+)\.(\d+)(-(.+))?$/;
	/**
	* Create a function to test an API version to see if it is compatible with the provided ownVersion.
	*
	* The returned function has the following semantics:
	* - Exact match is always compatible
	* - Major versions must match exactly
	*    - 1.x package cannot use global 2.x package
	*    - 2.x package cannot use global 1.x package
	* - The minor version of the API module requesting access to the global API must be less than or equal to the minor version of this API
	*    - 1.3 package may use 1.4 global because the later global contains all functions 1.3 expects
	*    - 1.4 package may NOT use 1.3 global because it may try to call functions which don't exist on 1.3
	* - If the major version is 0, the minor version is treated as the major and the patch is treated as the minor
	* - Patch and build tag differences are not considered at this time
	*
	* @param ownVersion version which should be checked against
	*/
	function _makeCompatibilityCheck(ownVersion) {
		const acceptedVersions = /* @__PURE__ */ new Set([ownVersion]);
		const rejectedVersions = /* @__PURE__ */ new Set();
		const myVersionMatch = ownVersion.match(re);
		if (!myVersionMatch) return () => false;
		const ownVersionParsed = {
			major: +myVersionMatch[1],
			minor: +myVersionMatch[2],
			patch: +myVersionMatch[3],
			prerelease: myVersionMatch[4]
		};
		if (ownVersionParsed.prerelease != null) return function isExactmatch(globalVersion) {
			return globalVersion === ownVersion;
		};
		function _reject(v) {
			rejectedVersions.add(v);
			return false;
		}
		function _accept(v) {
			acceptedVersions.add(v);
			return true;
		}
		return function isCompatible(globalVersion) {
			if (acceptedVersions.has(globalVersion)) return true;
			if (rejectedVersions.has(globalVersion)) return false;
			const globalVersionMatch = globalVersion.match(re);
			if (!globalVersionMatch) return _reject(globalVersion);
			const globalVersionParsed = {
				major: +globalVersionMatch[1],
				minor: +globalVersionMatch[2],
				patch: +globalVersionMatch[3],
				prerelease: globalVersionMatch[4]
			};
			if (globalVersionParsed.prerelease != null) return _reject(globalVersion);
			if (ownVersionParsed.major !== globalVersionParsed.major) return _reject(globalVersion);
			if (ownVersionParsed.major === 0) {
				if (ownVersionParsed.minor === globalVersionParsed.minor && ownVersionParsed.patch <= globalVersionParsed.patch) return _accept(globalVersion);
				return _reject(globalVersion);
			}
			if (ownVersionParsed.minor <= globalVersionParsed.minor) return _accept(globalVersion);
			return _reject(globalVersion);
		};
	}
	exports._makeCompatibilityCheck = _makeCompatibilityCheck;
	/**
	* Test an API version to see if it is compatible with this API.
	*
	* - Exact match is always compatible
	* - Major versions must match exactly
	*    - 1.x package cannot use global 2.x package
	*    - 2.x package cannot use global 1.x package
	* - The minor version of the API module requesting access to the global API must be less than or equal to the minor version of this API
	*    - 1.3 package may use 1.4 global because the later global contains all functions 1.3 expects
	*    - 1.4 package may NOT use 1.3 global because it may try to call functions which don't exist on 1.3
	* - If the major version is 0, the minor version is treated as the major and the patch is treated as the minor
	* - Patch and build tag differences are not considered at this time
	*
	* @param version version of the API requesting an instance of the global API
	*/
	exports.isCompatible = _makeCompatibilityCheck(version_1.VERSION);
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/internal/global-utils.js
var require_global_utils = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.unregisterGlobal = exports.getGlobal = exports.registerGlobal = void 0;
	var version_1 = require_version();
	var semver_1 = require_semver();
	var major = version_1.VERSION.split(".")[0];
	var GLOBAL_OPENTELEMETRY_API_KEY = Symbol.for(`opentelemetry.js.api.${major}`);
	var _global = typeof globalThis === "object" ? globalThis : typeof self === "object" ? self : typeof window === "object" ? window : typeof global === "object" ? global : {};
	function registerGlobal(type, instance, diag, allowOverride = false) {
		var _a;
		const api = _global[GLOBAL_OPENTELEMETRY_API_KEY] = (_a = _global[GLOBAL_OPENTELEMETRY_API_KEY]) !== null && _a !== void 0 ? _a : { version: version_1.VERSION };
		if (!allowOverride && api[type]) {
			const err = /* @__PURE__ */ new Error(`@opentelemetry/api: Attempted duplicate registration of API: ${type}`);
			diag.error(err.stack || err.message);
			return false;
		}
		if (api.version !== version_1.VERSION) {
			const err = /* @__PURE__ */ new Error(`@opentelemetry/api: Registration of version v${api.version} for ${type} does not match previously registered API v${version_1.VERSION}`);
			diag.error(err.stack || err.message);
			return false;
		}
		api[type] = instance;
		diag.debug(`@opentelemetry/api: Registered a global for ${type} v${version_1.VERSION}.`);
		return true;
	}
	exports.registerGlobal = registerGlobal;
	function getGlobal(type) {
		var _a, _b;
		const globalVersion = (_a = _global[GLOBAL_OPENTELEMETRY_API_KEY]) === null || _a === void 0 ? void 0 : _a.version;
		if (!globalVersion || !(0, semver_1.isCompatible)(globalVersion)) return;
		return (_b = _global[GLOBAL_OPENTELEMETRY_API_KEY]) === null || _b === void 0 ? void 0 : _b[type];
	}
	exports.getGlobal = getGlobal;
	function unregisterGlobal(type, diag) {
		diag.debug(`@opentelemetry/api: Unregistering a global for ${type} v${version_1.VERSION}.`);
		const api = _global[GLOBAL_OPENTELEMETRY_API_KEY];
		if (api) delete api[type];
	}
	exports.unregisterGlobal = unregisterGlobal;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/diag/ComponentLogger.js
var require_ComponentLogger = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.DiagComponentLogger = void 0;
	var global_utils_1 = require_global_utils();
	/**
	* Component Logger which is meant to be used as part of any component which
	* will add automatically additional namespace in front of the log message.
	* It will then forward all message to global diag logger
	* @example
	* const cLogger = diag.createComponentLogger({ namespace: '@opentelemetry/instrumentation-http' });
	* cLogger.debug('test');
	* // @opentelemetry/instrumentation-http test
	*/
	var DiagComponentLogger = class {
		constructor(props) {
			this._namespace = props.namespace || "DiagComponentLogger";
		}
		debug(...args) {
			return logProxy("debug", this._namespace, args);
		}
		error(...args) {
			return logProxy("error", this._namespace, args);
		}
		info(...args) {
			return logProxy("info", this._namespace, args);
		}
		warn(...args) {
			return logProxy("warn", this._namespace, args);
		}
		verbose(...args) {
			return logProxy("verbose", this._namespace, args);
		}
	};
	exports.DiagComponentLogger = DiagComponentLogger;
	function logProxy(funcName, namespace, args) {
		const logger = (0, global_utils_1.getGlobal)("diag");
		if (!logger) return;
		return logger[funcName](namespace, ...args);
	}
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/diag/types.js
var require_types = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.DiagLogLevel = void 0;
	(function(DiagLogLevel) {
		/** Diagnostic Logging level setting to disable all logging (except and forced logs) */
		DiagLogLevel[DiagLogLevel["NONE"] = 0] = "NONE";
		/** Identifies an error scenario */
		DiagLogLevel[DiagLogLevel["ERROR"] = 30] = "ERROR";
		/** Identifies a warning scenario */
		DiagLogLevel[DiagLogLevel["WARN"] = 50] = "WARN";
		/** General informational log message */
		DiagLogLevel[DiagLogLevel["INFO"] = 60] = "INFO";
		/** General debug log message */
		DiagLogLevel[DiagLogLevel["DEBUG"] = 70] = "DEBUG";
		/**
		* Detailed trace level logging should only be used for development, should only be set
		* in a development environment.
		*/
		DiagLogLevel[DiagLogLevel["VERBOSE"] = 80] = "VERBOSE";
		/** Used to set the logging level to include all logging */
		DiagLogLevel[DiagLogLevel["ALL"] = 9999] = "ALL";
	})(exports.DiagLogLevel || (exports.DiagLogLevel = {}));
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/diag/internal/logLevelLogger.js
var require_logLevelLogger = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.createLogLevelDiagLogger = void 0;
	var types_1 = require_types();
	function createLogLevelDiagLogger(maxLevel, logger) {
		if (maxLevel < types_1.DiagLogLevel.NONE) maxLevel = types_1.DiagLogLevel.NONE;
		else if (maxLevel > types_1.DiagLogLevel.ALL) maxLevel = types_1.DiagLogLevel.ALL;
		logger = logger || {};
		function _filterFunc(funcName, theLevel) {
			const theFunc = logger[funcName];
			if (typeof theFunc === "function" && maxLevel >= theLevel) return theFunc.bind(logger);
			return function() {};
		}
		return {
			error: _filterFunc("error", types_1.DiagLogLevel.ERROR),
			warn: _filterFunc("warn", types_1.DiagLogLevel.WARN),
			info: _filterFunc("info", types_1.DiagLogLevel.INFO),
			debug: _filterFunc("debug", types_1.DiagLogLevel.DEBUG),
			verbose: _filterFunc("verbose", types_1.DiagLogLevel.VERBOSE)
		};
	}
	exports.createLogLevelDiagLogger = createLogLevelDiagLogger;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/api/diag.js
var require_diag = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.DiagAPI = void 0;
	var ComponentLogger_1 = require_ComponentLogger();
	var logLevelLogger_1 = require_logLevelLogger();
	var types_1 = require_types();
	var global_utils_1 = require_global_utils();
	var API_NAME = "diag";
	exports.DiagAPI = class DiagAPI {
		/** Get the singleton instance of the DiagAPI API */
		static instance() {
			if (!this._instance) this._instance = new DiagAPI();
			return this._instance;
		}
		/**
		* Private internal constructor
		* @private
		*/
		constructor() {
			function _logProxy(funcName) {
				return function(...args) {
					const logger = (0, global_utils_1.getGlobal)("diag");
					if (!logger) return;
					return logger[funcName](...args);
				};
			}
			const self = this;
			const setLogger = (logger, optionsOrLogLevel = { logLevel: types_1.DiagLogLevel.INFO }) => {
				var _a, _b, _c;
				if (logger === self) {
					const err = /* @__PURE__ */ new Error("Cannot use diag as the logger for itself. Please use a DiagLogger implementation like ConsoleDiagLogger or a custom implementation");
					self.error((_a = err.stack) !== null && _a !== void 0 ? _a : err.message);
					return false;
				}
				if (typeof optionsOrLogLevel === "number") optionsOrLogLevel = { logLevel: optionsOrLogLevel };
				const oldLogger = (0, global_utils_1.getGlobal)("diag");
				const newLogger = (0, logLevelLogger_1.createLogLevelDiagLogger)((_b = optionsOrLogLevel.logLevel) !== null && _b !== void 0 ? _b : types_1.DiagLogLevel.INFO, logger);
				if (oldLogger && !optionsOrLogLevel.suppressOverrideMessage) {
					const stack = (_c = (/* @__PURE__ */ new Error()).stack) !== null && _c !== void 0 ? _c : "<failed to generate stacktrace>";
					oldLogger.warn(`Current logger will be overwritten from ${stack}`);
					newLogger.warn(`Current logger will overwrite one already registered from ${stack}`);
				}
				return (0, global_utils_1.registerGlobal)("diag", newLogger, self, true);
			};
			self.setLogger = setLogger;
			self.disable = () => {
				(0, global_utils_1.unregisterGlobal)(API_NAME, self);
			};
			self.createComponentLogger = (options) => {
				return new ComponentLogger_1.DiagComponentLogger(options);
			};
			self.verbose = _logProxy("verbose");
			self.debug = _logProxy("debug");
			self.info = _logProxy("info");
			self.warn = _logProxy("warn");
			self.error = _logProxy("error");
		}
	};
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/baggage/internal/baggage-impl.js
var require_baggage_impl = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.BaggageImpl = void 0;
	exports.BaggageImpl = class BaggageImpl {
		constructor(entries) {
			this._entries = entries ? new Map(entries) : /* @__PURE__ */ new Map();
		}
		getEntry(key) {
			const entry = this._entries.get(key);
			if (!entry) return;
			return Object.assign({}, entry);
		}
		getAllEntries() {
			return Array.from(this._entries.entries());
		}
		setEntry(key, entry) {
			const newBaggage = new BaggageImpl(this._entries);
			newBaggage._entries.set(key, entry);
			return newBaggage;
		}
		removeEntry(key) {
			const newBaggage = new BaggageImpl(this._entries);
			newBaggage._entries.delete(key);
			return newBaggage;
		}
		removeEntries(...keys) {
			const newBaggage = new BaggageImpl(this._entries);
			for (const key of keys) newBaggage._entries.delete(key);
			return newBaggage;
		}
		clear() {
			return new BaggageImpl();
		}
	};
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/baggage/internal/symbol.js
var require_symbol = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.baggageEntryMetadataSymbol = void 0;
	/**
	* Symbol used to make BaggageEntryMetadata an opaque type
	*/
	exports.baggageEntryMetadataSymbol = Symbol("BaggageEntryMetadata");
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/baggage/utils.js
var require_utils$1 = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.baggageEntryMetadataFromString = exports.createBaggage = void 0;
	var diag_1 = require_diag();
	var baggage_impl_1 = require_baggage_impl();
	var symbol_1 = require_symbol();
	var diag = diag_1.DiagAPI.instance();
	/**
	* Create a new Baggage with optional entries
	*
	* @param entries An array of baggage entries the new baggage should contain
	*/
	function createBaggage(entries = {}) {
		return new baggage_impl_1.BaggageImpl(new Map(Object.entries(entries)));
	}
	exports.createBaggage = createBaggage;
	/**
	* Create a serializable BaggageEntryMetadata object from a string.
	*
	* @param str string metadata. Format is currently not defined by the spec and has no special meaning.
	*
	* @since 1.0.0
	*/
	function baggageEntryMetadataFromString(str) {
		if (typeof str !== "string") {
			diag.error(`Cannot create baggage metadata from unknown type: ${typeof str}`);
			str = "";
		}
		return {
			__TYPE__: symbol_1.baggageEntryMetadataSymbol,
			toString() {
				return str;
			}
		};
	}
	exports.baggageEntryMetadataFromString = baggageEntryMetadataFromString;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/context/context.js
var require_context$1 = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ROOT_CONTEXT = exports.createContextKey = void 0;
	/**
	* Get a key to uniquely identify a context value
	*
	* @since 1.0.0
	*/
	function createContextKey(description) {
		return Symbol.for(description);
	}
	exports.createContextKey = createContextKey;
	/**
	* The root context is used as the default parent context when there is no active context
	*
	* @since 1.0.0
	*/
	exports.ROOT_CONTEXT = new class BaseContext {
		/**
		* Construct a new context which inherits values from an optional parent context.
		*
		* @param parentContext a context from which to inherit values
		*/
		constructor(parentContext) {
			const self = this;
			self._currentContext = parentContext ? new Map(parentContext) : /* @__PURE__ */ new Map();
			self.getValue = (key) => self._currentContext.get(key);
			self.setValue = (key, value) => {
				const context = new BaseContext(self._currentContext);
				context._currentContext.set(key, value);
				return context;
			};
			self.deleteValue = (key) => {
				const context = new BaseContext(self._currentContext);
				context._currentContext.delete(key);
				return context;
			};
		}
	}();
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/diag/consoleLogger.js
var require_consoleLogger = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.DiagConsoleLogger = exports._originalConsoleMethods = void 0;
	var consoleMap = [
		{
			n: "error",
			c: "error"
		},
		{
			n: "warn",
			c: "warn"
		},
		{
			n: "info",
			c: "info"
		},
		{
			n: "debug",
			c: "debug"
		},
		{
			n: "verbose",
			c: "trace"
		}
	];
	exports._originalConsoleMethods = {};
	if (typeof console !== "undefined") {
		for (const key of [
			"error",
			"warn",
			"info",
			"debug",
			"trace",
			"log"
		]) if (typeof console[key] === "function") exports._originalConsoleMethods[key] = console[key];
	}
	/**
	* A simple Immutable Console based diagnostic logger which will output any messages to the Console.
	* If you want to limit the amount of logging to a specific level or lower use the
	* {@link createLogLevelDiagLogger}
	*
	* @since 1.0.0
	*/
	var DiagConsoleLogger = class {
		constructor() {
			function _consoleFunc(funcName) {
				return function(...args) {
					let theFunc = exports._originalConsoleMethods[funcName];
					if (typeof theFunc !== "function") theFunc = exports._originalConsoleMethods["log"];
					if (typeof theFunc !== "function" && console) {
						theFunc = console[funcName];
						if (typeof theFunc !== "function") theFunc = console.log;
					}
					if (typeof theFunc === "function") return theFunc.apply(console, args);
				};
			}
			for (let i = 0; i < consoleMap.length; i++) this[consoleMap[i].n] = _consoleFunc(consoleMap[i].c);
		}
	};
	exports.DiagConsoleLogger = DiagConsoleLogger;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/metrics/NoopMeter.js
var require_NoopMeter = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.createNoopMeter = exports.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = exports.NOOP_OBSERVABLE_GAUGE_METRIC = exports.NOOP_OBSERVABLE_COUNTER_METRIC = exports.NOOP_UP_DOWN_COUNTER_METRIC = exports.NOOP_HISTOGRAM_METRIC = exports.NOOP_GAUGE_METRIC = exports.NOOP_COUNTER_METRIC = exports.NOOP_METER = exports.NoopObservableUpDownCounterMetric = exports.NoopObservableGaugeMetric = exports.NoopObservableCounterMetric = exports.NoopObservableMetric = exports.NoopHistogramMetric = exports.NoopGaugeMetric = exports.NoopUpDownCounterMetric = exports.NoopCounterMetric = exports.NoopMetric = exports.NoopMeter = void 0;
	/**
	* NoopMeter is a noop implementation of the {@link Meter} interface. It reuses
	* constant NoopMetrics for all of its methods.
	*/
	var NoopMeter = class {
		constructor() {}
		/**
		* @see {@link Meter.createGauge}
		*/
		createGauge(_name, _options) {
			return exports.NOOP_GAUGE_METRIC;
		}
		/**
		* @see {@link Meter.createHistogram}
		*/
		createHistogram(_name, _options) {
			return exports.NOOP_HISTOGRAM_METRIC;
		}
		/**
		* @see {@link Meter.createCounter}
		*/
		createCounter(_name, _options) {
			return exports.NOOP_COUNTER_METRIC;
		}
		/**
		* @see {@link Meter.createUpDownCounter}
		*/
		createUpDownCounter(_name, _options) {
			return exports.NOOP_UP_DOWN_COUNTER_METRIC;
		}
		/**
		* @see {@link Meter.createObservableGauge}
		*/
		createObservableGauge(_name, _options) {
			return exports.NOOP_OBSERVABLE_GAUGE_METRIC;
		}
		/**
		* @see {@link Meter.createObservableCounter}
		*/
		createObservableCounter(_name, _options) {
			return exports.NOOP_OBSERVABLE_COUNTER_METRIC;
		}
		/**
		* @see {@link Meter.createObservableUpDownCounter}
		*/
		createObservableUpDownCounter(_name, _options) {
			return exports.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC;
		}
		/**
		* @see {@link Meter.addBatchObservableCallback}
		*/
		addBatchObservableCallback(_callback, _observables) {}
		/**
		* @see {@link Meter.removeBatchObservableCallback}
		*/
		removeBatchObservableCallback(_callback) {}
	};
	exports.NoopMeter = NoopMeter;
	var NoopMetric = class {};
	exports.NoopMetric = NoopMetric;
	var NoopCounterMetric = class extends NoopMetric {
		add(_value, _attributes) {}
	};
	exports.NoopCounterMetric = NoopCounterMetric;
	var NoopUpDownCounterMetric = class extends NoopMetric {
		add(_value, _attributes) {}
	};
	exports.NoopUpDownCounterMetric = NoopUpDownCounterMetric;
	var NoopGaugeMetric = class extends NoopMetric {
		record(_value, _attributes) {}
	};
	exports.NoopGaugeMetric = NoopGaugeMetric;
	var NoopHistogramMetric = class extends NoopMetric {
		record(_value, _attributes) {}
	};
	exports.NoopHistogramMetric = NoopHistogramMetric;
	var NoopObservableMetric = class {
		addCallback(_callback) {}
		removeCallback(_callback) {}
	};
	exports.NoopObservableMetric = NoopObservableMetric;
	var NoopObservableCounterMetric = class extends NoopObservableMetric {};
	exports.NoopObservableCounterMetric = NoopObservableCounterMetric;
	var NoopObservableGaugeMetric = class extends NoopObservableMetric {};
	exports.NoopObservableGaugeMetric = NoopObservableGaugeMetric;
	var NoopObservableUpDownCounterMetric = class extends NoopObservableMetric {};
	exports.NoopObservableUpDownCounterMetric = NoopObservableUpDownCounterMetric;
	exports.NOOP_METER = new NoopMeter();
	exports.NOOP_COUNTER_METRIC = new NoopCounterMetric();
	exports.NOOP_GAUGE_METRIC = new NoopGaugeMetric();
	exports.NOOP_HISTOGRAM_METRIC = new NoopHistogramMetric();
	exports.NOOP_UP_DOWN_COUNTER_METRIC = new NoopUpDownCounterMetric();
	exports.NOOP_OBSERVABLE_COUNTER_METRIC = new NoopObservableCounterMetric();
	exports.NOOP_OBSERVABLE_GAUGE_METRIC = new NoopObservableGaugeMetric();
	exports.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = new NoopObservableUpDownCounterMetric();
	/**
	* Create a no-op Meter
	*
	* @since 1.3.0
	*/
	function createNoopMeter() {
		return exports.NOOP_METER;
	}
	exports.createNoopMeter = createNoopMeter;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/metrics/Metric.js
var require_Metric = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ValueType = void 0;
	(function(ValueType) {
		ValueType[ValueType["INT"] = 0] = "INT";
		ValueType[ValueType["DOUBLE"] = 1] = "DOUBLE";
	})(exports.ValueType || (exports.ValueType = {}));
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/propagation/TextMapPropagator.js
var require_TextMapPropagator = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.defaultTextMapSetter = exports.defaultTextMapGetter = void 0;
	/**
	* @since 1.0.0
	*/
	exports.defaultTextMapGetter = {
		get(carrier, key) {
			if (carrier == null) return;
			return carrier[key];
		},
		keys(carrier) {
			if (carrier == null) return [];
			return Object.keys(carrier);
		}
	};
	/**
	* @since 1.0.0
	*/
	exports.defaultTextMapSetter = { set(carrier, key, value) {
		if (carrier == null) return;
		carrier[key] = value;
	} };
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/context/NoopContextManager.js
var require_NoopContextManager = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.NoopContextManager = void 0;
	var context_1 = require_context$1();
	var NoopContextManager = class {
		active() {
			return context_1.ROOT_CONTEXT;
		}
		with(_context, fn, thisArg, ...args) {
			return fn.call(thisArg, ...args);
		}
		bind(_context, target) {
			return target;
		}
		enable() {
			return this;
		}
		disable() {
			return this;
		}
	};
	exports.NoopContextManager = NoopContextManager;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/api/context.js
var require_context = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ContextAPI = void 0;
	var NoopContextManager_1 = require_NoopContextManager();
	var global_utils_1 = require_global_utils();
	var diag_1 = require_diag();
	var API_NAME = "context";
	var NOOP_CONTEXT_MANAGER = new NoopContextManager_1.NoopContextManager();
	exports.ContextAPI = class ContextAPI {
		/** Empty private constructor prevents end users from constructing a new instance of the API */
		constructor() {}
		/** Get the singleton instance of the Context API */
		static getInstance() {
			if (!this._instance) this._instance = new ContextAPI();
			return this._instance;
		}
		/**
		* Set the current context manager.
		*
		* @returns true if the context manager was successfully registered, else false
		*/
		setGlobalContextManager(contextManager) {
			return (0, global_utils_1.registerGlobal)(API_NAME, contextManager, diag_1.DiagAPI.instance());
		}
		/**
		* Get the currently active context
		*/
		active() {
			return this._getContextManager().active();
		}
		/**
		* Execute a function with an active context
		*
		* @param context context to be active during function execution
		* @param fn function to execute in a context
		* @param thisArg optional receiver to be used for calling fn
		* @param args optional arguments forwarded to fn
		*/
		with(context, fn, thisArg, ...args) {
			return this._getContextManager().with(context, fn, thisArg, ...args);
		}
		/**
		* Bind a context to a target function or event emitter
		*
		* @param context context to bind to the event emitter or function. Defaults to the currently active context
		* @param target function or event emitter to bind
		*/
		bind(context, target) {
			return this._getContextManager().bind(context, target);
		}
		_getContextManager() {
			return (0, global_utils_1.getGlobal)(API_NAME) || NOOP_CONTEXT_MANAGER;
		}
		/** Disable and remove the global context manager */
		disable() {
			this._getContextManager().disable();
			(0, global_utils_1.unregisterGlobal)(API_NAME, diag_1.DiagAPI.instance());
		}
	};
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/trace_flags.js
var require_trace_flags = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.TraceFlags = void 0;
	(function(TraceFlags) {
		/** Represents no flag set. */
		TraceFlags[TraceFlags["NONE"] = 0] = "NONE";
		/** Bit to represent whether trace is sampled in trace flags. */
		TraceFlags[TraceFlags["SAMPLED"] = 1] = "SAMPLED";
	})(exports.TraceFlags || (exports.TraceFlags = {}));
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/invalid-span-constants.js
var require_invalid_span_constants = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.INVALID_SPAN_CONTEXT = exports.INVALID_TRACEID = exports.INVALID_SPANID = void 0;
	var trace_flags_1 = require_trace_flags();
	/**
	* @since 1.0.0
	*/
	exports.INVALID_SPANID = "0000000000000000";
	/**
	* @since 1.0.0
	*/
	exports.INVALID_TRACEID = "00000000000000000000000000000000";
	/**
	* @since 1.0.0
	*/
	exports.INVALID_SPAN_CONTEXT = {
		traceId: exports.INVALID_TRACEID,
		spanId: exports.INVALID_SPANID,
		traceFlags: trace_flags_1.TraceFlags.NONE
	};
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/NonRecordingSpan.js
var require_NonRecordingSpan = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.NonRecordingSpan = void 0;
	var invalid_span_constants_1 = require_invalid_span_constants();
	/**
	* The NonRecordingSpan is the default {@link Span} that is used when no Span
	* implementation is available. All operations are no-op including context
	* propagation.
	*/
	var NonRecordingSpan = class {
		constructor(spanContext = invalid_span_constants_1.INVALID_SPAN_CONTEXT) {
			this._spanContext = spanContext;
		}
		spanContext() {
			return this._spanContext;
		}
		setAttribute(_key, _value) {
			return this;
		}
		setAttributes(_attributes) {
			return this;
		}
		addEvent(_name, _attributes) {
			return this;
		}
		addLink(_link) {
			return this;
		}
		addLinks(_links) {
			return this;
		}
		setStatus(_status) {
			return this;
		}
		updateName(_name) {
			return this;
		}
		end(_endTime) {}
		isRecording() {
			return false;
		}
		recordException(_exception, _time) {}
	};
	exports.NonRecordingSpan = NonRecordingSpan;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/context-utils.js
var require_context_utils = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.getSpanContext = exports.setSpanContext = exports.deleteSpan = exports.setSpan = exports.getActiveSpan = exports.getSpan = void 0;
	var context_1 = require_context$1();
	var NonRecordingSpan_1 = require_NonRecordingSpan();
	var context_2 = require_context();
	/**
	* span key
	*/
	var SPAN_KEY = (0, context_1.createContextKey)("OpenTelemetry Context Key SPAN");
	/**
	* Return the span if one exists
	*
	* @param context context to get span from
	*/
	function getSpan(context) {
		return context.getValue(SPAN_KEY) || void 0;
	}
	exports.getSpan = getSpan;
	/**
	* Gets the span from the current context, if one exists.
	*/
	function getActiveSpan() {
		return getSpan(context_2.ContextAPI.getInstance().active());
	}
	exports.getActiveSpan = getActiveSpan;
	/**
	* Set the span on a context
	*
	* @param context context to use as parent
	* @param span span to set active
	*/
	function setSpan(context, span) {
		return context.setValue(SPAN_KEY, span);
	}
	exports.setSpan = setSpan;
	/**
	* Remove current span stored in the context
	*
	* @param context context to delete span from
	*/
	function deleteSpan(context) {
		return context.deleteValue(SPAN_KEY);
	}
	exports.deleteSpan = deleteSpan;
	/**
	* Wrap span context in a NoopSpan and set as span in a new
	* context
	*
	* @param context context to set active span on
	* @param spanContext span context to be wrapped
	*/
	function setSpanContext(context, spanContext) {
		return setSpan(context, new NonRecordingSpan_1.NonRecordingSpan(spanContext));
	}
	exports.setSpanContext = setSpanContext;
	/**
	* Get the span context of the span if it exists.
	*
	* @param context context to get values from
	*/
	function getSpanContext(context) {
		var _a;
		return (_a = getSpan(context)) === null || _a === void 0 ? void 0 : _a.spanContext();
	}
	exports.getSpanContext = getSpanContext;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/spancontext-utils.js
var require_spancontext_utils = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.wrapSpanContext = exports.isSpanContextValid = exports.isValidSpanId = exports.isValidTraceId = void 0;
	var invalid_span_constants_1 = require_invalid_span_constants();
	var NonRecordingSpan_1 = require_NonRecordingSpan();
	var isHex = new Uint8Array([
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		1,
		1,
		1,
		1,
		1,
		1,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		1,
		1,
		1,
		1,
		1,
		1
	]);
	function isValidHex(id, length) {
		if (typeof id !== "string" || id.length !== length) return false;
		let r = 0;
		for (let i = 0; i < id.length; i += 4) r += (isHex[id.charCodeAt(i)] | 0) + (isHex[id.charCodeAt(i + 1)] | 0) + (isHex[id.charCodeAt(i + 2)] | 0) + (isHex[id.charCodeAt(i + 3)] | 0);
		return r === length;
	}
	/**
	* @since 1.0.0
	*/
	function isValidTraceId(traceId) {
		return isValidHex(traceId, 32) && traceId !== invalid_span_constants_1.INVALID_TRACEID;
	}
	exports.isValidTraceId = isValidTraceId;
	/**
	* @since 1.0.0
	*/
	function isValidSpanId(spanId) {
		return isValidHex(spanId, 16) && spanId !== invalid_span_constants_1.INVALID_SPANID;
	}
	exports.isValidSpanId = isValidSpanId;
	/**
	* Returns true if this {@link SpanContext} is valid.
	* @return true if this {@link SpanContext} is valid.
	*
	* @since 1.0.0
	*/
	function isSpanContextValid(spanContext) {
		return isValidTraceId(spanContext.traceId) && isValidSpanId(spanContext.spanId);
	}
	exports.isSpanContextValid = isSpanContextValid;
	/**
	* Wrap the given {@link SpanContext} in a new non-recording {@link Span}
	*
	* @param spanContext span context to be wrapped
	* @returns a new non-recording {@link Span} with the provided context
	*/
	function wrapSpanContext(spanContext) {
		return new NonRecordingSpan_1.NonRecordingSpan(spanContext);
	}
	exports.wrapSpanContext = wrapSpanContext;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/NoopTracer.js
var require_NoopTracer = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.NoopTracer = void 0;
	var context_1 = require_context();
	var context_utils_1 = require_context_utils();
	var NonRecordingSpan_1 = require_NonRecordingSpan();
	var spancontext_utils_1 = require_spancontext_utils();
	var contextApi = context_1.ContextAPI.getInstance();
	/**
	* No-op implementations of {@link Tracer}.
	*/
	var NoopTracer = class {
		startSpan(name, options, context = contextApi.active()) {
			if (Boolean(options === null || options === void 0 ? void 0 : options.root)) return new NonRecordingSpan_1.NonRecordingSpan();
			const parentFromContext = context && (0, context_utils_1.getSpanContext)(context);
			if (isSpanContext(parentFromContext) && (0, spancontext_utils_1.isSpanContextValid)(parentFromContext)) return new NonRecordingSpan_1.NonRecordingSpan(parentFromContext);
			else return new NonRecordingSpan_1.NonRecordingSpan();
		}
		startActiveSpan(name, arg2, arg3, arg4) {
			let opts;
			let ctx;
			let fn;
			if (arguments.length < 2) return;
			else if (arguments.length === 2) fn = arg2;
			else if (arguments.length === 3) {
				opts = arg2;
				fn = arg3;
			} else {
				opts = arg2;
				ctx = arg3;
				fn = arg4;
			}
			const parentContext = ctx !== null && ctx !== void 0 ? ctx : contextApi.active();
			const span = this.startSpan(name, opts, parentContext);
			const contextWithSpanSet = (0, context_utils_1.setSpan)(parentContext, span);
			return contextApi.with(contextWithSpanSet, fn, void 0, span);
		}
	};
	exports.NoopTracer = NoopTracer;
	function isSpanContext(spanContext) {
		return spanContext !== null && typeof spanContext === "object" && "spanId" in spanContext && typeof spanContext["spanId"] === "string" && "traceId" in spanContext && typeof spanContext["traceId"] === "string" && "traceFlags" in spanContext && typeof spanContext["traceFlags"] === "number";
	}
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/ProxyTracer.js
var require_ProxyTracer = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ProxyTracer = void 0;
	var NOOP_TRACER = new (require_NoopTracer()).NoopTracer();
	/**
	* Proxy tracer provided by the proxy tracer provider
	*
	* @since 1.0.0
	*/
	var ProxyTracer = class {
		constructor(provider, name, version, options) {
			this._provider = provider;
			this.name = name;
			this.version = version;
			this.options = options;
		}
		startSpan(name, options, context) {
			return this._getTracer().startSpan(name, options, context);
		}
		startActiveSpan(_name, _options, _context, _fn) {
			const tracer = this._getTracer();
			return Reflect.apply(tracer.startActiveSpan, tracer, arguments);
		}
		/**
		* Try to get a tracer from the proxy tracer provider.
		* If the proxy tracer provider has no delegate, return a noop tracer.
		*/
		_getTracer() {
			if (this._delegate) return this._delegate;
			const tracer = this._provider.getDelegateTracer(this.name, this.version, this.options);
			if (!tracer) return NOOP_TRACER;
			this._delegate = tracer;
			return this._delegate;
		}
	};
	exports.ProxyTracer = ProxyTracer;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/NoopTracerProvider.js
var require_NoopTracerProvider = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.NoopTracerProvider = void 0;
	var NoopTracer_1 = require_NoopTracer();
	/**
	* An implementation of the {@link TracerProvider} which returns an impotent
	* Tracer for all calls to `getTracer`.
	*
	* All operations are no-op.
	*/
	var NoopTracerProvider = class {
		getTracer(_name, _version, _options) {
			return new NoopTracer_1.NoopTracer();
		}
	};
	exports.NoopTracerProvider = NoopTracerProvider;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/ProxyTracerProvider.js
var require_ProxyTracerProvider = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ProxyTracerProvider = void 0;
	var ProxyTracer_1 = require_ProxyTracer();
	var NOOP_TRACER_PROVIDER = new (require_NoopTracerProvider()).NoopTracerProvider();
	/**
	* Tracer provider which provides {@link ProxyTracer}s.
	*
	* Before a delegate is set, tracers provided are NoOp.
	*   When a delegate is set, traces are provided from the delegate.
	*   When a delegate is set after tracers have already been provided,
	*   all tracers already provided will use the provided delegate implementation.
	*
	* @deprecated This will be removed in the next major version.
	* @since 1.0.0
	*/
	var ProxyTracerProvider = class {
		/**
		* Get a {@link ProxyTracer}
		*/
		getTracer(name, version, options) {
			var _a;
			return (_a = this.getDelegateTracer(name, version, options)) !== null && _a !== void 0 ? _a : new ProxyTracer_1.ProxyTracer(this, name, version, options);
		}
		getDelegate() {
			var _a;
			return (_a = this._delegate) !== null && _a !== void 0 ? _a : NOOP_TRACER_PROVIDER;
		}
		/**
		* Set the delegate tracer provider
		*/
		setDelegate(delegate) {
			this._delegate = delegate;
		}
		getDelegateTracer(name, version, options) {
			var _a;
			return (_a = this._delegate) === null || _a === void 0 ? void 0 : _a.getTracer(name, version, options);
		}
	};
	exports.ProxyTracerProvider = ProxyTracerProvider;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/SamplingResult.js
var require_SamplingResult = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.SamplingDecision = void 0;
	(function(SamplingDecision) {
		/**
		* `Span.isRecording() === false`, span will not be recorded and all events
		* and attributes will be dropped.
		*/
		SamplingDecision[SamplingDecision["NOT_RECORD"] = 0] = "NOT_RECORD";
		/**
		* `Span.isRecording() === true`, but `Sampled` flag in {@link TraceFlags}
		* MUST NOT be set.
		*/
		SamplingDecision[SamplingDecision["RECORD"] = 1] = "RECORD";
		/**
		* `Span.isRecording() === true` AND `Sampled` flag in {@link TraceFlags}
		* MUST be set.
		*/
		SamplingDecision[SamplingDecision["RECORD_AND_SAMPLED"] = 2] = "RECORD_AND_SAMPLED";
	})(exports.SamplingDecision || (exports.SamplingDecision = {}));
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/span_kind.js
var require_span_kind = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.SpanKind = void 0;
	(function(SpanKind) {
		/** Default value. Indicates that the span is used internally. */
		SpanKind[SpanKind["INTERNAL"] = 0] = "INTERNAL";
		/**
		* Indicates that the span covers server-side handling of an RPC or other
		* remote request.
		*/
		SpanKind[SpanKind["SERVER"] = 1] = "SERVER";
		/**
		* Indicates that the span covers the client-side wrapper around an RPC or
		* other remote request.
		*/
		SpanKind[SpanKind["CLIENT"] = 2] = "CLIENT";
		/**
		* Indicates that the span describes producer sending a message to a
		* broker. Unlike client and server, there is no direct critical path latency
		* relationship between producer and consumer spans.
		*/
		SpanKind[SpanKind["PRODUCER"] = 3] = "PRODUCER";
		/**
		* Indicates that the span describes consumer receiving a message from a
		* broker. Unlike client and server, there is no direct critical path latency
		* relationship between producer and consumer spans.
		*/
		SpanKind[SpanKind["CONSUMER"] = 4] = "CONSUMER";
	})(exports.SpanKind || (exports.SpanKind = {}));
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/status.js
var require_status = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.SpanStatusCode = void 0;
	(function(SpanStatusCode) {
		/**
		* The default status.
		*/
		SpanStatusCode[SpanStatusCode["UNSET"] = 0] = "UNSET";
		/**
		* The operation has been validated by an Application developer or
		* Operator to have completed successfully.
		*/
		SpanStatusCode[SpanStatusCode["OK"] = 1] = "OK";
		/**
		* The operation contains an error.
		*/
		SpanStatusCode[SpanStatusCode["ERROR"] = 2] = "ERROR";
	})(exports.SpanStatusCode || (exports.SpanStatusCode = {}));
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/internal/tracestate-validators.js
var require_tracestate_validators = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.validateValue = exports.validateKey = void 0;
	var VALID_KEY_CHAR_RANGE = "[_0-9a-z-*/]";
	var VALID_KEY_REGEX = new RegExp(`^(?:${`[a-z]${VALID_KEY_CHAR_RANGE}{0,255}`}|${`[a-z0-9]${VALID_KEY_CHAR_RANGE}{0,240}@[a-z]${VALID_KEY_CHAR_RANGE}{0,13}`})$`);
	var VALID_VALUE_BASE_REGEX = /^[ -~]{0,255}[!-~]$/;
	var INVALID_VALUE_COMMA_EQUAL_REGEX = /,|=/;
	/**
	* Key is opaque string up to 256 characters printable. It MUST begin with a
	* lowercase letter, and can only contain lowercase letters a-z, digits 0-9,
	* underscores _, dashes -, asterisks *, and forward slashes /.
	* For multi-tenant vendor scenarios, an at sign (@) can be used to prefix the
	* vendor name. Vendors SHOULD set the tenant ID at the beginning of the key.
	* see https://www.w3.org/TR/trace-context/#key
	*/
	function validateKey(key) {
		return VALID_KEY_REGEX.test(key);
	}
	exports.validateKey = validateKey;
	/**
	* Value is opaque string up to 256 characters printable ASCII RFC0020
	* characters (i.e., the range 0x20 to 0x7E) except comma , and =.
	*/
	function validateValue(value) {
		return VALID_VALUE_BASE_REGEX.test(value) && !INVALID_VALUE_COMMA_EQUAL_REGEX.test(value);
	}
	exports.validateValue = validateValue;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/internal/tracestate-impl.js
var require_tracestate_impl = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.TraceStateImpl = void 0;
	var tracestate_validators_1 = require_tracestate_validators();
	var MAX_TRACE_STATE_ITEMS = 32;
	var MAX_TRACE_STATE_LEN = 512;
	var LIST_MEMBERS_SEPARATOR = ",";
	var LIST_MEMBER_KEY_VALUE_SPLITTER = "=";
	exports.TraceStateImpl = class TraceStateImpl {
		constructor(rawTraceState) {
			this._internalState = /* @__PURE__ */ new Map();
			if (rawTraceState) this._parse(rawTraceState);
		}
		set(key, value) {
			const traceState = this._clone();
			if (traceState._internalState.has(key)) traceState._internalState.delete(key);
			traceState._internalState.set(key, value);
			return traceState;
		}
		unset(key) {
			const traceState = this._clone();
			traceState._internalState.delete(key);
			return traceState;
		}
		get(key) {
			return this._internalState.get(key);
		}
		serialize() {
			return Array.from(this._internalState.keys()).reduceRight((agg, key) => {
				agg.push(key + LIST_MEMBER_KEY_VALUE_SPLITTER + this.get(key));
				return agg;
			}, []).join(LIST_MEMBERS_SEPARATOR);
		}
		_parse(rawTraceState) {
			if (rawTraceState.length > MAX_TRACE_STATE_LEN) return;
			this._internalState = rawTraceState.split(LIST_MEMBERS_SEPARATOR).reduceRight((agg, part) => {
				const listMember = part.trim();
				const i = listMember.indexOf(LIST_MEMBER_KEY_VALUE_SPLITTER);
				if (i !== -1) {
					const key = listMember.slice(0, i);
					const value = listMember.slice(i + 1, part.length);
					if ((0, tracestate_validators_1.validateKey)(key) && (0, tracestate_validators_1.validateValue)(value)) agg.set(key, value);
				}
				return agg;
			}, /* @__PURE__ */ new Map());
			if (this._internalState.size > MAX_TRACE_STATE_ITEMS) this._internalState = new Map(Array.from(this._internalState.entries()).reverse().slice(0, MAX_TRACE_STATE_ITEMS));
		}
		_keys() {
			return Array.from(this._internalState.keys()).reverse();
		}
		_clone() {
			const traceState = new TraceStateImpl();
			traceState._internalState = new Map(this._internalState);
			return traceState;
		}
	};
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace/internal/utils.js
var require_utils = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.createTraceState = void 0;
	var tracestate_impl_1 = require_tracestate_impl();
	/**
	* @since 1.1.0
	*/
	function createTraceState(rawTraceState) {
		return new tracestate_impl_1.TraceStateImpl(rawTraceState);
	}
	exports.createTraceState = createTraceState;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/context-api.js
var require_context_api = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.context = void 0;
	/**
	* Entrypoint for context API
	* @since 1.0.0
	*/
	exports.context = require_context().ContextAPI.getInstance();
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/diag-api.js
var require_diag_api = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.diag = void 0;
	/**
	* Entrypoint for Diag API.
	* Defines Diagnostic handler used for internal diagnostic logging operations.
	* The default provides a Noop DiagLogger implementation which may be changed via the
	* diag.setLogger(logger: DiagLogger) function.
	*
	* @since 1.0.0
	*/
	exports.diag = require_diag().DiagAPI.instance();
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/metrics/NoopMeterProvider.js
var require_NoopMeterProvider = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.NOOP_METER_PROVIDER = exports.NoopMeterProvider = void 0;
	var NoopMeter_1 = require_NoopMeter();
	/**
	* An implementation of the {@link MeterProvider} which returns an impotent Meter
	* for all calls to `getMeter`
	*/
	var NoopMeterProvider = class {
		getMeter(_name, _version, _options) {
			return NoopMeter_1.NOOP_METER;
		}
	};
	exports.NoopMeterProvider = NoopMeterProvider;
	exports.NOOP_METER_PROVIDER = new NoopMeterProvider();
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/api/metrics.js
var require_metrics = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.MetricsAPI = void 0;
	var NoopMeterProvider_1 = require_NoopMeterProvider();
	var global_utils_1 = require_global_utils();
	var diag_1 = require_diag();
	var API_NAME = "metrics";
	exports.MetricsAPI = class MetricsAPI {
		/** Empty private constructor prevents end users from constructing a new instance of the API */
		constructor() {}
		/** Get the singleton instance of the Metrics API */
		static getInstance() {
			if (!this._instance) this._instance = new MetricsAPI();
			return this._instance;
		}
		/**
		* Set the current global meter provider.
		* Returns true if the meter provider was successfully registered, else false.
		*/
		setGlobalMeterProvider(provider) {
			return (0, global_utils_1.registerGlobal)(API_NAME, provider, diag_1.DiagAPI.instance());
		}
		/**
		* Returns the global meter provider.
		*/
		getMeterProvider() {
			return (0, global_utils_1.getGlobal)(API_NAME) || NoopMeterProvider_1.NOOP_METER_PROVIDER;
		}
		/**
		* Returns a meter from the global meter provider.
		*/
		getMeter(name, version, options) {
			return this.getMeterProvider().getMeter(name, version, options);
		}
		/** Remove the global meter provider */
		disable() {
			(0, global_utils_1.unregisterGlobal)(API_NAME, diag_1.DiagAPI.instance());
		}
	};
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/metrics-api.js
var require_metrics_api = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.metrics = void 0;
	/**
	* Entrypoint for metrics API
	*
	* @since 1.3.0
	*/
	exports.metrics = require_metrics().MetricsAPI.getInstance();
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/propagation/NoopTextMapPropagator.js
var require_NoopTextMapPropagator = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.NoopTextMapPropagator = void 0;
	/**
	* No-op implementations of {@link TextMapPropagator}.
	*/
	var NoopTextMapPropagator = class {
		/** Noop inject function does nothing */
		inject(_context, _carrier) {}
		/** Noop extract function does nothing and returns the input context */
		extract(context, _carrier) {
			return context;
		}
		fields() {
			return [];
		}
	};
	exports.NoopTextMapPropagator = NoopTextMapPropagator;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/baggage/context-helpers.js
var require_context_helpers = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.deleteBaggage = exports.setBaggage = exports.getActiveBaggage = exports.getBaggage = void 0;
	var context_1 = require_context();
	/**
	* Baggage key
	*/
	var BAGGAGE_KEY = (0, require_context$1().createContextKey)("OpenTelemetry Baggage Key");
	/**
	* Retrieve the current baggage from the given context
	*
	* @param {Context} Context that manage all context values
	* @returns {Baggage} Extracted baggage from the context
	*/
	function getBaggage(context) {
		return context.getValue(BAGGAGE_KEY) || void 0;
	}
	exports.getBaggage = getBaggage;
	/**
	* Retrieve the current baggage from the active/current context
	*
	* @returns {Baggage} Extracted baggage from the context
	*/
	function getActiveBaggage() {
		return getBaggage(context_1.ContextAPI.getInstance().active());
	}
	exports.getActiveBaggage = getActiveBaggage;
	/**
	* Store a baggage in the given context
	*
	* @param {Context} Context that manage all context values
	* @param {Baggage} baggage that will be set in the actual context
	*/
	function setBaggage(context, baggage) {
		return context.setValue(BAGGAGE_KEY, baggage);
	}
	exports.setBaggage = setBaggage;
	/**
	* Delete the baggage stored in the given context
	*
	* @param {Context} Context that manage all context values
	*/
	function deleteBaggage(context) {
		return context.deleteValue(BAGGAGE_KEY);
	}
	exports.deleteBaggage = deleteBaggage;
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/api/propagation.js
var require_propagation = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.PropagationAPI = void 0;
	var global_utils_1 = require_global_utils();
	var NoopTextMapPropagator_1 = require_NoopTextMapPropagator();
	var TextMapPropagator_1 = require_TextMapPropagator();
	var context_helpers_1 = require_context_helpers();
	var utils_1 = require_utils$1();
	var diag_1 = require_diag();
	var API_NAME = "propagation";
	var NOOP_TEXT_MAP_PROPAGATOR = new NoopTextMapPropagator_1.NoopTextMapPropagator();
	exports.PropagationAPI = class PropagationAPI {
		/** Empty private constructor prevents end users from constructing a new instance of the API */
		constructor() {
			this.createBaggage = utils_1.createBaggage;
			this.getBaggage = context_helpers_1.getBaggage;
			this.getActiveBaggage = context_helpers_1.getActiveBaggage;
			this.setBaggage = context_helpers_1.setBaggage;
			this.deleteBaggage = context_helpers_1.deleteBaggage;
		}
		/** Get the singleton instance of the Propagator API */
		static getInstance() {
			if (!this._instance) this._instance = new PropagationAPI();
			return this._instance;
		}
		/**
		* Set the current propagator.
		*
		* @returns true if the propagator was successfully registered, else false
		*/
		setGlobalPropagator(propagator) {
			return (0, global_utils_1.registerGlobal)(API_NAME, propagator, diag_1.DiagAPI.instance());
		}
		/**
		* Inject context into a carrier to be propagated inter-process
		*
		* @param context Context carrying tracing data to inject
		* @param carrier carrier to inject context into
		* @param setter Function used to set values on the carrier
		*/
		inject(context, carrier, setter = TextMapPropagator_1.defaultTextMapSetter) {
			return this._getGlobalPropagator().inject(context, carrier, setter);
		}
		/**
		* Extract context from a carrier
		*
		* @param context Context which the newly created context will inherit from
		* @param carrier Carrier to extract context from
		* @param getter Function used to extract keys from a carrier
		*/
		extract(context, carrier, getter = TextMapPropagator_1.defaultTextMapGetter) {
			return this._getGlobalPropagator().extract(context, carrier, getter);
		}
		/**
		* Return a list of all fields which may be used by the propagator.
		*/
		fields() {
			return this._getGlobalPropagator().fields();
		}
		/** Remove the global propagator */
		disable() {
			(0, global_utils_1.unregisterGlobal)(API_NAME, diag_1.DiagAPI.instance());
		}
		_getGlobalPropagator() {
			return (0, global_utils_1.getGlobal)(API_NAME) || NOOP_TEXT_MAP_PROPAGATOR;
		}
	};
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/propagation-api.js
var require_propagation_api = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.propagation = void 0;
	/**
	* Entrypoint for propagation API
	*
	* @since 1.0.0
	*/
	exports.propagation = require_propagation().PropagationAPI.getInstance();
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/api/trace.js
var require_trace = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.TraceAPI = void 0;
	var global_utils_1 = require_global_utils();
	var ProxyTracerProvider_1 = require_ProxyTracerProvider();
	var spancontext_utils_1 = require_spancontext_utils();
	var context_utils_1 = require_context_utils();
	var diag_1 = require_diag();
	var API_NAME = "trace";
	exports.TraceAPI = class TraceAPI {
		/** Empty private constructor prevents end users from constructing a new instance of the API */
		constructor() {
			this._proxyTracerProvider = new ProxyTracerProvider_1.ProxyTracerProvider();
			this.wrapSpanContext = spancontext_utils_1.wrapSpanContext;
			this.isSpanContextValid = spancontext_utils_1.isSpanContextValid;
			this.deleteSpan = context_utils_1.deleteSpan;
			this.getSpan = context_utils_1.getSpan;
			this.getActiveSpan = context_utils_1.getActiveSpan;
			this.getSpanContext = context_utils_1.getSpanContext;
			this.setSpan = context_utils_1.setSpan;
			this.setSpanContext = context_utils_1.setSpanContext;
		}
		/** Get the singleton instance of the Trace API */
		static getInstance() {
			if (!this._instance) this._instance = new TraceAPI();
			return this._instance;
		}
		/**
		* Set the current global tracer.
		*
		* @returns true if the tracer provider was successfully registered, else false
		*/
		setGlobalTracerProvider(provider) {
			const success = (0, global_utils_1.registerGlobal)(API_NAME, this._proxyTracerProvider, diag_1.DiagAPI.instance());
			if (success) this._proxyTracerProvider.setDelegate(provider);
			return success;
		}
		/**
		* Returns the global tracer provider.
		*/
		getTracerProvider() {
			return (0, global_utils_1.getGlobal)(API_NAME) || this._proxyTracerProvider;
		}
		/**
		* Returns a tracer from the global tracer provider.
		*/
		getTracer(name, version) {
			return this.getTracerProvider().getTracer(name, version);
		}
		/** Remove the global tracer provider */
		disable() {
			(0, global_utils_1.unregisterGlobal)(API_NAME, diag_1.DiagAPI.instance());
			this._proxyTracerProvider = new ProxyTracerProvider_1.ProxyTracerProvider();
		}
	};
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/trace-api.js
var require_trace_api = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.trace = void 0;
	/**
	* Entrypoint for trace API
	*
	* @since 1.0.0
	*/
	exports.trace = require_trace().TraceAPI.getInstance();
}));
//#endregion
//#region node_modules/@opentelemetry/api/build/src/index.js
var require_src = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.trace = exports.propagation = exports.metrics = exports.diag = exports.context = exports.INVALID_SPAN_CONTEXT = exports.INVALID_TRACEID = exports.INVALID_SPANID = exports.isValidSpanId = exports.isValidTraceId = exports.isSpanContextValid = exports.createTraceState = exports.TraceFlags = exports.SpanStatusCode = exports.SpanKind = exports.SamplingDecision = exports.ProxyTracerProvider = exports.ProxyTracer = exports.defaultTextMapSetter = exports.defaultTextMapGetter = exports.ValueType = exports.createNoopMeter = exports.DiagLogLevel = exports.DiagConsoleLogger = exports.ROOT_CONTEXT = exports.createContextKey = exports.baggageEntryMetadataFromString = void 0;
	var utils_1 = require_utils$1();
	Object.defineProperty(exports, "baggageEntryMetadataFromString", {
		enumerable: true,
		get: function() {
			return utils_1.baggageEntryMetadataFromString;
		}
	});
	var context_1 = require_context$1();
	Object.defineProperty(exports, "createContextKey", {
		enumerable: true,
		get: function() {
			return context_1.createContextKey;
		}
	});
	Object.defineProperty(exports, "ROOT_CONTEXT", {
		enumerable: true,
		get: function() {
			return context_1.ROOT_CONTEXT;
		}
	});
	var consoleLogger_1 = require_consoleLogger();
	Object.defineProperty(exports, "DiagConsoleLogger", {
		enumerable: true,
		get: function() {
			return consoleLogger_1.DiagConsoleLogger;
		}
	});
	var types_1 = require_types();
	Object.defineProperty(exports, "DiagLogLevel", {
		enumerable: true,
		get: function() {
			return types_1.DiagLogLevel;
		}
	});
	var NoopMeter_1 = require_NoopMeter();
	Object.defineProperty(exports, "createNoopMeter", {
		enumerable: true,
		get: function() {
			return NoopMeter_1.createNoopMeter;
		}
	});
	var Metric_1 = require_Metric();
	Object.defineProperty(exports, "ValueType", {
		enumerable: true,
		get: function() {
			return Metric_1.ValueType;
		}
	});
	var TextMapPropagator_1 = require_TextMapPropagator();
	Object.defineProperty(exports, "defaultTextMapGetter", {
		enumerable: true,
		get: function() {
			return TextMapPropagator_1.defaultTextMapGetter;
		}
	});
	Object.defineProperty(exports, "defaultTextMapSetter", {
		enumerable: true,
		get: function() {
			return TextMapPropagator_1.defaultTextMapSetter;
		}
	});
	var ProxyTracer_1 = require_ProxyTracer();
	Object.defineProperty(exports, "ProxyTracer", {
		enumerable: true,
		get: function() {
			return ProxyTracer_1.ProxyTracer;
		}
	});
	var ProxyTracerProvider_1 = require_ProxyTracerProvider();
	Object.defineProperty(exports, "ProxyTracerProvider", {
		enumerable: true,
		get: function() {
			return ProxyTracerProvider_1.ProxyTracerProvider;
		}
	});
	var SamplingResult_1 = require_SamplingResult();
	Object.defineProperty(exports, "SamplingDecision", {
		enumerable: true,
		get: function() {
			return SamplingResult_1.SamplingDecision;
		}
	});
	var span_kind_1 = require_span_kind();
	Object.defineProperty(exports, "SpanKind", {
		enumerable: true,
		get: function() {
			return span_kind_1.SpanKind;
		}
	});
	var status_1 = require_status();
	Object.defineProperty(exports, "SpanStatusCode", {
		enumerable: true,
		get: function() {
			return status_1.SpanStatusCode;
		}
	});
	var trace_flags_1 = require_trace_flags();
	Object.defineProperty(exports, "TraceFlags", {
		enumerable: true,
		get: function() {
			return trace_flags_1.TraceFlags;
		}
	});
	var utils_2 = require_utils();
	Object.defineProperty(exports, "createTraceState", {
		enumerable: true,
		get: function() {
			return utils_2.createTraceState;
		}
	});
	var spancontext_utils_1 = require_spancontext_utils();
	Object.defineProperty(exports, "isSpanContextValid", {
		enumerable: true,
		get: function() {
			return spancontext_utils_1.isSpanContextValid;
		}
	});
	Object.defineProperty(exports, "isValidTraceId", {
		enumerable: true,
		get: function() {
			return spancontext_utils_1.isValidTraceId;
		}
	});
	Object.defineProperty(exports, "isValidSpanId", {
		enumerable: true,
		get: function() {
			return spancontext_utils_1.isValidSpanId;
		}
	});
	var invalid_span_constants_1 = require_invalid_span_constants();
	Object.defineProperty(exports, "INVALID_SPANID", {
		enumerable: true,
		get: function() {
			return invalid_span_constants_1.INVALID_SPANID;
		}
	});
	Object.defineProperty(exports, "INVALID_TRACEID", {
		enumerable: true,
		get: function() {
			return invalid_span_constants_1.INVALID_TRACEID;
		}
	});
	Object.defineProperty(exports, "INVALID_SPAN_CONTEXT", {
		enumerable: true,
		get: function() {
			return invalid_span_constants_1.INVALID_SPAN_CONTEXT;
		}
	});
	var context_api_1 = require_context_api();
	Object.defineProperty(exports, "context", {
		enumerable: true,
		get: function() {
			return context_api_1.context;
		}
	});
	var diag_api_1 = require_diag_api();
	Object.defineProperty(exports, "diag", {
		enumerable: true,
		get: function() {
			return diag_api_1.diag;
		}
	});
	var metrics_api_1 = require_metrics_api();
	Object.defineProperty(exports, "metrics", {
		enumerable: true,
		get: function() {
			return metrics_api_1.metrics;
		}
	});
	var propagation_api_1 = require_propagation_api();
	Object.defineProperty(exports, "propagation", {
		enumerable: true,
		get: function() {
			return propagation_api_1.propagation;
		}
	});
	var trace_api_1 = require_trace_api();
	Object.defineProperty(exports, "trace", {
		enumerable: true,
		get: function() {
			return trace_api_1.trace;
		}
	});
	exports.default = {
		context: context_api_1.context,
		diag: diag_api_1.diag,
		metrics: metrics_api_1.metrics,
		propagation: propagation_api_1.propagation,
		trace: trace_api_1.trace
	};
}));
//#endregion
//#region node_modules/@langfuse/core/dist/index.mjs
var import_src = /* @__PURE__ */ __toESM(require_src(), 1);
var __defProp = Object.defineProperty;
var __export = (target, all) => {
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
};
var package_default = {
	name: "@langfuse/core",
	version: "6.0.2",
	description: "Core functions and utilities for Langfuse packages",
	type: "module",
	sideEffects: false,
	main: "./dist/index.cjs",
	module: "./dist/index.mjs",
	types: "./dist/index.d.ts",
	exports: { ".": {
		import: {
			types: "./dist/index.d.ts",
			default: "./dist/index.mjs"
		},
		require: {
			types: "./dist/index.d.cts",
			default: "./dist/index.cjs"
		}
	} },
	scripts: {
		build: "tsup",
		test: "vitest run",
		"test:watch": "vitest",
		format: "prettier --write \"src/**/*.ts\"",
		"format:check": "prettier --check \"src/**/*.ts\"",
		clean: "rm -rf dist"
	},
	author: "Langfuse",
	license: "MIT",
	repository: {
		type: "git",
		url: "https://github.com/langfuse/langfuse-js.git",
		directory: "packages/core"
	},
	engines: { node: ">=22" },
	files: ["dist"],
	peerDependencies: { "@opentelemetry/api": "^1.9.0" },
	devDependencies: { "@types/node": "^24.1.0" }
};
var LANGFUSE_TRACER_NAME = "langfuse-sdk";
var LANGFUSE_SDK_VERSION = package_default.version;
var LANGFUSE_SDK_EXPERIMENT_ENVIRONMENT = "sdk-experiment";
var LangfuseOtelSpanAttributes = /* @__PURE__ */ ((LangfuseOtelSpanAttributes2) => {
	LangfuseOtelSpanAttributes2["TRACE_NAME"] = "langfuse.trace.name";
	LangfuseOtelSpanAttributes2["TRACE_USER_ID"] = "user.id";
	LangfuseOtelSpanAttributes2["TRACE_SESSION_ID"] = "session.id";
	LangfuseOtelSpanAttributes2["TRACE_TAGS"] = "langfuse.trace.tags";
	LangfuseOtelSpanAttributes2["TRACE_PUBLIC"] = "langfuse.trace.public";
	LangfuseOtelSpanAttributes2["TRACE_METADATA"] = "langfuse.trace.metadata";
	LangfuseOtelSpanAttributes2["TRACE_INPUT"] = "langfuse.trace.input";
	LangfuseOtelSpanAttributes2["TRACE_OUTPUT"] = "langfuse.trace.output";
	LangfuseOtelSpanAttributes2["OBSERVATION_TYPE"] = "langfuse.observation.type";
	LangfuseOtelSpanAttributes2["OBSERVATION_METADATA"] = "langfuse.observation.metadata";
	LangfuseOtelSpanAttributes2["OBSERVATION_LEVEL"] = "langfuse.observation.level";
	LangfuseOtelSpanAttributes2["OBSERVATION_STATUS_MESSAGE"] = "langfuse.observation.status_message";
	LangfuseOtelSpanAttributes2["OBSERVATION_INPUT"] = "langfuse.observation.input";
	LangfuseOtelSpanAttributes2["OBSERVATION_OUTPUT"] = "langfuse.observation.output";
	LangfuseOtelSpanAttributes2["OBSERVATION_COMPLETION_START_TIME"] = "langfuse.observation.completion_start_time";
	LangfuseOtelSpanAttributes2["OBSERVATION_MODEL"] = "langfuse.observation.model.name";
	LangfuseOtelSpanAttributes2["OBSERVATION_MODEL_PARAMETERS"] = "langfuse.observation.model.parameters";
	LangfuseOtelSpanAttributes2["OBSERVATION_USAGE_DETAILS"] = "langfuse.observation.usage_details";
	LangfuseOtelSpanAttributes2["OBSERVATION_COST_DETAILS"] = "langfuse.observation.cost_details";
	LangfuseOtelSpanAttributes2["OBSERVATION_PROMPT_NAME"] = "langfuse.observation.prompt.name";
	LangfuseOtelSpanAttributes2["OBSERVATION_PROMPT_VERSION"] = "langfuse.observation.prompt.version";
	LangfuseOtelSpanAttributes2["ENVIRONMENT"] = "langfuse.environment";
	LangfuseOtelSpanAttributes2["RELEASE"] = "langfuse.release";
	LangfuseOtelSpanAttributes2["VERSION"] = "langfuse.version";
	LangfuseOtelSpanAttributes2["AS_ROOT"] = "langfuse.internal.as_root";
	LangfuseOtelSpanAttributes2["IS_APP_ROOT"] = "langfuse.internal.is_app_root";
	LangfuseOtelSpanAttributes2["EXPERIMENT_ID"] = "langfuse.experiment.id";
	LangfuseOtelSpanAttributes2["EXPERIMENT_NAME"] = "langfuse.experiment.name";
	LangfuseOtelSpanAttributes2["EXPERIMENT_DESCRIPTION"] = "langfuse.experiment.description";
	LangfuseOtelSpanAttributes2["EXPERIMENT_METADATA"] = "langfuse.experiment.metadata";
	LangfuseOtelSpanAttributes2["EXPERIMENT_DATASET_ID"] = "langfuse.experiment.dataset.id";
	LangfuseOtelSpanAttributes2["EXPERIMENT_ITEM_ID"] = "langfuse.experiment.item.id";
	LangfuseOtelSpanAttributes2["EXPERIMENT_ITEM_EXPECTED_OUTPUT"] = "langfuse.experiment.item.expected_output";
	LangfuseOtelSpanAttributes2["EXPERIMENT_ITEM_METADATA"] = "langfuse.experiment.item.metadata";
	LangfuseOtelSpanAttributes2["EXPERIMENT_ITEM_ROOT_OBSERVATION_ID"] = "langfuse.experiment.item.root_observation_id";
	LangfuseOtelSpanAttributes2["EXPERIMENT_ITEM_VERSION"] = "langfuse.experiment.item.version";
	LangfuseOtelSpanAttributes2["TRACE_COMPAT_USER_ID"] = "langfuse.user.id";
	LangfuseOtelSpanAttributes2["TRACE_COMPAT_SESSION_ID"] = "langfuse.session.id";
	return LangfuseOtelSpanAttributes2;
})(LangfuseOtelSpanAttributes || {});
function getEnv(key) {
	if (typeof process !== "undefined" && process.env[key]) return process.env[key];
	else if (typeof globalThis !== "undefined") return globalThis[key];
}
function generateUUID(globalThis2) {
	let d = (/* @__PURE__ */ new Date()).getTime();
	let d2 = globalThis2 && globalThis2.performance && globalThis2.performance.now && globalThis2.performance.now() * 1e3 || 0;
	return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
		let r = Math.random() * 16;
		if (d > 0) {
			r = (d + r) % 16 | 0;
			d = Math.floor(d / 16);
		} else {
			r = (d2 + r) % 16 | 0;
			d2 = Math.floor(d2 / 16);
		}
		return (c === "x" ? r : r & 3 | 8).toString(16);
	});
}
function safeSetTimeout(fn, timeout) {
	const t = setTimeout(fn, timeout);
	if (t?.unref) t?.unref();
	return t;
}
function base64ToBytes(base64) {
	const binString = atob(base64);
	return Uint8Array.from(binString, (m) => m.codePointAt(0));
}
function bytesToBase64(bytes) {
	const binString = Array.from(bytes, (byte) => String.fromCharCode(byte)).join("");
	return btoa(binString);
}
function base64Encode(input) {
	if (typeof Buffer !== "undefined") return Buffer.from(input, "utf8").toString("base64");
	return bytesToBase64(new TextEncoder().encode(input));
}
async function createExperimentId() {
	const randomBytes = /* @__PURE__ */ new Uint8Array(8);
	crypto.getRandomValues(randomBytes);
	return Array.from(randomBytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function createStableExperimentId(params) {
	const seed = JSON.stringify([
		"langfuse-experiment-v1",
		params.projectId,
		params.datasetId,
		params.runName
	]);
	const hashBuffer = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(seed));
	return Array.from(new Uint8Array(hashBuffer)).map((b) => b.toString(16).padStart(2, "0")).join("").slice(0, 16);
}
async function createExperimentItemId(input) {
	const serialized = serializeValue(input);
	const data = new TextEncoder().encode(serialized);
	const hashBuffer = await crypto.subtle.digest("SHA-256", data);
	return Array.from(new Uint8Array(hashBuffer)).map((b) => b.toString(16).padStart(2, "0")).join("").slice(0, 16);
}
function serializeValue(value) {
	if (value === void 0 || value === null) return void 0;
	if (typeof value === "string") return value;
	return JSON.stringify(value);
}
function isObservationMetadataKey(key) {
	const prefix = "langfuse.observation.metadata";
	return key === prefix || key.startsWith(`${prefix}.`);
}
function getSpanAttributeCountLimit(span) {
	const limit = span?._spanLimits?.attributeCountLimit;
	return typeof limit === "number" && Number.isFinite(limit) ? limit : void 0;
}
function dropMetadataOverSpanAttributeLimit(span, attributes, reservedKeys) {
	try {
		const limit = getSpanAttributeCountLimit(span);
		if (limit === void 0) return attributes;
		const existing = span.attributes ?? {};
		const isExisting = (key) => Object.prototype.hasOwnProperty.call(existing, key);
		const newKeys = Object.keys(attributes).filter((key) => attributes[key] != null && !isExisting(key));
		const newKeySet = new Set(newKeys);
		const reservedCount = new Set(reservedKeys.filter((key) => !isExisting(key) && !newKeySet.has(key))).size;
		const usedCount = Object.keys(existing).length + reservedCount;
		if (usedCount + newKeys.length <= limit) return attributes;
		const newMetadataKeys = newKeys.filter(isObservationMetadataKey);
		const freeSlots = Math.max(0, limit - usedCount - (newKeys.length - newMetadataKeys.length));
		const dropped = newMetadataKeys.slice(freeSlots);
		if (dropped.length === 0) return attributes;
		const metadataPrefix = `langfuse.observation.metadata.`;
		getGlobalLogger().warn(`Dropped ${dropped.length} metadata key(s) from observation '${span.name}' to stay within the span attribute limit of ${limit} (spanLimits.attributeCountLimit / OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT). Dropped keys include: ${dropped.slice(0, 5).map((key) => key.startsWith(metadataPrefix) ? key.slice(metadataPrefix.length) : key).join(", ")}`);
		const droppedKeys = new Set(dropped);
		return Object.fromEntries(Object.entries(attributes).filter(([key]) => !droppedKeys.has(key)));
	} catch {
		return attributes;
	}
}
function serializeMetadataValue(value) {
	if (value == null || typeof value === "function" || typeof value === "symbol") return;
	try {
		return JSON.stringify(value, (_, v) => {
			if (typeof v === "number" && !Number.isFinite(v)) return String(v);
			if (typeof v !== "bigint") return v;
			return v >= BigInt(Number.MIN_SAFE_INTEGER) && v <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(v) : v.toString();
		});
	} catch {
		return JSON.stringify("<failed to serialize>");
	}
}
var LogLevel = /* @__PURE__ */ ((LogLevel2) => {
	LogLevel2[LogLevel2["NONE"] = 4] = "NONE";
	LogLevel2[LogLevel2["ERROR"] = 3] = "ERROR";
	LogLevel2[LogLevel2["WARN"] = 2] = "WARN";
	LogLevel2[LogLevel2["INFO"] = 1] = "INFO";
	LogLevel2[LogLevel2["DEBUG"] = 0] = "DEBUG";
	return LogLevel2;
})(LogLevel || {});
function parseLogLevelFromEnv() {
	if (typeof process === "object" && "env" in process) {
		if (getEnv("LANGFUSE_DEBUG")?.toLowerCase() === "true") return 0;
		switch ((getEnv("LANGFUSE_LOG_LEVEL") ?? "").toUpperCase()) {
			case "NONE": return 4;
			case "ERROR": return 3;
			case "WARN": return 2;
			case "INFO": return 1;
			case "DEBUG": return 0;
			default: return;
		}
	}
}
var Logger = class {
	config;
	/**
	* Creates a new Logger instance.
	*
	* @param config - Configuration options for the logger
	*/
	constructor(config = { level: 1 }) {
		this.config = {
			enableTimestamp: true,
			...config
		};
	}
	/**
	* Determines if a message should be logged based on the current log level.
	*
	* @param level - The log level to check
	* @returns True if the message should be logged, false otherwise
	*/
	shouldLog(level) {
		return level >= this.config.level;
	}
	/**
	* Formats a log message with timestamp, prefix, and log level.
	*
	* @param level - The log level string
	* @param message - The message to format
	* @returns The formatted message string
	*/
	formatMessage(level, message) {
		return [
			this.config.enableTimestamp ? (/* @__PURE__ */ new Date()).toISOString() : "",
			this.config.prefix || "[Langfuse SDK]",
			`[${level}]`,
			message
		].filter(Boolean).join(" ");
	}
	/**
	* Logs an error message.
	*
	* @param message - The error message to log
	* @param args - Additional arguments to pass to console.error
	*/
	error(message, ...args) {
		if (this.shouldLog(3)) console.error(this.formatMessage("ERROR", message), ...args);
	}
	/**
	* Logs a warning message.
	*
	* @param message - The warning message to log
	* @param args - Additional arguments to pass to console.warn
	*/
	warn(message, ...args) {
		if (this.shouldLog(2)) console.warn(this.formatMessage("WARN", message), ...args);
	}
	/**
	* Logs an informational message.
	*
	* @param message - The info message to log
	* @param args - Additional arguments to pass to console.info
	*/
	info(message, ...args) {
		if (this.shouldLog(1)) console.info(this.formatMessage("INFO", message), ...args);
	}
	/**
	* Logs a debug message.
	*
	* @param message - The debug message to log
	* @param args - Additional arguments to pass to console.debug
	*/
	debug(message, ...args) {
		if (this.shouldLog(0)) console.debug(this.formatMessage("DEBUG", message), ...args);
	}
	/**
	* Sets the minimum log level.
	*
	* @param level - The new log level
	*/
	setLevel(level) {
		this.config.level = level;
	}
	/**
	* Gets the current log level.
	*
	* @returns The current log level
	*/
	getLevel() {
		return this.config.level;
	}
	/**
	* Checks if a given log level is enabled.
	* Use this to guard expensive operations (like JSON.stringify) before debug logging.
	*
	* @param level - The log level to check
	* @returns True if the level is enabled, false otherwise
	*
	* @example
	* ```typescript
	* if (logger.isLevelEnabled(LogLevel.DEBUG)) {
	*   logger.debug('Expensive data:', JSON.stringify(largeObject));
	* }
	* ```
	*/
	isLevelEnabled(level) {
		return this.shouldLog(level);
	}
};
var LoggerSingleton = class _LoggerSingleton {
	static instance = null;
	static defaultConfig = { level: parseLogLevelFromEnv() ?? 1 };
	/**
	* Gets the singleton logger instance, creating it if it doesn't exist.
	*
	* @returns The singleton logger instance
	*/
	static getInstance() {
		if (!_LoggerSingleton.instance) _LoggerSingleton.instance = new Logger(_LoggerSingleton.defaultConfig);
		return _LoggerSingleton.instance;
	}
	/**
	* Configures the global logger with new settings.
	* This will replace the existing logger instance.
	*
	* @param config - The new logger configuration
	*/
	static configure(config) {
		_LoggerSingleton.defaultConfig = config;
		_LoggerSingleton.instance = new Logger(config);
	}
	/**
	* Resets the singleton logger instance and configuration.
	* Useful for testing or reinitializing the logger.
	*/
	static reset() {
		_LoggerSingleton.instance = null;
		_LoggerSingleton.defaultConfig = { level: 1 };
	}
};
var getGlobalLogger = () => {
	return LoggerSingleton.getInstance();
};
__export({}, {
	AnnotationQueueObjectType: () => AnnotationQueueObjectType,
	AnnotationQueueStatus: () => AnnotationQueueStatus
});
var AnnotationQueueStatus = {
	Pending: "PENDING",
	Completed: "COMPLETED"
};
var AnnotationQueueObjectType = {
	Trace: "TRACE",
	Observation: "OBSERVATION",
	Session: "SESSION"
};
__export({}, {
	BlobStorageExportFieldGroup: () => BlobStorageExportFieldGroup,
	BlobStorageExportFrequency: () => BlobStorageExportFrequency,
	BlobStorageExportMode: () => BlobStorageExportMode,
	BlobStorageExportSource: () => BlobStorageExportSource,
	BlobStorageIntegrationFileType: () => BlobStorageIntegrationFileType,
	BlobStorageIntegrationFileTypeResponse: () => BlobStorageIntegrationFileTypeResponse,
	BlobStorageIntegrationType: () => BlobStorageIntegrationType,
	BlobStorageSyncStatus: () => BlobStorageSyncStatus
});
var BlobStorageIntegrationType = {
	S3: "S3",
	S3Compatible: "S3_COMPATIBLE",
	AzureBlobStorage: "AZURE_BLOB_STORAGE",
	GoogleCloudStorage: "GOOGLE_CLOUD_STORAGE"
};
var BlobStorageIntegrationFileType = {
	Json: "JSON",
	Csv: "CSV",
	Jsonl: "JSONL",
	Parquet: "PARQUET"
};
var BlobStorageIntegrationFileTypeResponse = {
	Json: "JSON",
	Csv: "CSV",
	Jsonl: "JSONL",
	Parquet: "PARQUET"
};
var BlobStorageExportMode = {
	FullHistory: "FULL_HISTORY",
	FromToday: "FROM_TODAY",
	FromCustomDate: "FROM_CUSTOM_DATE"
};
var BlobStorageExportFrequency = {
	Every20Minutes: "every_20_minutes",
	Hourly: "hourly",
	Daily: "daily",
	Weekly: "weekly"
};
var BlobStorageExportSource = {
	LegacyTracesObservations: "LEGACY_TRACES_OBSERVATIONS",
	ObservationsV2: "OBSERVATIONS_V2",
	LegacyTracesAndEnrichedObservations: "LEGACY_TRACES_AND_ENRICHED_OBSERVATIONS"
};
var BlobStorageExportFieldGroup = {
	Core: "core",
	Basic: "basic",
	Time: "time",
	Io: "io",
	Metadata: "metadata",
	Model: "model",
	Usage: "usage",
	Prompt: "prompt",
	Metrics: "metrics",
	Tools: "tools",
	TraceContext: "trace_context"
};
var BlobStorageSyncStatus = {
	Idle: "idle",
	Running: "running",
	Queued: "queued",
	UpToDate: "up_to_date",
	Disabled: "disabled",
	Error: "error"
};
__export({}, {
	AccessDeniedError: () => AccessDeniedError,
	CommentObjectType: () => CommentObjectType,
	DatasetItemMediaReferenceField: () => DatasetItemMediaReferenceField,
	DatasetStatus: () => DatasetStatus,
	Error: () => Error2,
	MethodNotAllowedError: () => MethodNotAllowedError,
	ModelUsageUnit: () => ModelUsageUnit,
	NotFoundError: () => NotFoundError,
	ObservationLevel: () => ObservationLevel,
	PricingTierAttributeSource: () => PricingTierAttributeSource,
	PricingTierOperator: () => PricingTierOperator,
	ScoreConfigDataType: () => ScoreConfigDataType,
	ScoreDataType: () => ScoreDataType,
	ScoreSource: () => ScoreSource,
	UnauthorizedError: () => UnauthorizedError
});
var DatasetItemMediaReferenceField = {
	Input: "input",
	ExpectedOutput: "expectedOutput",
	Metadata: "metadata"
};
var PricingTierAttributeSource = {
	ModelParameters: "model_parameters",
	Metadata: "metadata"
};
var PricingTierOperator = {
	Gt: "gt",
	Gte: "gte",
	Lt: "lt",
	Lte: "lte",
	Eq: "eq",
	Neq: "neq"
};
var ModelUsageUnit = {
	Characters: "CHARACTERS",
	Tokens: "TOKENS",
	Milliseconds: "MILLISECONDS",
	Seconds: "SECONDS",
	Images: "IMAGES",
	Requests: "REQUESTS"
};
var ObservationLevel = {
	Debug: "DEBUG",
	Default: "DEFAULT",
	Warning: "WARNING",
	Error: "ERROR"
};
var CommentObjectType = {
	Trace: "TRACE",
	Observation: "OBSERVATION",
	Session: "SESSION",
	Prompt: "PROMPT"
};
var DatasetStatus = {
	Active: "ACTIVE",
	Archived: "ARCHIVED"
};
var ScoreSource = {
	Annotation: "ANNOTATION",
	Api: "API",
	Eval: "EVAL"
};
var ScoreConfigDataType = {
	Numeric: "NUMERIC",
	Boolean: "BOOLEAN",
	Categorical: "CATEGORICAL",
	Text: "TEXT"
};
var ScoreDataType = {
	Numeric: "NUMERIC",
	Boolean: "BOOLEAN",
	Categorical: "CATEGORICAL",
	Correction: "CORRECTION",
	Text: "TEXT"
};
var toJson = (value, replacer, space) => {
	return JSON.stringify(value, replacer, space);
};
function fromJson(text, reviver) {
	return JSON.parse(text, reviver);
}
var LangfuseAPIError = class _LangfuseAPIError extends Error {
	statusCode;
	body;
	rawResponse;
	constructor({ message, statusCode, body, rawResponse }) {
		super(buildMessage({
			message,
			statusCode,
			body
		}));
		Object.setPrototypeOf(this, _LangfuseAPIError.prototype);
		this.statusCode = statusCode;
		this.body = body;
		this.rawResponse = rawResponse;
	}
};
function buildMessage({ message, statusCode, body }) {
	let lines = [];
	if (message != null) lines.push(message);
	if (statusCode != null) lines.push(`Status code: ${statusCode.toString()}`);
	if (body != null) lines.push(`Body: ${toJson(body, void 0, 2)}`);
	return lines.join("\n");
}
var LangfuseAPITimeoutError = class _LangfuseAPITimeoutError extends Error {
	constructor(message) {
		super(message);
		Object.setPrototypeOf(this, _LangfuseAPITimeoutError.prototype);
	}
};
var Error2 = class _Error extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "Error",
			statusCode: 400,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _Error.prototype);
	}
};
var UnauthorizedError = class _UnauthorizedError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "UnauthorizedError",
			statusCode: 401,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _UnauthorizedError.prototype);
	}
};
var AccessDeniedError = class _AccessDeniedError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "AccessDeniedError",
			statusCode: 403,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _AccessDeniedError.prototype);
	}
};
var NotFoundError = class _NotFoundError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "NotFoundError",
			statusCode: 404,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _NotFoundError.prototype);
	}
};
var MethodNotAllowedError = class _MethodNotAllowedError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "MethodNotAllowedError",
			statusCode: 405,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _MethodNotAllowedError.prototype);
	}
};
__export({}, {
	CodeEvaluatorSourceCodeLanguage: () => CodeEvaluatorSourceCodeLanguage,
	EvaluationRuleArrayOptionsFilterOperator: () => EvaluationRuleArrayOptionsFilterOperator,
	EvaluationRuleBooleanFilterOperator: () => EvaluationRuleBooleanFilterOperator,
	EvaluationRuleNullFilterOperator: () => EvaluationRuleNullFilterOperator,
	EvaluationRuleNumberFilterOperator: () => EvaluationRuleNumberFilterOperator,
	EvaluationRuleOptionsFilterOperator: () => EvaluationRuleOptionsFilterOperator,
	EvaluationRuleStringFilterOperator: () => EvaluationRuleStringFilterOperator,
	EvaluationRuleStringObjectFilterOperator: () => EvaluationRuleStringObjectFilterOperator,
	EvaluatorOutputScoreType: () => EvaluatorOutputScoreType,
	EvaluatorType: () => EvaluatorType,
	LegacyEvaluationObject: () => LegacyEvaluationObject,
	PromptVariableMappingSource: () => PromptVariableMappingSource
});
var EvaluatorType = {
	LlmAsJudge: "llm_as_judge",
	Code: "code"
};
var CodeEvaluatorSourceCodeLanguage = {
	Python: "PYTHON",
	Typescript: "TYPESCRIPT"
};
var PromptVariableMappingSource = {
	Input: "input",
	Output: "output",
	Metadata: "metadata",
	ToolCalls: "tool_calls",
	ExpectedOutput: "expected_output",
	ExperimentItemMetadata: "experiment_item_metadata"
};
var EvaluatorOutputScoreType = {
	Numeric: "NUMERIC",
	Boolean: "BOOLEAN",
	Categorical: "CATEGORICAL"
};
var EvaluationRuleStringFilterOperator = {
	Equals: "=",
	Contains: "contains",
	DoesNotContain: "does not contain",
	StartsWith: "starts with",
	EndsWith: "ends with"
};
var EvaluationRuleStringObjectFilterOperator = {
	Equals: "=",
	Contains: "contains",
	DoesNotContain: "does not contain",
	StartsWith: "starts with",
	EndsWith: "ends with",
	IsSet: "is set",
	IsNotSet: "is not set"
};
var EvaluationRuleNumberFilterOperator = {
	Equals: "=",
	GreaterThan: ">",
	LessThan: "<",
	GreaterThanOrEqual: ">=",
	LessThanOrEqual: "<="
};
var EvaluationRuleOptionsFilterOperator = {
	AnyOf: "any of",
	NoneOf: "none of"
};
var EvaluationRuleArrayOptionsFilterOperator = {
	AnyOf: "any of",
	NoneOf: "none of",
	AllOf: "all of"
};
var EvaluationRuleBooleanFilterOperator = {
	Equals: "=",
	NotEquals: "<>"
};
var EvaluationRuleNullFilterOperator = {
	IsNull: "is null",
	IsNotNull: "is not null"
};
var LegacyEvaluationObject = {
	Trace: "trace",
	Span: "span",
	Generation: "generation",
	Event: "event",
	Agent: "agent",
	Tool: "tool",
	Chain: "chain",
	Retriever: "retriever",
	Evaluator: "evaluator",
	Embedding: "embedding",
	Guardrail: "guardrail",
	DatasetItem: "dataset_item"
};
__export({}, {
	BadRequestError: () => BadRequestError,
	ConflictError: () => ConflictError,
	EvaluationAccessDeniedError: () => EvaluationAccessDeniedError,
	EvaluationMethodNotAllowedError: () => EvaluationMethodNotAllowedError,
	EvaluationNotFoundError: () => EvaluationNotFoundError,
	EvaluationUnauthorizedError: () => EvaluationUnauthorizedError,
	InternalServerError: () => InternalServerError,
	PreconditionFailedError: () => PreconditionFailedError,
	PublicApiErrorCode: () => PublicApiErrorCode,
	TooManyRequestsError: () => TooManyRequestsError
});
var PublicApiErrorCode = {
	AuthenticationFailed: "authentication_failed",
	AccessDenied: "access_denied",
	InvalidRequest: "invalid_request",
	InvalidQuery: "invalid_query",
	InvalidBody: "invalid_body",
	ResourceNotFound: "resource_not_found",
	Conflict: "conflict",
	RateLimited: "rate_limited",
	MethodNotAllowed: "method_not_allowed",
	InternalError: "internal_error"
};
var BadRequestError = class _BadRequestError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "BadRequestError",
			statusCode: 400,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _BadRequestError.prototype);
	}
};
var EvaluationUnauthorizedError = class _EvaluationUnauthorizedError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "EvaluationUnauthorizedError",
			statusCode: 401,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _EvaluationUnauthorizedError.prototype);
	}
};
var EvaluationAccessDeniedError = class _EvaluationAccessDeniedError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "EvaluationAccessDeniedError",
			statusCode: 403,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _EvaluationAccessDeniedError.prototype);
	}
};
var EvaluationNotFoundError = class _EvaluationNotFoundError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "EvaluationNotFoundError",
			statusCode: 404,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _EvaluationNotFoundError.prototype);
	}
};
var EvaluationMethodNotAllowedError = class _EvaluationMethodNotAllowedError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "EvaluationMethodNotAllowedError",
			statusCode: 405,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _EvaluationMethodNotAllowedError.prototype);
	}
};
var ConflictError = class _ConflictError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "ConflictError",
			statusCode: 409,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _ConflictError.prototype);
	}
};
var PreconditionFailedError = class _PreconditionFailedError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "PreconditionFailedError",
			statusCode: 412,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _PreconditionFailedError.prototype);
	}
};
var TooManyRequestsError = class _TooManyRequestsError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "TooManyRequestsError",
			statusCode: 429,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _TooManyRequestsError.prototype);
	}
};
var InternalServerError = class _InternalServerError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "InternalServerError",
			statusCode: 500,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _InternalServerError.prototype);
	}
};
__export({}, {
	EvaluatorChatMessageRole: () => EvaluatorChatMessageRole,
	EvaluatorStatus: () => EvaluatorStatus
});
var EvaluatorChatMessageRole = {
	System: "system",
	User: "user",
	Assistant: "assistant"
};
var EvaluatorStatus = {
	Active: "active",
	Paused: "paused"
};
__export({}, {
	FeedbackNotConfiguredError: () => FeedbackNotConfiguredError,
	FeedbackTargetType: () => FeedbackTargetType
});
var FeedbackTargetType = {
	Skill: "skill",
	McpTool: "mcp-tool",
	Cli: "cli",
	Docs: "docs",
	PublicApi: "public-api",
	Other: "other"
};
var FeedbackNotConfiguredError = class _FeedbackNotConfiguredError extends LangfuseAPIError {
	constructor(rawResponse) {
		super({
			message: "FeedbackNotConfiguredError",
			statusCode: 409,
			rawResponse
		});
		Object.setPrototypeOf(this, _FeedbackNotConfiguredError.prototype);
	}
};
__export({}, { ServiceUnavailableError: () => ServiceUnavailableError });
var ServiceUnavailableError = class _ServiceUnavailableError extends LangfuseAPIError {
	constructor(rawResponse) {
		super({
			message: "ServiceUnavailableError",
			statusCode: 503,
			rawResponse
		});
		Object.setPrototypeOf(this, _ServiceUnavailableError.prototype);
	}
};
__export({}, { LlmAdapter: () => LlmAdapter });
var LlmAdapter = {
	Anthropic: "anthropic",
	OpenAi: "openai",
	Azure: "azure",
	Bedrock: "bedrock",
	GoogleVertexAi: "google-vertex-ai",
	GoogleAiStudio: "google-ai-studio"
};
__export({}, { MediaContentType: () => MediaContentType });
var MediaContentType = {
	ImagePng: "image/png",
	ImageJpeg: "image/jpeg",
	ImageJpg: "image/jpg",
	ImageWebp: "image/webp",
	ImageGif: "image/gif",
	ImageSvgXml: "image/svg+xml",
	ImageTiff: "image/tiff",
	ImageBmp: "image/bmp",
	ImageAvif: "image/avif",
	ImageHeic: "image/heic",
	AudioMpeg: "audio/mpeg",
	AudioMp3: "audio/mp3",
	AudioWav: "audio/wav",
	AudioOgg: "audio/ogg",
	AudioOga: "audio/oga",
	AudioAac: "audio/aac",
	AudioMp4: "audio/mp4",
	AudioFlac: "audio/flac",
	AudioOpus: "audio/opus",
	AudioWebm: "audio/webm",
	VideoMp4: "video/mp4",
	VideoWebm: "video/webm",
	VideoOgg: "video/ogg",
	VideoMpeg: "video/mpeg",
	VideoQuicktime: "video/quicktime",
	VideoXMsvideo: "video/x-msvideo",
	VideoXMatroska: "video/x-matroska",
	TextPlain: "text/plain",
	TextHtml: "text/html",
	TextCss: "text/css",
	TextCsv: "text/csv",
	TextMarkdown: "text/markdown",
	TextXPython: "text/x-python",
	ApplicationJavascript: "application/javascript",
	TextXTypescript: "text/x-typescript",
	ApplicationXYaml: "application/x-yaml",
	ApplicationPdf: "application/pdf",
	ApplicationMsword: "application/msword",
	ApplicationMsExcel: "application/vnd.ms-excel",
	ApplicationOpenxmlSpreadsheet: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
	ApplicationZip: "application/zip",
	ApplicationJson: "application/json",
	ApplicationXml: "application/xml",
	ApplicationOctetStream: "application/octet-stream",
	ApplicationOpenxmlWord: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
	ApplicationOpenxmlPresentation: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
	ApplicationRtf: "application/rtf",
	ApplicationXNdjson: "application/x-ndjson",
	ApplicationParquet: "application/vnd.apache.parquet",
	ApplicationGzip: "application/gzip",
	ApplicationXTar: "application/x-tar",
	ApplicationX7ZCompressed: "application/x-7z-compressed"
};
__export({}, { ModelTokenizerId: () => ModelTokenizerId });
var ModelTokenizerId = {
	Openai: "openai",
	Claude: "claude"
};
__export({}, { MembershipRole: () => MembershipRole });
var MembershipRole = {
	Owner: "OWNER",
	Admin: "ADMIN",
	Member: "MEMBER",
	Viewer: "VIEWER"
};
__export({}, {
	ChatMessageType: () => ChatMessageType,
	CreateChatPromptType: () => CreateChatPromptType,
	CreateTextPromptType: () => CreateTextPromptType,
	PlaceholderMessageType: () => PlaceholderMessageType,
	PromptType: () => PromptType
});
var PromptType = {
	Chat: "chat",
	Text: "text"
};
var ChatMessageType = { Chatmessage: "chatmessage" };
var PlaceholderMessageType = { Placeholder: "placeholder" };
var CreateChatPromptType = { Chat: "chat" };
var CreateTextPromptType = { Text: "text" };
__export({}, { CreateScoreSource: () => CreateScoreSource });
var CreateScoreSource = {
	Api: "API",
	Annotation: "ANNOTATION"
};
var unstable_exports = {};
__export(unstable_exports, {
	AccessDeniedError: () => AccessDeniedError2,
	BadRequestError: () => BadRequestError2,
	ConflictError: () => ConflictError2,
	DashboardWidgetChartType: () => DashboardWidgetChartType,
	DashboardWidgetMetricAggregation: () => DashboardWidgetMetricAggregation,
	DashboardWidgetSortOrder: () => DashboardWidgetSortOrder,
	DashboardWidgetView: () => DashboardWidgetView,
	DashboardWidgetViewWithLegacy: () => DashboardWidgetViewWithLegacy,
	InternalServerError: () => InternalServerError2,
	MethodNotAllowedError: () => MethodNotAllowedError2,
	NotFoundError: () => NotFoundError2,
	PublicApiErrorCode: () => PublicApiErrorCode2,
	TooManyRequestsError: () => TooManyRequestsError2,
	UnauthorizedError: () => UnauthorizedError2,
	dashboardWidgets: () => dashboardWidgets_exports,
	dashboards: () => dashboards_exports,
	errors: () => errors_exports2,
	skills: () => skills_exports
});
var dashboardWidgets_exports = {};
__export(dashboardWidgets_exports, {
	DashboardWidgetChartType: () => DashboardWidgetChartType,
	DashboardWidgetMetricAggregation: () => DashboardWidgetMetricAggregation,
	DashboardWidgetSortOrder: () => DashboardWidgetSortOrder,
	DashboardWidgetView: () => DashboardWidgetView,
	DashboardWidgetViewWithLegacy: () => DashboardWidgetViewWithLegacy
});
var DashboardWidgetView = {
	Observations: "observations",
	ScoresNumeric: "scores-numeric",
	ScoresBoolean: "scores-boolean",
	ScoresCategorical: "scores-categorical"
};
var DashboardWidgetViewWithLegacy = {
	Observations: "observations",
	ScoresNumeric: "scores-numeric",
	ScoresBoolean: "scores-boolean",
	ScoresCategorical: "scores-categorical",
	Traces: "traces"
};
var DashboardWidgetChartType = {
	LineTimeSeries: "LINE_TIME_SERIES",
	AreaTimeSeries: "AREA_TIME_SERIES",
	BarTimeSeries: "BAR_TIME_SERIES",
	HorizontalBar: "HORIZONTAL_BAR",
	VerticalBar: "VERTICAL_BAR",
	Pie: "PIE",
	Number: "NUMBER",
	Histogram: "HISTOGRAM",
	PivotTable: "PIVOT_TABLE"
};
var DashboardWidgetMetricAggregation = {
	Sum: "sum",
	Avg: "avg",
	Count: "count",
	Max: "max",
	Min: "min",
	P50: "p50",
	P75: "p75",
	P90: "p90",
	P95: "p95",
	P99: "p99",
	Histogram: "histogram",
	Uniq: "uniq"
};
var DashboardWidgetSortOrder = {
	Asc: "ASC",
	Desc: "DESC"
};
var dashboards_exports = {};
var errors_exports2 = {};
__export(errors_exports2, {
	AccessDeniedError: () => AccessDeniedError2,
	BadRequestError: () => BadRequestError2,
	ConflictError: () => ConflictError2,
	InternalServerError: () => InternalServerError2,
	MethodNotAllowedError: () => MethodNotAllowedError2,
	NotFoundError: () => NotFoundError2,
	PublicApiErrorCode: () => PublicApiErrorCode2,
	TooManyRequestsError: () => TooManyRequestsError2,
	UnauthorizedError: () => UnauthorizedError2
});
var PublicApiErrorCode2 = {
	AuthenticationFailed: "authentication_failed",
	AccessDenied: "access_denied",
	InvalidRequest: "invalid_request",
	InvalidQuery: "invalid_query",
	InvalidBody: "invalid_body",
	ResourceNotFound: "resource_not_found",
	Conflict: "conflict",
	RateLimited: "rate_limited",
	MethodNotAllowed: "method_not_allowed",
	InternalError: "internal_error"
};
var BadRequestError2 = class _BadRequestError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "BadRequestError",
			statusCode: 400,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _BadRequestError.prototype);
	}
};
var UnauthorizedError2 = class _UnauthorizedError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "UnauthorizedError",
			statusCode: 401,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _UnauthorizedError.prototype);
	}
};
var AccessDeniedError2 = class _AccessDeniedError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "AccessDeniedError",
			statusCode: 403,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _AccessDeniedError.prototype);
	}
};
var NotFoundError2 = class _NotFoundError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "NotFoundError",
			statusCode: 404,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _NotFoundError.prototype);
	}
};
var MethodNotAllowedError2 = class _MethodNotAllowedError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "MethodNotAllowedError",
			statusCode: 405,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _MethodNotAllowedError.prototype);
	}
};
var ConflictError2 = class _ConflictError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "ConflictError",
			statusCode: 409,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _ConflictError.prototype);
	}
};
var TooManyRequestsError2 = class _TooManyRequestsError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "TooManyRequestsError",
			statusCode: 429,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _TooManyRequestsError.prototype);
	}
};
var InternalServerError2 = class _InternalServerError extends LangfuseAPIError {
	constructor(body, rawResponse) {
		super({
			message: "InternalServerError",
			statusCode: 500,
			body,
			rawResponse
		});
		Object.setPrototypeOf(this, _InternalServerError.prototype);
	}
};
var skills_exports = {};
__export({}, { pagination: () => pagination_exports });
var pagination_exports = {};
function mergeHeaders(...headersArray) {
	const result = {};
	for (const [key, value] of headersArray.filter((headers) => headers != null).flatMap((headers) => Object.entries(headers))) if (value != null) result[key] = value;
	else if (key in result) delete result[key];
	return result;
}
function mergeOnlyDefinedHeaders(...headersArray) {
	const result = {};
	for (const [key, value] of headersArray.filter((headers) => headers != null).flatMap((headers) => Object.entries(headers))) if (value != null) result[key] = value;
	return result;
}
var defaultQsOptions = {
	arrayFormat: "indices",
	encode: true
};
function encodeValue(value, shouldEncode) {
	if (value === void 0) return "";
	if (value === null) return "";
	const stringValue = String(value);
	return shouldEncode ? encodeURIComponent(stringValue) : stringValue;
}
function stringifyObject(obj, prefix = "", options) {
	const parts = [];
	for (const [key, value] of Object.entries(obj)) {
		const fullKey = prefix ? `${prefix}[${key}]` : key;
		if (value === void 0) continue;
		if (Array.isArray(value)) {
			if (value.length === 0) continue;
			for (let i = 0; i < value.length; i++) {
				const item = value[i];
				if (item === void 0) continue;
				if (typeof item === "object" && !Array.isArray(item) && item !== null) {
					const arrayKey = options.arrayFormat === "indices" ? `${fullKey}[${i}]` : fullKey;
					parts.push(...stringifyObject(item, arrayKey, options));
				} else {
					const arrayKey = options.arrayFormat === "indices" ? `${fullKey}[${i}]` : fullKey;
					const encodedKey = options.encode ? encodeURIComponent(arrayKey) : arrayKey;
					parts.push(`${encodedKey}=${encodeValue(item, options.encode)}`);
				}
			}
		} else if (typeof value === "object" && value !== null) {
			if (Object.keys(value).length === 0) continue;
			parts.push(...stringifyObject(value, fullKey, options));
		} else {
			const encodedKey = options.encode ? encodeURIComponent(fullKey) : fullKey;
			parts.push(`${encodedKey}=${encodeValue(value, options.encode)}`);
		}
	}
	return parts;
}
function toQueryString(obj, options) {
	if (obj == null || typeof obj !== "object") return "";
	return stringifyObject(obj, "", {
		...defaultQsOptions,
		...options
	}).join("&");
}
function createRequestUrl(baseUrl, queryParameters) {
	const queryString = toQueryString(queryParameters, { arrayFormat: "repeat" });
	return queryString ? `${baseUrl}?${queryString}` : baseUrl;
}
function getBinaryResponse(response) {
	const binaryResponse = {
		get bodyUsed() {
			return response.bodyUsed;
		},
		stream: () => response.body,
		arrayBuffer: response.arrayBuffer.bind(response),
		blob: response.blob.bind(response)
	};
	if ("bytes" in response && typeof response.bytes === "function") binaryResponse.bytes = response.bytes.bind(response);
	return binaryResponse;
}
function isResponseWithBody(response) {
	return response.body != null;
}
async function getResponseBody(response, responseType) {
	if (!isResponseWithBody(response)) return;
	switch (responseType) {
		case "binary-response": return getBinaryResponse(response);
		case "blob": return await response.blob();
		case "arrayBuffer": return await response.arrayBuffer();
		case "sse": return response.body;
		case "streaming": return response.body;
		case "text": return await response.text();
	}
	const text = await response.text();
	if (text.length > 0) try {
		return fromJson(text);
	} catch (err) {
		return {
			ok: false,
			error: {
				reason: "non-json",
				statusCode: response.status,
				rawBody: text
			}
		};
	}
}
async function getErrorResponseBody(response) {
	let contentType = response.headers.get("Content-Type")?.toLowerCase();
	if (contentType == null || contentType.length === 0) return getResponseBody(response);
	if (contentType.indexOf(";") !== -1) contentType = contentType.split(";")[0]?.trim() ?? "";
	switch (contentType) {
		case "application/hal+json":
		case "application/json":
		case "application/ld+json":
		case "application/problem+json":
		case "application/vnd.api+json":
		case "text/json":
			const text = await response.text();
			return text.length > 0 ? fromJson(text) : void 0;
		default:
			if (contentType.startsWith("application/vnd.") && contentType.endsWith("+json")) {
				const text2 = await response.text();
				return text2.length > 0 ? fromJson(text2) : void 0;
			}
			return await response.text();
	}
}
async function getFetchFn() {
	return fetch;
}
async function getRequestBody({ body, type }) {
	if (type.includes("json")) return toJson(body);
	else return body;
}
var TIMEOUT = "timeout";
function getTimeoutSignal(timeoutMs) {
	const controller = new AbortController();
	const abortId = setTimeout(() => controller.abort(TIMEOUT), timeoutMs);
	return {
		signal: controller.signal,
		abortId
	};
}
function anySignal(...args) {
	const signals = args.length === 1 && Array.isArray(args[0]) ? args[0] : args;
	const controller = new AbortController();
	for (const signal of signals) {
		if (signal.aborted) {
			controller.abort(signal?.reason);
			break;
		}
		signal.addEventListener("abort", () => controller.abort(signal?.reason), { signal: controller.signal });
	}
	return controller.signal;
}
var makeRequest = async (fetchFn, url, method, headers, requestBody, timeoutMs, abortSignal, withCredentials, duplex) => {
	const signals = [];
	let timeoutAbortId = void 0;
	if (timeoutMs != null) {
		const { signal, abortId } = getTimeoutSignal(timeoutMs);
		timeoutAbortId = abortId;
		signals.push(signal);
	}
	if (abortSignal != null) signals.push(abortSignal);
	const response = await fetchFn(url, {
		method,
		headers,
		body: requestBody,
		signal: anySignal(signals),
		credentials: withCredentials ? "include" : void 0,
		duplex
	});
	if (timeoutAbortId != null) clearTimeout(timeoutAbortId);
	return response;
};
var Headers;
if (typeof globalThis.Headers !== "undefined") Headers = globalThis.Headers;
else Headers = class Headers2 {
	headers;
	constructor(init) {
		this.headers = /* @__PURE__ */ new Map();
		if (init) {
			if (init instanceof Headers2) init.forEach((value, key) => this.append(key, value));
			else if (Array.isArray(init)) for (const [key, value] of init) if (typeof key === "string" && typeof value === "string") this.append(key, value);
			else throw new TypeError("Each header entry must be a [string, string] tuple");
			else for (const [key, value] of Object.entries(init)) if (typeof value === "string") this.append(key, value);
			else throw new TypeError("Header values must be strings");
		}
	}
	append(name, value) {
		const key = name.toLowerCase();
		const existing = this.headers.get(key) || [];
		this.headers.set(key, [...existing, value]);
	}
	delete(name) {
		const key = name.toLowerCase();
		this.headers.delete(key);
	}
	get(name) {
		const key = name.toLowerCase();
		const values = this.headers.get(key);
		return values ? values.join(", ") : null;
	}
	has(name) {
		const key = name.toLowerCase();
		return this.headers.has(key);
	}
	set(name, value) {
		const key = name.toLowerCase();
		this.headers.set(key, [value]);
	}
	forEach(callbackfn, thisArg) {
		const boundCallback = thisArg ? callbackfn.bind(thisArg) : callbackfn;
		this.headers.forEach((values, key) => boundCallback(values.join(", "), key, this));
	}
	getSetCookie() {
		return this.headers.get("set-cookie") || [];
	}
	*entries() {
		for (const [key, values] of this.headers.entries()) yield [key, values.join(", ")];
	}
	*keys() {
		yield* this.headers.keys();
	}
	*values() {
		for (const values of this.headers.values()) yield values.join(", ");
	}
	[Symbol.iterator]() {
		return this.entries();
	}
};
var abortRawResponse = {
	headers: new Headers(),
	redirected: false,
	status: 499,
	statusText: "Client Closed Request",
	type: "error",
	url: ""
};
var unknownRawResponse = {
	headers: new Headers(),
	redirected: false,
	status: 0,
	statusText: "Unknown Error",
	type: "error",
	url: ""
};
function toRawResponse(response) {
	return {
		headers: response.headers,
		redirected: response.redirected,
		status: response.status,
		statusText: response.statusText,
		type: response.type,
		url: response.url
	};
}
var INITIAL_RETRY_DELAY = 1e3;
var MAX_RETRY_DELAY = 6e4;
var DEFAULT_MAX_RETRIES = 2;
var JITTER_FACTOR = .2;
function addPositiveJitter(delay) {
	return delay * (1 + Math.random() * JITTER_FACTOR);
}
function addSymmetricJitter(delay) {
	return delay * (1 + (Math.random() - .5) * JITTER_FACTOR);
}
function getRetryDelayFromHeaders(response, retryAttempt) {
	const retryAfter = response.headers.get("Retry-After");
	if (retryAfter) {
		const retryAfterSeconds = parseInt(retryAfter, 10);
		if (!isNaN(retryAfterSeconds) && retryAfterSeconds > 0) return Math.min(retryAfterSeconds * 1e3, MAX_RETRY_DELAY);
		const retryAfterDate = new Date(retryAfter);
		if (!isNaN(retryAfterDate.getTime())) {
			const delay = retryAfterDate.getTime() - Date.now();
			if (delay > 0) return Math.min(Math.max(delay, 0), MAX_RETRY_DELAY);
		}
	}
	const rateLimitReset = response.headers.get("X-RateLimit-Reset");
	if (rateLimitReset) {
		const resetTime = parseInt(rateLimitReset, 10);
		if (!isNaN(resetTime)) {
			const delay = resetTime * 1e3 - Date.now();
			if (delay > 0) return addPositiveJitter(Math.min(delay, MAX_RETRY_DELAY));
		}
	}
	return addSymmetricJitter(Math.min(INITIAL_RETRY_DELAY * Math.pow(2, retryAttempt), MAX_RETRY_DELAY));
}
async function requestWithRetries(requestFn, maxRetries = DEFAULT_MAX_RETRIES) {
	let response = await requestFn();
	for (let i = 0; i < maxRetries; ++i) if ([408, 429].includes(response.status) || response.status >= 500) {
		const delay = getRetryDelayFromHeaders(response, i);
		await new Promise((resolve) => setTimeout(resolve, delay));
		response = await requestFn();
	} else break;
	return response;
}
var Supplier = { get: async (supplier) => {
	if (typeof supplier === "function") return supplier();
	else return supplier;
} };
async function getHeaders(args) {
	const newHeaders = {};
	if (args.body !== void 0 && args.contentType != null) newHeaders["Content-Type"] = args.contentType;
	if (args.headers == null) return newHeaders;
	for (const [key, value] of Object.entries(args.headers)) {
		const result = await Supplier.get(value);
		if (typeof result === "string") {
			newHeaders[key] = result;
			continue;
		}
		if (result == null) continue;
		newHeaders[key] = `${result}`;
	}
	return newHeaders;
}
async function fetcherImpl(args) {
	const url = createRequestUrl(args.url, args.queryParameters);
	const requestBody = await getRequestBody({
		body: args.body,
		type: args.requestType === "json" ? "json" : "other"
	});
	const fetchFn = await getFetchFn();
	try {
		const response = await requestWithRetries(async () => makeRequest(fetchFn, url, args.method, await getHeaders(args), requestBody, args.timeoutMs, args.abortSignal, args.withCredentials, args.duplex), args.maxRetries);
		if (response.status >= 200 && response.status < 400) return {
			ok: true,
			body: await getResponseBody(response, args.responseType),
			headers: response.headers,
			rawResponse: toRawResponse(response)
		};
		else return {
			ok: false,
			error: {
				reason: "status-code",
				statusCode: response.status,
				body: await getErrorResponseBody(response)
			},
			rawResponse: toRawResponse(response)
		};
	} catch (error) {
		if (args.abortSignal != null && args.abortSignal.aborted) return {
			ok: false,
			error: {
				reason: "unknown",
				errorMessage: "The user aborted a request"
			},
			rawResponse: abortRawResponse
		};
		else if (error instanceof Error && error.name === "AbortError") return {
			ok: false,
			error: { reason: "timeout" },
			rawResponse: abortRawResponse
		};
		else if (error instanceof Error) return {
			ok: false,
			error: {
				reason: "unknown",
				errorMessage: error.message
			},
			rawResponse: unknownRawResponse
		};
		return {
			ok: false,
			error: {
				reason: "unknown",
				errorMessage: toJson(error)
			},
			rawResponse: unknownRawResponse
		};
	}
}
var fetcher = fetcherImpl;
var HttpResponsePromise = class _HttpResponsePromise extends Promise {
	innerPromise;
	unwrappedPromise;
	constructor(promise) {
		super((resolve) => {
			resolve(void 0);
		});
		this.innerPromise = promise;
	}
	/**
	* Creates an `HttpResponsePromise` from a function that returns a promise.
	*
	* @param fn - A function that returns a promise resolving to a `WithRawResponse` object.
	* @param args - Arguments to pass to the function.
	* @returns An `HttpResponsePromise` instance.
	*/
	static fromFunction(fn, ...args) {
		return new _HttpResponsePromise(fn(...args));
	}
	/**
	* Creates a function that returns an `HttpResponsePromise` from a function that returns a promise.
	*
	* @param fn - A function that returns a promise resolving to a `WithRawResponse` object.
	* @returns A function that returns an `HttpResponsePromise` instance.
	*/
	static interceptFunction(fn) {
		return (...args) => {
			return _HttpResponsePromise.fromPromise(fn(...args));
		};
	}
	/**
	* Creates an `HttpResponsePromise` from an existing promise.
	*
	* @param promise - A promise resolving to a `WithRawResponse` object.
	* @returns An `HttpResponsePromise` instance.
	*/
	static fromPromise(promise) {
		return new _HttpResponsePromise(promise);
	}
	/**
	* Creates an `HttpResponsePromise` from an executor function.
	*
	* @param executor - A function that takes resolve and reject callbacks to create a promise.
	* @returns An `HttpResponsePromise` instance.
	*/
	static fromExecutor(executor) {
		const promise = new Promise(executor);
		return new _HttpResponsePromise(promise);
	}
	/**
	* Creates an `HttpResponsePromise` from a resolved result.
	*
	* @param result - A `WithRawResponse` object to resolve immediately.
	* @returns An `HttpResponsePromise` instance.
	*/
	static fromResult(result) {
		const promise = Promise.resolve(result);
		return new _HttpResponsePromise(promise);
	}
	unwrap() {
		if (!this.unwrappedPromise) this.unwrappedPromise = this.innerPromise.then(({ data }) => data);
		return this.unwrappedPromise;
	}
	/** @inheritdoc */
	then(onfulfilled, onrejected) {
		return this.unwrap().then(onfulfilled, onrejected);
	}
	/** @inheritdoc */
	catch(onrejected) {
		return this.unwrap().catch(onrejected);
	}
	/** @inheritdoc */
	finally(onfinally) {
		return this.unwrap().finally(onfinally);
	}
	/**
	* Retrieves the data and raw response.
	*
	* @returns A promise resolving to a `WithRawResponse` object.
	*/
	async withRawResponse() {
		return await this.innerPromise;
	}
};
var url_exports = {};
__export(url_exports, {
	join: () => join,
	toQueryString: () => toQueryString
});
function join(base, ...segments) {
	if (!base) return "";
	if (segments.length === 0) return base;
	if (base.includes("://")) {
		let url;
		try {
			url = new URL(base);
		} catch {
			return joinPath(base, ...segments);
		}
		const lastSegment = segments[segments.length - 1];
		const shouldPreserveTrailingSlash = lastSegment && lastSegment.endsWith("/");
		for (const segment of segments) {
			const cleanSegment = trimSlashes(segment);
			if (cleanSegment) url.pathname = joinPathSegments(url.pathname, cleanSegment);
		}
		if (shouldPreserveTrailingSlash && !url.pathname.endsWith("/")) url.pathname += "/";
		return url.toString();
	}
	return joinPath(base, ...segments);
}
function joinPath(base, ...segments) {
	if (segments.length === 0) return base;
	let result = base;
	const lastSegment = segments[segments.length - 1];
	const shouldPreserveTrailingSlash = lastSegment && lastSegment.endsWith("/");
	for (const segment of segments) {
		const cleanSegment = trimSlashes(segment);
		if (cleanSegment) result = joinPathSegments(result, cleanSegment);
	}
	if (shouldPreserveTrailingSlash && !result.endsWith("/")) result += "/";
	return result;
}
function joinPathSegments(left, right) {
	if (left.endsWith("/")) return left + right;
	return left + "/" + right;
}
function trimSlashes(str) {
	if (!str) return str;
	let start = 0;
	let end = str.length;
	if (str.startsWith("/")) start = 1;
	if (str.endsWith("/")) end = str.length - 1;
	return start === 0 && end === str.length ? str : str.slice(start, end);
}
function base64ToBytes2(base64) {
	const binString = atob(base64);
	return Uint8Array.from(binString, (m) => m.codePointAt(0));
}
function bytesToBase642(bytes) {
	const binString = String.fromCodePoint(...bytes);
	return btoa(binString);
}
function base64Encode2(input) {
	if (typeof Buffer !== "undefined") return Buffer.from(input, "utf8").toString("base64");
	return bytesToBase642(new TextEncoder().encode(input));
}
function base64Decode2(input) {
	if (typeof Buffer !== "undefined") return Buffer.from(input, "base64").toString("utf8");
	const bytes = base64ToBytes2(input);
	return new TextDecoder().decode(bytes);
}
var BASIC_AUTH_HEADER_PREFIX = /^Basic /i;
var BasicAuth = {
	toAuthorizationHeader: (basicAuth) => {
		if (basicAuth == null) return;
		return `Basic ${base64Encode2(`${basicAuth.username}:${basicAuth.password}`)}`;
	},
	fromAuthorizationHeader: (header) => {
		const [username, password] = base64Decode2(header.replace(BASIC_AUTH_HEADER_PREFIX, "")).split(":", 2);
		if (username == null || password == null) throw new Error("Invalid basic auth");
		return {
			username,
			password
		};
	}
};
var AnnotationQueues = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Get all annotation queues
	*
	* @param {LangfuseAPI.GetAnnotationQueuesRequest} request
	* @param {AnnotationQueues.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.annotationQueues.listQueues()
	*/
	listQueues(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__listQueues(request, requestOptions));
	}
	async __listQueues(request = {}, requestOptions) {
		const { page, limit } = request;
		const _queryParams = {};
		if (page != null) _queryParams["page"] = page.toString();
		if (limit != null) _queryParams["limit"] = limit.toString();
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/annotation-queues"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/annotation-queues.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create an annotation queue
	*
	* @param {LangfuseAPI.CreateAnnotationQueueRequest} request
	* @param {AnnotationQueues.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.annotationQueues.createQueue({
	*         name: "name",
	*         description: undefined,
	*         scoreConfigIds: ["scoreConfigIds", "scoreConfigIds"]
	*     })
	*/
	createQueue(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__createQueue(request, requestOptions));
	}
	async __createQueue(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/annotation-queues"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/annotation-queues.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get an annotation queue by ID
	*
	* @param {string} queueId - The unique identifier of the annotation queue
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {AnnotationQueues.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.annotationQueues.getQueue("queueId")
	*/
	getQueue(queueId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getQueue(queueId, requestOptions));
	}
	async __getQueue(queueId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/annotation-queues/${encodeURIComponent(queueId)}`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/annotation-queues/{queueId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get items for a specific annotation queue
	*
	* @param {string} queueId - The unique identifier of the annotation queue
	* @param {LangfuseAPI.GetAnnotationQueueItemsRequest} request
	* @param {AnnotationQueues.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.annotationQueues.listQueueItems("queueId")
	*/
	listQueueItems(queueId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__listQueueItems(queueId, request, requestOptions));
	}
	async __listQueueItems(queueId, request = {}, requestOptions) {
		const { status, page, limit } = request;
		const _queryParams = {};
		if (status != null) _queryParams["status"] = status;
		if (page != null) _queryParams["page"] = page.toString();
		if (limit != null) _queryParams["limit"] = limit.toString();
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/annotation-queues/${encodeURIComponent(queueId)}/items`),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/annotation-queues/{queueId}/items.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get a specific item from an annotation queue
	*
	* @param {string} queueId - The unique identifier of the annotation queue
	* @param {string} itemId - The unique identifier of the annotation queue item
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {AnnotationQueues.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.annotationQueues.getQueueItem("queueId", "itemId")
	*/
	getQueueItem(queueId, itemId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getQueueItem(queueId, itemId, requestOptions));
	}
	async __getQueueItem(queueId, itemId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/annotation-queues/${encodeURIComponent(queueId)}/items/${encodeURIComponent(itemId)}`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/annotation-queues/{queueId}/items/{itemId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Add an item to an annotation queue
	*
	* @param {string} queueId - The unique identifier of the annotation queue
	* @param {LangfuseAPI.CreateAnnotationQueueItemRequest} request
	* @param {AnnotationQueues.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.annotationQueues.createQueueItem("queueId", {
	*         objectId: "objectId",
	*         objectType: "TRACE",
	*         status: undefined
	*     })
	*/
	createQueueItem(queueId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__createQueueItem(queueId, request, requestOptions));
	}
	async __createQueueItem(queueId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/annotation-queues/${encodeURIComponent(queueId)}/items`),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/annotation-queues/{queueId}/items.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Update an annotation queue item
	*
	* @param {string} queueId - The unique identifier of the annotation queue
	* @param {string} itemId - The unique identifier of the annotation queue item
	* @param {LangfuseAPI.UpdateAnnotationQueueItemRequest} request
	* @param {AnnotationQueues.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.annotationQueues.updateQueueItem("queueId", "itemId", {
	*         status: undefined
	*     })
	*/
	updateQueueItem(queueId, itemId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__updateQueueItem(queueId, itemId, request, requestOptions));
	}
	async __updateQueueItem(queueId, itemId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/annotation-queues/${encodeURIComponent(queueId)}/items/${encodeURIComponent(itemId)}`),
			method: "PATCH",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PATCH /api/public/annotation-queues/{queueId}/items/{itemId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Remove an item from an annotation queue
	*
	* @param {string} queueId - The unique identifier of the annotation queue
	* @param {string} itemId - The unique identifier of the annotation queue item
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {AnnotationQueues.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.annotationQueues.deleteQueueItem("queueId", "itemId")
	*/
	deleteQueueItem(queueId, itemId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__deleteQueueItem(queueId, itemId, requestOptions));
	}
	async __deleteQueueItem(queueId, itemId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/annotation-queues/${encodeURIComponent(queueId)}/items/${encodeURIComponent(itemId)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/annotation-queues/{queueId}/items/{itemId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create an assignment for a user to an annotation queue
	*
	* @param {string} queueId - The unique identifier of the annotation queue
	* @param {LangfuseAPI.AnnotationQueueAssignmentRequest} request
	* @param {AnnotationQueues.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.annotationQueues.createQueueAssignment("queueId", {
	*         userId: "userId"
	*     })
	*/
	createQueueAssignment(queueId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__createQueueAssignment(queueId, request, requestOptions));
	}
	async __createQueueAssignment(queueId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/annotation-queues/${encodeURIComponent(queueId)}/assignments`),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/annotation-queues/{queueId}/assignments.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete an assignment for a user to an annotation queue
	*
	* @param {string} queueId - The unique identifier of the annotation queue
	* @param {LangfuseAPI.AnnotationQueueAssignmentRequest} request
	* @param {AnnotationQueues.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.annotationQueues.deleteQueueAssignment("queueId", {
	*         userId: "userId"
	*     })
	*/
	deleteQueueAssignment(queueId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__deleteQueueAssignment(queueId, request, requestOptions));
	}
	async __deleteQueueAssignment(queueId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/annotation-queues/${encodeURIComponent(queueId)}/assignments`),
			method: "DELETE",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/annotation-queues/{queueId}/assignments.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var BlobStorageIntegrations = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Get all blob storage integrations for the organization (requires organization-scoped API key)
	*
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {BlobStorageIntegrations.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.blobStorageIntegrations.getBlobStorageIntegrations()
	*/
	getBlobStorageIntegrations(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getBlobStorageIntegrations(requestOptions));
	}
	async __getBlobStorageIntegrations(requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/integrations/blob-storage"),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/integrations/blob-storage.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create or update a blob storage integration for a specific project (requires organization-scoped API key). The configuration is validated by performing a test upload to the bucket.
	*
	* @param {LangfuseAPI.CreateBlobStorageIntegrationRequest} request
	* @param {BlobStorageIntegrations.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.blobStorageIntegrations.upsertBlobStorageIntegration({
	*         projectId: "projectId",
	*         type: "S3",
	*         bucketName: "bucketName",
	*         endpoint: undefined,
	*         region: "region",
	*         accessKeyId: undefined,
	*         secretAccessKey: undefined,
	*         prefix: undefined,
	*         exportFrequency: "every_20_minutes",
	*         enabled: true,
	*         forcePathStyle: true,
	*         fileType: "JSON",
	*         exportMode: "FULL_HISTORY",
	*         exportStartDate: undefined,
	*         compressed: undefined,
	*         exportSource: undefined,
	*         exportFieldGroups: undefined
	*     })
	*/
	upsertBlobStorageIntegration(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__upsertBlobStorageIntegration(request, requestOptions));
	}
	async __upsertBlobStorageIntegration(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/integrations/blob-storage"),
			method: "PUT",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PUT /api/public/integrations/blob-storage.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get the sync status of a blob storage integration by integration ID (requires organization-scoped API key)
	*
	* @param {string} id
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {BlobStorageIntegrations.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.blobStorageIntegrations.getBlobStorageIntegrationStatus("id")
	*/
	getBlobStorageIntegrationStatus(id, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getBlobStorageIntegrationStatus(id, requestOptions));
	}
	async __getBlobStorageIntegrationStatus(id, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/integrations/blob-storage/${encodeURIComponent(id)}`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/integrations/blob-storage/{id}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete a blob storage integration by ID (requires organization-scoped API key)
	*
	* @param {string} id
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {BlobStorageIntegrations.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.blobStorageIntegrations.deleteBlobStorageIntegration("id")
	*/
	deleteBlobStorageIntegration(id, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__deleteBlobStorageIntegration(id, requestOptions));
	}
	async __deleteBlobStorageIntegration(id, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/integrations/blob-storage/${encodeURIComponent(id)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/integrations/blob-storage/{id}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Comments = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Create a comment. Comments may be attached to different object types (trace, observation, session, prompt).
	*
	* @param {LangfuseAPI.CreateCommentRequest} request
	* @param {Comments.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.comments.create({
	*         projectId: "projectId",
	*         objectType: "objectType",
	*         objectId: "objectId",
	*         content: "content",
	*         authorUserId: undefined
	*     })
	*/
	create(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__create(request, requestOptions));
	}
	async __create(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/comments"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/comments.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get all comments
	*
	* @param {LangfuseAPI.GetCommentsRequest} request
	* @param {Comments.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.comments.get()
	*/
	get(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__get(request, requestOptions));
	}
	async __get(request = {}, requestOptions) {
		const { page, limit, objectType, objectId, authorUserId } = request;
		const _queryParams = {};
		if (page != null) _queryParams["page"] = page.toString();
		if (limit != null) _queryParams["limit"] = limit.toString();
		if (objectType != null) _queryParams["objectType"] = objectType;
		if (objectId != null) _queryParams["objectId"] = objectId;
		if (authorUserId != null) _queryParams["authorUserId"] = authorUserId;
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/comments"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/comments.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get a comment by id
	*
	* @param {string} commentId - The unique langfuse identifier of a comment
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Comments.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.comments.getById("commentId")
	*/
	getById(commentId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getById(commentId, requestOptions));
	}
	async __getById(commentId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/comments/${encodeURIComponent(commentId)}`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/comments/{commentId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var DatasetItems = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Create a dataset item
	*
	* @param {LangfuseAPI.CreateDatasetItemRequest} request
	* @param {DatasetItems.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.datasetItems.create({
	*         datasetName: "datasetName",
	*         input: undefined,
	*         expectedOutput: undefined,
	*         metadata: undefined,
	*         sourceTraceId: undefined,
	*         sourceObservationId: undefined,
	*         id: undefined,
	*         status: undefined
	*     })
	*/
	create(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__create(request, requestOptions));
	}
	async __create(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/dataset-items"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/dataset-items.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get a dataset item
	*
	* @param {string} id
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {DatasetItems.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.datasetItems.get("id")
	*/
	get(id, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__get(id, requestOptions));
	}
	async __get(id, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/dataset-items/${encodeURIComponent(id)}`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/dataset-items/{id}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get dataset items. Optionally specify a version to get the items as they existed at that point in time.
	* Note: If version parameter is provided, datasetName must also be provided.
	*
	* @param {LangfuseAPI.GetDatasetItemsRequest} request
	* @param {DatasetItems.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.datasetItems.list()
	*/
	list(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__list(request, requestOptions));
	}
	async __list(request = {}, requestOptions) {
		const { datasetName, sourceTraceId, sourceObservationId, version, page, limit } = request;
		const _queryParams = {};
		if (datasetName != null) _queryParams["datasetName"] = datasetName;
		if (sourceTraceId != null) _queryParams["sourceTraceId"] = sourceTraceId;
		if (sourceObservationId != null) _queryParams["sourceObservationId"] = sourceObservationId;
		if (version != null) _queryParams["version"] = version;
		if (page != null) _queryParams["page"] = page.toString();
		if (limit != null) _queryParams["limit"] = limit.toString();
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/dataset-items"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/dataset-items.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete a dataset item and all its run items. This action is irreversible.
	*
	* @param {string} id
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {DatasetItems.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.datasetItems.delete("id")
	*/
	delete(id, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__delete(id, requestOptions));
	}
	async __delete(id, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/dataset-items/${encodeURIComponent(id)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/dataset-items/{id}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Datasets = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Get all datasets
	*
	* @param {LangfuseAPI.GetDatasetsRequest} request
	* @param {Datasets.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.datasets.list()
	*/
	list(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__list(request, requestOptions));
	}
	async __list(request = {}, requestOptions) {
		const { page, limit } = request;
		const _queryParams = {};
		if (page != null) _queryParams["page"] = page.toString();
		if (limit != null) _queryParams["limit"] = limit.toString();
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/v2/datasets"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/v2/datasets.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get a dataset
	*
	* @param {string} datasetName
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Datasets.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.datasets.get("datasetName")
	*/
	get(datasetName, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__get(datasetName, requestOptions));
	}
	async __get(datasetName, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/v2/datasets/${encodeURIComponent(datasetName)}`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/v2/datasets/{datasetName}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create a dataset
	*
	* @param {LangfuseAPI.CreateDatasetRequest} request
	* @param {Datasets.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.datasets.create({
	*         name: "name",
	*         description: undefined,
	*         metadata: undefined,
	*         inputSchema: undefined,
	*         expectedOutputSchema: undefined
	*     })
	*/
	create(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__create(request, requestOptions));
	}
	async __create(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/v2/datasets"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/v2/datasets.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var EvaluationRules = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Create an evaluation rule using stable evaluator identifiers.
	*
	* An evaluation rule defines **which** incoming observations should be evaluated and how prompt variables should be populated.
	*
	* Key behavior:
	* - rule names are not identifiers and do not need to be unique
	* - rules always use the latest version of each associated evaluator
	* - an enabled rule requires at least one evaluator assignment
	* - omit `sampling` to evaluate every matching observation
	* - omit `filter` to match every incoming observation
	* - `datasetId` is the public filter name for selecting experiment datasets
	*
	* @param {LangfuseAPI.CreateEvaluationRuleRequest} request
	* @param {EvaluationRules.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.BadRequestError}
	* @throws {@link LangfuseAPI.EvaluationUnauthorizedError}
	* @throws {@link LangfuseAPI.EvaluationAccessDeniedError}
	* @throws {@link LangfuseAPI.EvaluationNotFoundError}
	* @throws {@link LangfuseAPI.EvaluationMethodNotAllowedError}
	* @throws {@link LangfuseAPI.ConflictError}
	* @throws {@link LangfuseAPI.TooManyRequestsError}
	* @throws {@link LangfuseAPI.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.evaluationRules.create({
	*         name: "name",
	*         enabled: true,
	*         sampling: undefined,
	*         filter: undefined,
	*         evaluatorAssignments: [{
	*                 evaluatorId: "evaluatorId",
	*                 variableMapping: undefined
	*             }, {
	*                 evaluatorId: "evaluatorId",
	*                 variableMapping: undefined
	*             }]
	*     })
	*/
	create(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__create(request, requestOptions));
	}
	async __create(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/v2/evaluation-rules"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new EvaluationUnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new EvaluationAccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new EvaluationNotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new EvaluationMethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 409: throw new ConflictError(_response.error.body, _response.rawResponse);
			case 429: throw new TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/v2/evaluation-rules.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* List evaluation rules in newest-first creation order.
	*
	* This includes legacy trace and dataset rules so they can be inspected and migrated. Treat the cursor as opaque and return it unchanged.
	*
	* @param {LangfuseAPI.ListEvaluationRulesRequest} request
	* @param {EvaluationRules.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.BadRequestError}
	* @throws {@link LangfuseAPI.EvaluationUnauthorizedError}
	* @throws {@link LangfuseAPI.EvaluationAccessDeniedError}
	* @throws {@link LangfuseAPI.EvaluationMethodNotAllowedError}
	* @throws {@link LangfuseAPI.TooManyRequestsError}
	* @throws {@link LangfuseAPI.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.evaluationRules.list()
	*/
	list(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__list(request, requestOptions));
	}
	async __list(request = {}, requestOptions) {
		const { limit, cursor } = request;
		const _queryParams = {};
		if (limit != null) _queryParams["limit"] = limit.toString();
		if (cursor != null) _queryParams["cursor"] = cursor;
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/v2/evaluation-rules"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new EvaluationUnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new EvaluationAccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new EvaluationMethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/v2/evaluation-rules.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get one evaluation rule, including a legacy trace or dataset rule, by its stable identifier.
	*
	* @param {string} evaluationRuleId - Stable evaluation-rule identifier returned by the evaluation-rule endpoints.
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {EvaluationRules.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.EvaluationUnauthorizedError}
	* @throws {@link LangfuseAPI.EvaluationAccessDeniedError}
	* @throws {@link LangfuseAPI.EvaluationNotFoundError}
	* @throws {@link LangfuseAPI.EvaluationMethodNotAllowedError}
	* @throws {@link LangfuseAPI.TooManyRequestsError}
	* @throws {@link LangfuseAPI.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.evaluationRules.get("evaluationRuleId")
	*/
	get(evaluationRuleId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__get(evaluationRuleId, requestOptions));
	}
	async __get(evaluationRuleId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/v2/evaluation-rules/${encodeURIComponent(evaluationRuleId)}`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 401: throw new EvaluationUnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new EvaluationAccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new EvaluationNotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new EvaluationMethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/v2/evaluation-rules/{evaluationRuleId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Update an evaluation rule by its stable identifier.
	*
	* Provide only the fields to change. Providing `evaluatorAssignments` replaces the complete assignment list. Replacing the list with an empty array disables the rule. Setting `enabled=true` is rejected when the resulting assignment list is empty, including when both fields are sent in the same request.
	*
	* Legacy trace and dataset rules follow the existing lifecycle restrictions: they can be deactivated with `enabled=false`, but their name, filters, sampling, and evaluator assignments cannot be changed.
	*
	* @param {string} evaluationRuleId - Stable evaluation-rule identifier returned by the evaluation-rule endpoints.
	* @param {LangfuseAPI.UpdateEvaluationRuleRequest} request
	* @param {EvaluationRules.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.BadRequestError}
	* @throws {@link LangfuseAPI.EvaluationUnauthorizedError}
	* @throws {@link LangfuseAPI.EvaluationAccessDeniedError}
	* @throws {@link LangfuseAPI.EvaluationNotFoundError}
	* @throws {@link LangfuseAPI.EvaluationMethodNotAllowedError}
	* @throws {@link LangfuseAPI.ConflictError}
	* @throws {@link LangfuseAPI.TooManyRequestsError}
	* @throws {@link LangfuseAPI.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.evaluationRules.update("evaluationRuleId", {
	*         name: undefined,
	*         enabled: undefined,
	*         sampling: undefined,
	*         filter: undefined,
	*         evaluatorAssignments: undefined
	*     })
	*/
	update(evaluationRuleId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__update(evaluationRuleId, request, requestOptions));
	}
	async __update(evaluationRuleId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/v2/evaluation-rules/${encodeURIComponent(evaluationRuleId)}`),
			method: "PATCH",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new EvaluationUnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new EvaluationAccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new EvaluationNotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new EvaluationMethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 409: throw new ConflictError(_response.error.body, _response.rawResponse);
			case 429: throw new TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PATCH /api/public/v2/evaluation-rules/{evaluationRuleId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete an evaluation rule.
	*
	* This removes the live-ingestion rule only. It does not delete associated evaluators or scores already produced by them.
	*
	* Legacy trace and dataset rules can also be deleted. Their evaluators and previously produced scores are preserved.
	*
	* @param {string} evaluationRuleId - Stable evaluation-rule identifier returned by the evaluation-rule endpoints.
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {EvaluationRules.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.EvaluationUnauthorizedError}
	* @throws {@link LangfuseAPI.EvaluationAccessDeniedError}
	* @throws {@link LangfuseAPI.EvaluationNotFoundError}
	* @throws {@link LangfuseAPI.EvaluationMethodNotAllowedError}
	* @throws {@link LangfuseAPI.TooManyRequestsError}
	* @throws {@link LangfuseAPI.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.evaluationRules.delete("evaluationRuleId")
	*/
	delete(evaluationRuleId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__delete(evaluationRuleId, requestOptions));
	}
	async __delete(evaluationRuleId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/v2/evaluation-rules/${encodeURIComponent(evaluationRuleId)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 401: throw new EvaluationUnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new EvaluationAccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new EvaluationNotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new EvaluationMethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/v2/evaluation-rules/{evaluationRuleId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Evaluators = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Create an evaluator in the authenticated project.
	*
	* An evaluator defines **how** Langfuse should score data. LLM-as-a-judge evaluators define a prompt, expected structured output, and optional model configuration. Code evaluators define source code and a runtime language.
	*
	* This always creates a new evaluator with version `1`. Names are not identifiers and do not need to be unique.
	*
	* @param {LangfuseAPI.CreateEvaluatorRequest} request
	* @param {Evaluators.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.BadRequestError}
	* @throws {@link LangfuseAPI.EvaluationUnauthorizedError}
	* @throws {@link LangfuseAPI.EvaluationAccessDeniedError}
	* @throws {@link LangfuseAPI.EvaluationMethodNotAllowedError}
	* @throws {@link LangfuseAPI.PreconditionFailedError}
	* @throws {@link LangfuseAPI.TooManyRequestsError}
	* @throws {@link LangfuseAPI.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.evaluators.create({
	*         type: "llm_as_judge",
	*         name: "name",
	*         description: undefined,
	*         type: "llm_as_judge",
	*         prompt: "prompt",
	*         modelConfig: undefined,
	*         variableMapping: undefined,
	*         outputDefinition: {
	*             dataType: "NUMERIC",
	*             dataType: "NUMERIC",
	*             minValue: undefined,
	*             maxValue: undefined,
	*             scoreReasoningInstructions: undefined,
	*             scoreValueInstructions: undefined
	*         }
	*     })
	*/
	create(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__create(request, requestOptions));
	}
	async __create(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/v2/evaluators"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new EvaluationUnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new EvaluationAccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new EvaluationMethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 412: throw new PreconditionFailedError(_response.error.body, _response.rawResponse);
			case 429: throw new TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/v2/evaluators.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* List evaluators in newest-first creation order.
	*
	* Every evaluator includes its latest definition and version metadata flattened into the evaluator object, plus associated evaluation rules. Treat the cursor as opaque and return it unchanged.
	*
	* @param {LangfuseAPI.ListEvaluatorsRequest} request
	* @param {Evaluators.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.BadRequestError}
	* @throws {@link LangfuseAPI.EvaluationUnauthorizedError}
	* @throws {@link LangfuseAPI.EvaluationAccessDeniedError}
	* @throws {@link LangfuseAPI.EvaluationMethodNotAllowedError}
	* @throws {@link LangfuseAPI.TooManyRequestsError}
	* @throws {@link LangfuseAPI.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.evaluators.list()
	*/
	list(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__list(request, requestOptions));
	}
	async __list(request = {}, requestOptions) {
		const { limit, cursor } = request;
		const _queryParams = {};
		if (limit != null) _queryParams["limit"] = limit.toString();
		if (cursor != null) _queryParams["cursor"] = cursor;
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/v2/evaluators"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new EvaluationUnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new EvaluationAccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new EvaluationMethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/v2/evaluators.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get one evaluator by its stable identifier.
	*
	* The response includes the evaluator's latest definition and version metadata flattened into the evaluator object, plus associated evaluation rules. Use the version-history endpoint when older definitions are needed.
	*
	* @param {string} evaluatorId - Stable evaluator identifier returned by the evaluator endpoints.
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Evaluators.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.EvaluationUnauthorizedError}
	* @throws {@link LangfuseAPI.EvaluationAccessDeniedError}
	* @throws {@link LangfuseAPI.EvaluationNotFoundError}
	* @throws {@link LangfuseAPI.EvaluationMethodNotAllowedError}
	* @throws {@link LangfuseAPI.TooManyRequestsError}
	* @throws {@link LangfuseAPI.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.evaluators.get("evaluatorId")
	*/
	get(evaluatorId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__get(evaluatorId, requestOptions));
	}
	async __get(evaluatorId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/v2/evaluators/${encodeURIComponent(evaluatorId)}`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 401: throw new EvaluationUnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new EvaluationAccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new EvaluationNotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new EvaluationMethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/v2/evaluators/{evaluatorId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Update an evaluator by its stable identifier.
	*
	* Provide only the top-level fields to change. Metadata-only changes do not create a version. Evaluator type cannot change.
	*
	* Definition fields are flattened into the request. To replace a definition, include `type` and every definition field for that type. Definition fields are replaced as a complete unit rather than merged. For LLM-as-a-judge evaluators, omitting or setting `modelConfig` to `null` selects the project's default evaluation model.
	*
	* Replacing a definition automatically returns an evaluator paused by an invalid or missing model configuration to `active`, while preserving its id and evaluation-rule assignments. Pauses caused by provider authentication, billing, connectivity, account state, or an unknown legacy reason remain paused until the explicit reactivation check succeeds.
	*
	* @param {string} evaluatorId - Stable evaluator identifier returned by the evaluator endpoints.
	* @param {LangfuseAPI.UpdateEvaluatorRequest} request
	* @param {Evaluators.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.BadRequestError}
	* @throws {@link LangfuseAPI.EvaluationUnauthorizedError}
	* @throws {@link LangfuseAPI.EvaluationAccessDeniedError}
	* @throws {@link LangfuseAPI.EvaluationNotFoundError}
	* @throws {@link LangfuseAPI.EvaluationMethodNotAllowedError}
	* @throws {@link LangfuseAPI.ConflictError}
	* @throws {@link LangfuseAPI.PreconditionFailedError}
	* @throws {@link LangfuseAPI.TooManyRequestsError}
	* @throws {@link LangfuseAPI.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.evaluators.update("evaluatorId", {
	*         name: undefined,
	*         description: undefined
	*     })
	*/
	update(evaluatorId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__update(evaluatorId, request, requestOptions));
	}
	async __update(evaluatorId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/v2/evaluators/${encodeURIComponent(evaluatorId)}`),
			method: "PATCH",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new EvaluationUnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new EvaluationAccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new EvaluationNotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new EvaluationMethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 409: throw new ConflictError(_response.error.body, _response.rawResponse);
			case 412: throw new PreconditionFailedError(_response.error.body, _response.rawResponse);
			case 429: throw new TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PATCH /api/public/v2/evaluators/{evaluatorId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete an evaluator and all of its stored versions.
	*
	* Associated evaluation-rule assignments are also removed. Scores already produced by the evaluator are preserved.
	*
	* @param {string} evaluatorId - Stable evaluator identifier returned by the evaluator endpoints.
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Evaluators.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.EvaluationUnauthorizedError}
	* @throws {@link LangfuseAPI.EvaluationAccessDeniedError}
	* @throws {@link LangfuseAPI.EvaluationNotFoundError}
	* @throws {@link LangfuseAPI.EvaluationMethodNotAllowedError}
	* @throws {@link LangfuseAPI.TooManyRequestsError}
	* @throws {@link LangfuseAPI.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.evaluators.delete("evaluatorId")
	*/
	delete(evaluatorId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__delete(evaluatorId, requestOptions));
	}
	async __delete(evaluatorId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/v2/evaluators/${encodeURIComponent(evaluatorId)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 401: throw new EvaluationUnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new EvaluationAccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new EvaluationNotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new EvaluationMethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/v2/evaluators/{evaluatorId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* List an evaluator's version history in newest-first order.
	*
	* This endpoint is intended for history and audit use cases. Ordinary clients can use the flattened `version` and definition fields on the evaluator response.
	*
	* @param {string} evaluatorId - Stable evaluator identifier returned by the evaluator endpoints.
	* @param {LangfuseAPI.ListEvaluatorVersionsRequest} request
	* @param {Evaluators.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.BadRequestError}
	* @throws {@link LangfuseAPI.EvaluationUnauthorizedError}
	* @throws {@link LangfuseAPI.EvaluationAccessDeniedError}
	* @throws {@link LangfuseAPI.EvaluationNotFoundError}
	* @throws {@link LangfuseAPI.EvaluationMethodNotAllowedError}
	* @throws {@link LangfuseAPI.TooManyRequestsError}
	* @throws {@link LangfuseAPI.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.evaluators.listVersions("evaluatorId")
	*/
	listVersions(evaluatorId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__listVersions(evaluatorId, request, requestOptions));
	}
	async __listVersions(evaluatorId, request = {}, requestOptions) {
		const { limit, cursor } = request;
		const _queryParams = {};
		if (limit != null) _queryParams["limit"] = limit.toString();
		if (cursor != null) _queryParams["cursor"] = cursor;
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/v2/evaluators/${encodeURIComponent(evaluatorId)}/versions`),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new EvaluationUnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new EvaluationAccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new EvaluationNotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new EvaluationMethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/v2/evaluators/{evaluatorId}/versions.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Experiments = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* List experiments with cursor-based pagination. Results are ordered by
	* latest experiment activity descending.
	*
	* @param {LangfuseAPI.ListExperimentsRequest} request
	* @param {Experiments.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.experiments.list({
	*         fromStartTime: "2024-01-15T09:30:00Z"
	*     })
	*/
	list(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__list(request, requestOptions));
	}
	async __list(request, requestOptions) {
		const { fields, limit, scoreLimit, cursor, fromStartTime, toStartTime, id, name, datasetId, filter } = request;
		const _queryParams = {};
		if (fields != null) _queryParams["fields"] = fields;
		if (limit != null) _queryParams["limit"] = limit.toString();
		if (scoreLimit != null) _queryParams["scoreLimit"] = scoreLimit.toString();
		if (cursor != null) _queryParams["cursor"] = cursor;
		_queryParams["fromStartTime"] = fromStartTime;
		if (toStartTime != null) _queryParams["toStartTime"] = toStartTime;
		if (id != null) _queryParams["id"] = id;
		if (name != null) _queryParams["name"] = name;
		if (datasetId != null) _queryParams["datasetId"] = datasetId;
		if (filter != null) _queryParams["filter"] = filter;
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/experiments"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/experiments.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* List experiment items with cursor-based pagination. Use this endpoint
	* to export experiment item inputs, outputs, expected outputs, metadata,
	* and optionally item/trace scores. Results are ordered by time
	* descending.
	*
	* @param {LangfuseAPI.ListExperimentItemsRequest} request
	* @param {Experiments.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.experiments.listItems({
	*         fromStartTime: "2024-01-15T09:30:00Z"
	*     })
	*/
	listItems(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__listItems(request, requestOptions));
	}
	async __listItems(request, requestOptions) {
		const { fields, limit, scoreLimit, cursor, fromStartTime, toStartTime, experimentId, experimentName, experimentItemId, datasetId, filter } = request;
		const _queryParams = {};
		if (fields != null) _queryParams["fields"] = fields;
		if (limit != null) _queryParams["limit"] = limit.toString();
		if (scoreLimit != null) _queryParams["scoreLimit"] = scoreLimit.toString();
		if (cursor != null) _queryParams["cursor"] = cursor;
		_queryParams["fromStartTime"] = fromStartTime;
		if (toStartTime != null) _queryParams["toStartTime"] = toStartTime;
		if (experimentId != null) _queryParams["experimentId"] = experimentId;
		if (experimentName != null) _queryParams["experimentName"] = experimentName;
		if (experimentItemId != null) _queryParams["experimentItemId"] = experimentItemId;
		if (datasetId != null) _queryParams["datasetId"] = datasetId;
		if (filter != null) _queryParams["filter"] = filter;
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/experiment-items"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/experiment-items.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Feedback = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Submit explicit user-approved feedback about Langfuse skills, MCP tools, CLI, docs, or public API. Do not include secrets, credentials, customer data, trace payloads, or unrelated use-case details.
	*
	* Not available in the HIPAA cloud region.
	*
	* @param {LangfuseAPI.SubmitFeedbackRequest} request
	* @param {Feedback.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.FeedbackNotConfiguredError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.feedback.submit({
	*         targetType: "skill",
	*         target: "target",
	*         feedback: "feedback",
	*         goal: undefined,
	*         referenceUrl: undefined
	*     })
	*/
	submit(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__submit(request, requestOptions));
	}
	async __submit(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/feedback"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 409: throw new FeedbackNotConfiguredError(_response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/feedback.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Health = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Check health of API and database
	*
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Health.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.ServiceUnavailableError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.health.health()
	*/
	health(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__health(requestOptions));
	}
	async __health(requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/health"),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 503: throw new ServiceUnavailableError(_response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/health.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var LlmConnections = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Get all LLM connections in a project
	*
	* @param {LangfuseAPI.GetLlmConnectionsRequest} request
	* @param {LlmConnections.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.llmConnections.list()
	*/
	list(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__list(request, requestOptions));
	}
	async __list(request = {}, requestOptions) {
		const { page, limit } = request;
		const _queryParams = {};
		if (page != null) _queryParams["page"] = page.toString();
		if (limit != null) _queryParams["limit"] = limit.toString();
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/llm-connections"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/llm-connections.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create or update an LLM connection. The connection is upserted on provider.
	*
	* @param {LangfuseAPI.UpsertLlmConnectionRequest} request
	* @param {LlmConnections.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.llmConnections.upsert({
	*         provider: "provider",
	*         adapter: "anthropic",
	*         secretKey: "secretKey",
	*         baseURL: undefined,
	*         customModels: undefined,
	*         withDefaultModels: undefined,
	*         extraHeaders: undefined,
	*         config: undefined
	*     })
	*/
	upsert(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__upsert(request, requestOptions));
	}
	async __upsert(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/llm-connections"),
			method: "PUT",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PUT /api/public/llm-connections.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete an LLM connection by id. Evaluators that depend on the deleted connection are automatically paused.
	*
	* @param {string} id
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {LlmConnections.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.llmConnections.delete("id")
	*/
	delete(id, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__delete(id, requestOptions));
	}
	async __delete(id, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/llm-connections/${encodeURIComponent(id)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/llm-connections/{id}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Media = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Get a media record
	*
	* @param {string} mediaId - The unique langfuse identifier of a media record
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Media.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.media.get("mediaId")
	*/
	get(mediaId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__get(mediaId, requestOptions));
	}
	async __get(mediaId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/media/${encodeURIComponent(mediaId)}`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/media/{mediaId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Patch a media record
	*
	* @param {string} mediaId - The unique langfuse identifier of a media record
	* @param {LangfuseAPI.PatchMediaBody} request
	* @param {Media.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.media.patch("mediaId", {
	*         uploadedAt: "2024-01-15T09:30:00Z",
	*         uploadHttpStatus: 1,
	*         uploadHttpError: undefined,
	*         uploadTimeMs: undefined
	*     })
	*/
	patch(mediaId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__patch(mediaId, request, requestOptions));
	}
	async __patch(mediaId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/media/${encodeURIComponent(mediaId)}`),
			method: "PATCH",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: void 0,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PATCH /api/public/media/{mediaId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get a presigned upload URL for a media record
	*
	* @param {LangfuseAPI.GetMediaUploadUrlRequest} request
	* @param {Media.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.media.getUploadUrl({
	*         traceId: undefined,
	*         observationId: undefined,
	*         datasetId: undefined,
	*         datasetItemId: undefined,
	*         contentType: "image/png",
	*         contentLength: 1,
	*         sha256Hash: "sha256Hash",
	*         field: "field"
	*     })
	*/
	getUploadUrl(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getUploadUrl(request, requestOptions));
	}
	async __getUploadUrl(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/media"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/media.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Metrics = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Get metrics from the Langfuse project using a query object. V2 endpoint with optimized performance.
	*
	* Together with OpenTelemetry ingestion and Observations API v2, this is the only real-time read path. Other public API endpoints can delay data by about 10 minutes.
	*
	* ## V2 Differences
	* - Supports `observations`, `scores-numeric`, `scores-boolean`, and `scores-categorical` views only (traces view not supported)
	* - Direct access to tags and release fields on observations
	* - Semantic-root filtering and grouping through the v2-only `isRootObservation` dimension
	* - Backwards-compatible: traceName, traceRelease, traceVersion dimensions are still available on observations view
	* - High cardinality dimensions are not supported and will return a 400 error (see below)
	*
	* For more details, see the [Metrics API documentation](https://langfuse.com/docs/metrics/features/metrics-api).
	*
	* ## Available Views
	*
	* ### observations
	* Query observation-level data (spans, generations, events).
	*
	* **Dimensions:**
	* - `environment` - Deployment environment (e.g., production, staging)
	* - `type` - Type of observation (SPAN, GENERATION, EVENT)
	* - `name` - Name of the observation
	* - `level` - Logging level of the observation
	* - `version` - Version of the observation
	* - `tags` - User-defined tags
	* - `release` - Release version
	* - `traceName` - Name of the parent trace (backwards-compatible)
	* - `traceRelease` - Release version of the parent trace (backwards-compatible, maps to release)
	* - `traceVersion` - Version of the parent trace (backwards-compatible, maps to version)
	* - `providedModelName` - Name of the model used
	* - `promptName` - Name of the prompt used
	* - `promptVersion` - Version of the prompt used
	* - `isRootObservation` - Boolean semantic-root status. `true` includes physical roots and app roots whose SDK parent is external (so `parentObservationId` may be non-null).
	* - `startTimeMonth` - Month of start_time in YYYY-MM format
	*
	* **Measures:**
	* - `count` - Total number of observations
	* - `latency` - Observation latency (milliseconds)
	* - `streamingLatency` - Generation latency from completion start to end (milliseconds)
	* - `inputTokens` - Sum of input tokens consumed
	* - `outputTokens` - Sum of output tokens produced
	* - `totalTokens` - Sum of all tokens consumed
	* - `outputTokensPerSecond` - Output tokens per second
	* - `tokensPerSecond` - Total tokens per second
	* - `inputCost` - Input cost (USD)
	* - `outputCost` - Output cost (USD)
	* - `totalCost` - Total cost (USD)
	* - `timeToFirstToken` - Time to first token (milliseconds)
	* - `countScores` - Number of scores attached to the observation
	*
	* ### scores-numeric
	* Query numeric and boolean score data.
	*
	* **Dimensions:**
	* - `environment` - Deployment environment
	* - `name` - Name of the score (e.g., accuracy, toxicity)
	* - `source` - Origin of the score (API, ANNOTATION, EVAL)
	* - `dataType` - Data type (NUMERIC, BOOLEAN)
	* - `configId` - Identifier of the score config
	* - `timestampMonth` - Month in YYYY-MM format
	* - `timestampDay` - Day in YYYY-MM-DD format
	* - `value` - Numeric value of the score
	* - `traceName` - Name of the parent trace
	* - `tags` - Tags
	* - `traceRelease` - Release version
	* - `traceVersion` - Version
	* - `observationName` - Name of the associated observation
	* - `observationModelName` - Model name of the associated observation
	* - `observationPromptName` - Prompt name of the associated observation
	* - `observationPromptVersion` - Prompt version of the associated observation
	*
	* **Measures:**
	* - `count` - Total number of scores
	* - `value` - Score value (for aggregations)
	*
	* ### scores-boolean
	* Query boolean score data. It has the same score and parent trace/observation dimensions as scores-numeric, plus:
	*
	* **Dimensions:**
	* - `booleanValue` - Boolean value for true/false grouping and filtering
	*
	* **Measures:**
	* - `count` - Total number of boolean scores
	* - `value` - Numeric 0/1 score value; `avg` returns the true-rate
	*
	* ### scores-categorical
	* Query categorical score data. Same dimensions as scores-numeric except uses `stringValue` instead of `value`.
	*
	* **Measures:**
	* - `count` - Total number of scores
	*
	* ## High Cardinality Dimensions
	* The following dimensions cannot be used as grouping dimensions in v2 metrics API as they can cause performance issues.
	* Use them in filters instead.
	*
	* **observations view:**
	* - `id` - Use traceId filter to narrow down results
	* - `traceId` - Use traceId filter instead
	* - `userId` - Use userId filter instead
	* - `sessionId` - Use sessionId filter instead
	* - `parentObservationId` - Use parentObservationId filter instead
	*
	* **scores-numeric / scores-boolean / scores-categorical views:**
	* - `id` - Use specific filters to narrow down results
	* - `traceId` - Use traceId filter instead
	* - `userId` - Use userId filter instead
	* - `sessionId` - Use sessionId filter instead
	* - `observationId` - Use observationId filter instead
	*
	* ## Aggregations
	* Available aggregation functions: `sum`, `avg`, `count`, `max`, `min`, `p50`, `p75`, `p90`, `p95`, `p99`, `histogram`
	*
	* ## Time Granularities
	* Available granularities for timeDimension: `auto`, `minute`, `hour`, `day`, `week`, `month`
	* - `auto` bins the data into approximately 50 buckets based on the time range
	*
	* @param {LangfuseAPI.GetMetricsV2Request} request
	* @param {Metrics.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.metrics.metrics({
	*         query: "query"
	*     })
	*/
	metrics(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__metrics(request, requestOptions));
	}
	async __metrics(request, requestOptions) {
		const { query } = request;
		const _queryParams = {};
		_queryParams["query"] = query;
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/v2/metrics"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/v2/metrics.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Models = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Create a model
	*
	* @param {LangfuseAPI.CreateModelRequest} request
	* @param {Models.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.models.create({
	*         modelName: "modelName",
	*         matchPattern: "matchPattern",
	*         startDate: undefined,
	*         unit: "CHARACTERS",
	*         inputPrice: undefined,
	*         outputPrice: undefined,
	*         totalPrice: undefined,
	*         pricingTiers: undefined,
	*         tokenizerId: undefined,
	*         tokenizerConfig: undefined
	*     })
	*/
	create(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__create(request, requestOptions));
	}
	async __create(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/models"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/models.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create or replace a project-owned model using its id. Built-in models cannot be modified.
	*
	* @param {string} id
	* @param {LangfuseAPI.CreateModelRequest} request
	* @param {Models.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.models.upsert("id", {
	*         modelName: "modelName",
	*         matchPattern: "matchPattern",
	*         startDate: undefined,
	*         unit: "CHARACTERS",
	*         inputPrice: undefined,
	*         outputPrice: undefined,
	*         totalPrice: undefined,
	*         pricingTiers: undefined,
	*         tokenizerId: undefined,
	*         tokenizerConfig: undefined
	*     })
	*/
	upsert(id, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__upsert(id, request, requestOptions));
	}
	async __upsert(id, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/models/${encodeURIComponent(id)}`),
			method: "PUT",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PUT /api/public/models/{id}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get all models
	*
	* @param {LangfuseAPI.GetModelsRequest} request
	* @param {Models.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.models.list()
	*/
	list(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__list(request, requestOptions));
	}
	async __list(request = {}, requestOptions) {
		const { page, limit } = request;
		const _queryParams = {};
		if (page != null) _queryParams["page"] = page.toString();
		if (limit != null) _queryParams["limit"] = limit.toString();
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/models"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/models.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get a model
	*
	* @param {string} id
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Models.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.models.get("id")
	*/
	get(id, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__get(id, requestOptions));
	}
	async __get(id, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/models/${encodeURIComponent(id)}`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/models/{id}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete a model. Cannot delete models managed by Langfuse. You can create your own definition with the same modelName to override the definition though.
	*
	* @param {string} id
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Models.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.models.delete("id")
	*/
	delete(id, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__delete(id, requestOptions));
	}
	async __delete(id, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/models/${encodeURIComponent(id)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: void 0,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/models/{id}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Observations = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Get a list of observations with cursor-based pagination and flexible field selection.
	*
	* Together with OpenTelemetry ingestion and Metrics API v2, this is the only real-time read path. Other public API endpoints can delay data by about 10 minutes.
	*
	* ## Cursor-based Pagination
	* This endpoint uses cursor-based pagination for efficient traversal of large datasets.
	* The cursor is returned in the response metadata and should be passed in subsequent requests
	* to retrieve the next page of results.
	*
	* ## Field Selection
	* Use the `fields` parameter to control which observation fields are returned:
	* - `core` - Always included: id, traceId, startTime, endTime, projectId, parentObservationId, type
	* - `basic` - name, level, statusMessage, version, environment, bookmarked, public, userId, sessionId, isRootObservation
	* - `time` - completionStartTime, createdAt, updatedAt
	* - `io` - input, output
	* - `metadata` - metadata (truncated to 200 chars by default, use `expandMetadata` to get full values)
	* - `model` - model, internalModelId, modelParameters
	* - `usage` - usageDetails, costDetails, totalCost, usagePricingTierName
	* - `prompt` - promptId, promptName, promptVersion
	* - `metrics` - latency, timeToFirstToken
	* - `trace_context` - tags, release, traceName
	*
	* If not specified, `core` and `basic` field groups are returned.
	*
	* ## Filters
	* Multiple filtering options are available via query parameters or the structured `filter` parameter.
	* When using the `filter` parameter, it takes precedence over individual query parameter filters.
	*
	* @param {LangfuseAPI.GetObservationsV2Request} request
	* @param {Observations.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.observations.getMany()
	*/
	getMany(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getMany(request, requestOptions));
	}
	async __getMany(request = {}, requestOptions) {
		const { fields, expandMetadata, limit, cursor, parseIoAsJson, name, userId, sessionId, type: type_, traceId, level, parentObservationId, isRootObservation, environment, fromStartTime, toStartTime, version, filter } = request;
		const _queryParams = {};
		if (fields != null) _queryParams["fields"] = fields;
		if (expandMetadata != null) _queryParams["expandMetadata"] = expandMetadata;
		if (limit != null) _queryParams["limit"] = limit.toString();
		if (cursor != null) _queryParams["cursor"] = cursor;
		if (parseIoAsJson != null) _queryParams["parseIoAsJson"] = parseIoAsJson.toString();
		if (name != null) _queryParams["name"] = name;
		if (userId != null) _queryParams["userId"] = userId;
		if (sessionId != null) _queryParams["sessionId"] = sessionId;
		if (type_ != null) _queryParams["type"] = type_;
		if (traceId != null) _queryParams["traceId"] = traceId;
		if (level != null) _queryParams["level"] = level;
		if (parentObservationId != null) _queryParams["parentObservationId"] = parentObservationId;
		if (isRootObservation != null) _queryParams["isRootObservation"] = isRootObservation.toString();
		if (environment != null) {
			if (Array.isArray(environment)) _queryParams["environment"] = environment.map((item) => item);
			else _queryParams["environment"] = environment;
		}
		if (fromStartTime != null) _queryParams["fromStartTime"] = fromStartTime;
		if (toStartTime != null) _queryParams["toStartTime"] = toStartTime;
		if (version != null) _queryParams["version"] = version;
		if (filter != null) _queryParams["filter"] = filter;
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/v2/observations"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/v2/observations.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Opentelemetry = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* **OpenTelemetry Traces Ingestion Endpoint**
	*
	* This endpoint implements the OTLP/HTTP specification for trace ingestion, providing native OpenTelemetry integration for Langfuse Observability.
	*
	* Together with Observations API v2 and Metrics API v2, this is the only real-time write path. Other public API endpoints can delay data by about 10 minutes. Direct exporters must send `x-langfuse-ingestion-version: 4`; current Python and JS SDKs already do.
	*
	* **Supported Formats:**
	* - Binary Protobuf: `Content-Type: application/x-protobuf`
	* - JSON Protobuf: `Content-Type: application/json`
	* - Supports gzip compression via `Content-Encoding: gzip` header
	*
	* **Specification Compliance:**
	* - Conforms to [OTLP/HTTP Trace Export](https://opentelemetry.io/docs/specs/otlp/#otlphttp)
	* - Implements `ExportTraceServiceRequest` message format
	*
	* **Documentation:**
	* - Integration guide: https://langfuse.com/integrations/native/opentelemetry
	* - Data model: https://langfuse.com/docs/observability/data-model
	*
	* @param {LangfuseAPI.OtelTraceRequest} request
	* @param {Opentelemetry.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.opentelemetry.exportTraces({
	*         resourceSpans: [{
	*                 resource: {
	*                     attributes: [{
	*                             key: "service.name",
	*                             value: {
	*                                 stringValue: "my-service"
	*                             }
	*                         }, {
	*                             key: "service.version",
	*                             value: {
	*                                 stringValue: "1.0.0"
	*                             }
	*                         }]
	*                 },
	*                 scopeSpans: [{
	*                         scope: {
	*                             name: "langfuse-sdk",
	*                             version: "2.60.3"
	*                         },
	*                         spans: [{
	*                                 traceId: "0123456789abcdef0123456789abcdef",
	*                                 spanId: "0123456789abcdef",
	*                                 name: "my-operation",
	*                                 kind: 1,
	*                                 startTimeUnixNano: "1747872000000000000",
	*                                 endTimeUnixNano: "1747872001000000000",
	*                                 attributes: [{
	*                                         key: "langfuse.observation.type",
	*                                         value: {
	*                                             stringValue: "generation"
	*                                         }
	*                                     }],
	*                                 status: {}
	*                             }]
	*                     }]
	*             }]
	*     })
	*/
	exportTraces(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__exportTraces(request, requestOptions));
	}
	async __exportTraces(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/otel/v1/traces"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/otel/v1/traces.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Organizations = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Get all memberships for the organization associated with the API key (requires organization-scoped API key)
	*
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Organizations.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.organizations.getOrganizationMemberships()
	*/
	getOrganizationMemberships(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getOrganizationMemberships(requestOptions));
	}
	async __getOrganizationMemberships(requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/organizations/memberships"),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/organizations/memberships.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create or update a membership for the organization associated with the API key (requires organization-scoped API key)
	*
	* @param {LangfuseAPI.MembershipRequest} request
	* @param {Organizations.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.organizations.updateOrganizationMembership({
	*         userId: "userId",
	*         role: "OWNER"
	*     })
	*/
	updateOrganizationMembership(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__updateOrganizationMembership(request, requestOptions));
	}
	async __updateOrganizationMembership(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/organizations/memberships"),
			method: "PUT",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PUT /api/public/organizations/memberships.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete a membership from the organization associated with the API key (requires organization-scoped API key)
	*
	* @param {LangfuseAPI.DeleteMembershipRequest} request
	* @param {Organizations.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.organizations.deleteOrganizationMembership({
	*         userId: "userId"
	*     })
	*/
	deleteOrganizationMembership(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__deleteOrganizationMembership(request, requestOptions));
	}
	async __deleteOrganizationMembership(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/organizations/memberships"),
			method: "DELETE",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/organizations/memberships.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get all memberships for a specific project (requires organization-scoped API key)
	*
	* @param {string} projectId
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Organizations.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.organizations.getProjectMemberships("projectId")
	*/
	getProjectMemberships(projectId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getProjectMemberships(projectId, requestOptions));
	}
	async __getProjectMemberships(projectId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/projects/${encodeURIComponent(projectId)}/memberships`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/projects/{projectId}/memberships.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create or update a membership for a specific project (requires organization-scoped API key). The user must already be a member of the organization.
	*
	* @param {string} projectId
	* @param {LangfuseAPI.MembershipRequest} request
	* @param {Organizations.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.organizations.updateProjectMembership("projectId", {
	*         userId: "userId",
	*         role: "OWNER"
	*     })
	*/
	updateProjectMembership(projectId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__updateProjectMembership(projectId, request, requestOptions));
	}
	async __updateProjectMembership(projectId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/projects/${encodeURIComponent(projectId)}/memberships`),
			method: "PUT",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PUT /api/public/projects/{projectId}/memberships.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete a membership from a specific project (requires organization-scoped API key). The user must be a member of the organization.
	*
	* @param {string} projectId
	* @param {LangfuseAPI.DeleteMembershipRequest} request
	* @param {Organizations.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.organizations.deleteProjectMembership("projectId", {
	*         userId: "userId"
	*     })
	*/
	deleteProjectMembership(projectId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__deleteProjectMembership(projectId, request, requestOptions));
	}
	async __deleteProjectMembership(projectId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/projects/${encodeURIComponent(projectId)}/memberships`),
			method: "DELETE",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/projects/{projectId}/memberships.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get all projects for the organization associated with the API key (requires organization-scoped API key)
	*
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Organizations.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.organizations.getOrganizationProjects()
	*/
	getOrganizationProjects(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getOrganizationProjects(requestOptions));
	}
	async __getOrganizationProjects(requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/organizations/projects"),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/organizations/projects.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get all API keys for the organization associated with the API key (requires organization-scoped API key)
	*
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Organizations.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.organizations.getOrganizationApiKeys()
	*/
	getOrganizationApiKeys(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getOrganizationApiKeys(requestOptions));
	}
	async __getOrganizationApiKeys(requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/organizations/apiKeys"),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/organizations/apiKeys.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Projects = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Get Project associated with API key (requires project-scoped API key). You can use GET /api/public/organizations/projects to get all projects with an organization-scoped key.
	*
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Projects.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.projects.get()
	*/
	get(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__get(requestOptions));
	}
	async __get(requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/projects"),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/projects.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create a new project (requires organization-scoped API key)
	*
	* @param {LangfuseAPI.CreateProjectRequest} request
	* @param {Projects.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.projects.create({
	*         name: "name",
	*         metadata: undefined,
	*         retention: 1
	*     })
	*/
	create(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__create(request, requestOptions));
	}
	async __create(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/projects"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/projects.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Update a project by ID (requires organization-scoped API key).
	*
	* @param {string} projectId
	* @param {LangfuseAPI.UpdateProjectRequest} request
	* @param {Projects.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.projects.update("projectId", {
	*         name: "name",
	*         metadata: undefined,
	*         retention: undefined
	*     })
	*/
	update(projectId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__update(projectId, request, requestOptions));
	}
	async __update(projectId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/projects/${encodeURIComponent(projectId)}`),
			method: "PUT",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PUT /api/public/projects/{projectId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete a project by ID (requires organization-scoped API key). Project deletion is processed asynchronously.
	*
	* @param {string} projectId
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Projects.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.projects.delete("projectId")
	*/
	delete(projectId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__delete(projectId, requestOptions));
	}
	async __delete(projectId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/projects/${encodeURIComponent(projectId)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/projects/{projectId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get all API keys for a project (requires organization-scoped API key)
	*
	* @param {string} projectId
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Projects.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.projects.getApiKeys("projectId")
	*/
	getApiKeys(projectId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getApiKeys(projectId, requestOptions));
	}
	async __getApiKeys(projectId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/projects/${encodeURIComponent(projectId)}/apiKeys`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/projects/{projectId}/apiKeys.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create a new API key for a project (requires organization-scoped API key)
	*
	* @param {string} projectId
	* @param {LangfuseAPI.CreateApiKeyRequest} request
	* @param {Projects.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.projects.createApiKey("projectId", {
	*         name: undefined,
	*         note: undefined,
	*         expiresAt: undefined,
	*         publicKey: undefined,
	*         secretKey: undefined
	*     })
	*/
	createApiKey(projectId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__createApiKey(projectId, request, requestOptions));
	}
	async __createApiKey(projectId, request = {}, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/projects/${encodeURIComponent(projectId)}/apiKeys`),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/projects/{projectId}/apiKeys.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete an API key for a project (requires organization-scoped API key)
	*
	* @param {string} projectId
	* @param {string} apiKeyId
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Projects.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.projects.deleteApiKey("projectId", "apiKeyId")
	*/
	deleteApiKey(projectId, apiKeyId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__deleteApiKey(projectId, apiKeyId, requestOptions));
	}
	async __deleteApiKey(projectId, apiKeyId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/projects/${encodeURIComponent(projectId)}/apiKeys/${encodeURIComponent(apiKeyId)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/projects/{projectId}/apiKeys/{apiKeyId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var PromptVersion = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Update labels for a specific prompt version
	*
	* @param {string} name - The name of the prompt. If the prompt is in a folder (e.g., "folder/subfolder/prompt-name"),
	*                        the folder path must be URL encoded.
	* @param {number} version - Version of the prompt to update
	* @param {LangfuseAPI.UpdatePromptRequest} request
	* @param {PromptVersion.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.promptVersion.update("name", 1, {
	*         newLabels: ["newLabels", "newLabels"]
	*     })
	*/
	update(name, version, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__update(name, version, request, requestOptions));
	}
	async __update(name, version, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/v2/prompts/${encodeURIComponent(name)}/versions/${encodeURIComponent(version)}`),
			method: "PATCH",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PATCH /api/public/v2/prompts/{name}/versions/{version}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Prompts = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Get a prompt
	*
	* @param {string} promptName - The name of the prompt. If the prompt is in a folder (e.g., "folder/subfolder/prompt-name"),
	*                              the folder path must be URL encoded.
	* @param {LangfuseAPI.GetPromptRequest} request
	* @param {Prompts.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.prompts.get("promptName")
	*/
	get(promptName, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__get(promptName, request, requestOptions));
	}
	async __get(promptName, request = {}, requestOptions) {
		const { version, label, resolve } = request;
		const _queryParams = {};
		if (version != null) _queryParams["version"] = version.toString();
		if (label != null) _queryParams["label"] = label;
		if (resolve != null) _queryParams["resolve"] = resolve.toString();
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/v2/prompts/${encodeURIComponent(promptName)}`),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/v2/prompts/{promptName}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get a list of prompt names with versions and labels
	*
	* @param {LangfuseAPI.ListPromptsMetaRequest} request
	* @param {Prompts.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.prompts.list()
	*/
	list(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__list(request, requestOptions));
	}
	async __list(request = {}, requestOptions) {
		const { name, label, tag, page, limit, fromUpdatedAt, toUpdatedAt, filter } = request;
		const _queryParams = {};
		if (name != null) _queryParams["name"] = name;
		if (label != null) _queryParams["label"] = label;
		if (tag != null) _queryParams["tag"] = tag;
		if (page != null) _queryParams["page"] = page.toString();
		if (limit != null) _queryParams["limit"] = limit.toString();
		if (fromUpdatedAt != null) _queryParams["fromUpdatedAt"] = fromUpdatedAt;
		if (toUpdatedAt != null) _queryParams["toUpdatedAt"] = toUpdatedAt;
		if (filter != null) _queryParams["filter"] = filter;
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/v2/prompts"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/v2/prompts.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create a new version for the prompt with the given `name`
	*
	* @param {LangfuseAPI.CreatePromptRequest} request
	* @param {Prompts.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.prompts.create({
	*         name: "name",
	*         prompt: [{
	*                 role: "role",
	*                 content: "content",
	*                 type: undefined
	*             }, {
	*                 role: "role",
	*                 content: "content",
	*                 type: undefined
	*             }],
	*         config: undefined,
	*         type: "chat",
	*         labels: undefined,
	*         tags: undefined,
	*         commitMessage: undefined
	*     })
	*/
	create(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__create(request, requestOptions));
	}
	async __create(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/v2/prompts"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/v2/prompts.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete prompt versions. If neither version nor label is specified, all versions of the prompt are deleted.
	*
	* @param {string} promptName - The name of the prompt
	* @param {LangfuseAPI.DeletePromptRequest} request
	* @param {Prompts.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.prompts.delete("promptName")
	*/
	delete(promptName, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__delete(promptName, request, requestOptions));
	}
	async __delete(promptName, request = {}, requestOptions) {
		const { label, version } = request;
		const _queryParams = {};
		if (label != null) _queryParams["label"] = label;
		if (version != null) _queryParams["version"] = version.toString();
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/v2/prompts/${encodeURIComponent(promptName)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: void 0,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/v2/prompts/{promptName}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Scim = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Get SCIM Service Provider Configuration (requires organization-scoped API key)
	*
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Scim.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.scim.getServiceProviderConfig()
	*/
	getServiceProviderConfig(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getServiceProviderConfig(requestOptions));
	}
	async __getServiceProviderConfig(requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/scim/ServiceProviderConfig"),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/scim/ServiceProviderConfig.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get SCIM Resource Types (requires organization-scoped API key)
	*
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Scim.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.scim.getResourceTypes()
	*/
	getResourceTypes(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getResourceTypes(requestOptions));
	}
	async __getResourceTypes(requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/scim/ResourceTypes"),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/scim/ResourceTypes.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get SCIM Schemas (requires organization-scoped API key)
	*
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Scim.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.scim.getSchemas()
	*/
	getSchemas(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getSchemas(requestOptions));
	}
	async __getSchemas(requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/scim/Schemas"),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/scim/Schemas.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* List users in the organization (requires organization-scoped API key)
	*
	* @param {LangfuseAPI.ListUsersRequest} request
	* @param {Scim.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.scim.listUsers()
	*/
	listUsers(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__listUsers(request, requestOptions));
	}
	async __listUsers(request = {}, requestOptions) {
		const { filter, startIndex, count } = request;
		const _queryParams = {};
		if (filter != null) _queryParams["filter"] = filter;
		if (startIndex != null) _queryParams["startIndex"] = startIndex.toString();
		if (count != null) _queryParams["count"] = count.toString();
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/scim/Users"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/scim/Users.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create a new user in the organization (requires organization-scoped API key)
	*
	* @param {LangfuseAPI.CreateUserRequest} request
	* @param {Scim.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.scim.createUser({
	*         userName: "userName",
	*         name: {
	*             formatted: undefined
	*         },
	*         emails: undefined,
	*         active: undefined,
	*         password: undefined
	*     })
	*/
	createUser(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__createUser(request, requestOptions));
	}
	async __createUser(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/scim/Users"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/scim/Users.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get a specific user by ID (requires organization-scoped API key)
	*
	* @param {string} userId
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Scim.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.scim.getUser("userId")
	*/
	getUser(userId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getUser(userId, requestOptions));
	}
	async __getUser(userId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/scim/Users/${encodeURIComponent(userId)}`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/scim/Users/{userId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Remove a user from the organization (requires organization-scoped API key). Note that this only removes the user from the organization but does not delete the user entity itself.
	*
	* @param {string} userId
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Scim.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.scim.deleteUser("userId")
	*/
	deleteUser(userId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__deleteUser(userId, requestOptions));
	}
	async __deleteUser(userId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/scim/Users/${encodeURIComponent(userId)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/scim/Users/{userId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var ScoreConfigs = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Create a score configuration (config). Score configs are used to define the structure of scores
	*
	* @param {LangfuseAPI.CreateScoreConfigRequest} request
	* @param {ScoreConfigs.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.scoreConfigs.create({
	*         name: "name",
	*         dataType: "NUMERIC",
	*         categories: undefined,
	*         minValue: undefined,
	*         maxValue: undefined,
	*         description: undefined
	*     })
	*/
	create(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__create(request, requestOptions));
	}
	async __create(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/score-configs"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/score-configs.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get all score configs
	*
	* @param {LangfuseAPI.GetScoreConfigsRequest} request
	* @param {ScoreConfigs.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.scoreConfigs.get()
	*/
	get(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__get(request, requestOptions));
	}
	async __get(request = {}, requestOptions) {
		const { page, limit } = request;
		const _queryParams = {};
		if (page != null) _queryParams["page"] = page.toString();
		if (limit != null) _queryParams["limit"] = limit.toString();
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/score-configs"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/score-configs.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get a score config
	*
	* @param {string} configId - The unique langfuse identifier of a score config
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {ScoreConfigs.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.scoreConfigs.getById("configId")
	*/
	getById(configId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getById(configId, requestOptions));
	}
	async __getById(configId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/score-configs/${encodeURIComponent(configId)}`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/score-configs/{configId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Update a score config
	*
	* @param {string} configId - The unique langfuse identifier of a score config
	* @param {LangfuseAPI.UpdateScoreConfigRequest} request
	* @param {ScoreConfigs.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.scoreConfigs.update("configId", {
	*         isArchived: undefined,
	*         name: undefined,
	*         categories: undefined,
	*         minValue: undefined,
	*         maxValue: undefined,
	*         description: undefined
	*     })
	*/
	update(configId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__update(configId, request, requestOptions));
	}
	async __update(configId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/score-configs/${encodeURIComponent(configId)}`),
			method: "PATCH",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PATCH /api/public/score-configs/{configId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Scores = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Create scores asynchronously from a list of scores. Returns 202 if all scores are accepted, or 207 with accepted/rejected counts and error messages. Do not automatically retry a 207 batch. The generated reference shows only 200; the endpoint returns 202 or 207.
	*
	* @param {LangfuseAPI.CreateScoresRequest} request
	* @param {Scores.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.scores.create([{
	*             id: undefined,
	*             traceId: undefined,
	*             sessionId: undefined,
	*             observationId: undefined,
	*             datasetRunId: undefined,
	*             name: "name",
	*             value: 1.1,
	*             comment: undefined,
	*             metadata: undefined,
	*             environment: undefined,
	*             queueId: undefined,
	*             dataType: undefined,
	*             configId: undefined,
	*             source: undefined,
	*             timestamp: undefined
	*         }, {
	*             id: undefined,
	*             traceId: undefined,
	*             sessionId: undefined,
	*             observationId: undefined,
	*             datasetRunId: undefined,
	*             name: "name",
	*             value: 1.1,
	*             comment: undefined,
	*             metadata: undefined,
	*             environment: undefined,
	*             queueId: undefined,
	*             dataType: undefined,
	*             configId: undefined,
	*             source: undefined,
	*             timestamp: undefined
	*         }])
	*/
	create(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__create(request, requestOptions));
	}
	async __create(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/scores"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/scores.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete a score (supports both trace and session scores)
	*
	* @param {string} scoreId - The unique langfuse identifier of a score
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Scores.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.scores.delete("scoreId")
	*/
	delete(scoreId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__delete(scoreId, requestOptions));
	}
	async __delete(scoreId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/scores/${encodeURIComponent(scoreId)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: void 0,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/scores/{scoreId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get a list of scores with a polymorphic `value` field (v3).
	*
	* The `value` field type depends on `dataType`:
	* - `NUMERIC` → number
	* - `BOOLEAN` → boolean
	* - `CATEGORICAL`, `TEXT`, `CORRECTION` → string
	*
	* The response always includes the core fields: id, projectId, name,
	* value, dataType, source, timestamp, environment, createdAt, updatedAt.
	*
	* Additional field groups can be requested via the `fields` parameter:
	* - `details` — adds comment, configId, metadata
	* - `subject` — adds the subject object describing the entity the score
	*   is attached to: kind (trace, observation, session, or experiment),
	*   id, and traceId for observation-level scores
	* - `annotation` — adds authorUserId, queueId
	*
	* Unknown group names return HTTP 400.
	*
	* @param {LangfuseAPI.GetScoresV3Request} request
	* @param {Scores.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.scores.getMany()
	*/
	getMany(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getMany(request, requestOptions));
	}
	async __getMany(request = {}, requestOptions) {
		const { limit, cursor, fields, id, name, source, dataType, environment, configId, queueId, authorUserId, value, valueMin, valueMax, traceId, sessionId, observationId, experimentId, fromTimestamp, toTimestamp } = request;
		const _queryParams = {};
		if (limit != null) _queryParams["limit"] = limit.toString();
		if (cursor != null) _queryParams["cursor"] = cursor;
		if (fields != null) _queryParams["fields"] = fields;
		if (id != null) _queryParams["id"] = id;
		if (name != null) _queryParams["name"] = name;
		if (source != null) _queryParams["source"] = source;
		if (dataType != null) _queryParams["dataType"] = dataType;
		if (environment != null) _queryParams["environment"] = environment;
		if (configId != null) _queryParams["configId"] = configId;
		if (queueId != null) _queryParams["queueId"] = queueId;
		if (authorUserId != null) _queryParams["authorUserId"] = authorUserId;
		if (value != null) _queryParams["value"] = value;
		if (valueMin != null) _queryParams["valueMin"] = valueMin.toString();
		if (valueMax != null) _queryParams["valueMax"] = valueMax.toString();
		if (traceId != null) _queryParams["traceId"] = traceId;
		if (sessionId != null) _queryParams["sessionId"] = sessionId;
		if (observationId != null) _queryParams["observationId"] = observationId;
		if (experimentId != null) _queryParams["experimentId"] = experimentId;
		if (fromTimestamp != null) _queryParams["fromTimestamp"] = fromTimestamp;
		if (toTimestamp != null) _queryParams["toTimestamp"] = toTimestamp;
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/v3/scores"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/v3/scores.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Trace = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* Delete a specific trace
	*
	* @param {string} traceId - The unique langfuse identifier of the trace to delete
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Trace.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.trace.delete("traceId")
	*/
	delete(traceId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__delete(traceId, requestOptions));
	}
	async __delete(traceId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/traces/${encodeURIComponent(traceId)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/traces/{traceId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete multiple traces
	*
	* @param {LangfuseAPI.DeleteTracesRequest} request
	* @param {Trace.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.trace.deleteMultiple({
	*         traceIds: ["traceIds", "traceIds"]
	*     })
	*/
	deleteMultiple(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__deleteMultiple(request, requestOptions));
	}
	async __deleteMultiple(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/traces"),
			method: "DELETE",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/traces.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var DashboardWidgets = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* List dashboard widgets in the project, ordered by most recently
	* updated first.
	*
	* Responses may include legacy `traces` widgets created before this
	* API existed. New widgets cannot be created with `view: traces`.
	*
	* @param {LangfuseAPI.unstable.ListDashboardWidgetsRequest} request
	* @param {DashboardWidgets.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.unstable.BadRequestError}
	* @throws {@link LangfuseAPI.unstable.UnauthorizedError}
	* @throws {@link LangfuseAPI.unstable.AccessDeniedError}
	* @throws {@link LangfuseAPI.unstable.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.unstable.TooManyRequestsError}
	* @throws {@link LangfuseAPI.unstable.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.dashboardWidgets.list()
	*/
	list(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__list(request, requestOptions));
	}
	async __list(request = {}, requestOptions) {
		const { page, limit } = request;
		const _queryParams = {};
		if (page != null) _queryParams["page"] = page.toString();
		if (limit != null) _queryParams["limit"] = limit.toString();
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/unstable/dashboard-widgets"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new unstable_exports.BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new unstable_exports.UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new unstable_exports.AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new unstable_exports.MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new unstable_exports.TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new unstable_exports.InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/unstable/dashboard-widgets.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create a dashboard widget (a standalone chart definition you place on
	* any dashboard).
	*
	* This endpoint creates the widget only; place it on a dashboard via
	* `POST /dashboards/{dashboardId}/placements`.
	*
	* Supported views are `observations`, `scores-numeric`, `scores-boolean`, and `scores-categorical`.
	* The legacy `traces` view is not supported by this unstable API.
	* Widgets are created as v2 internally.
	*
	* `chartConfig` is optional and defaults to the plain config for
	* `chartType`; when `chartConfig.type` is given it must match
	* `chartType`.
	*
	* Unstable API note:
	* - This surface may evolve while dashboard/widget APIs are being finalized.
	*
	* @param {LangfuseAPI.unstable.CreateDashboardWidgetRequest} request
	* @param {DashboardWidgets.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.unstable.BadRequestError}
	* @throws {@link LangfuseAPI.unstable.UnauthorizedError}
	* @throws {@link LangfuseAPI.unstable.AccessDeniedError}
	* @throws {@link LangfuseAPI.unstable.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.unstable.TooManyRequestsError}
	* @throws {@link LangfuseAPI.unstable.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.dashboardWidgets.create({
	*         name: "Total cost by model",
	*         description: "Total model cost grouped by provided model name.",
	*         view: "observations",
	*         dimensions: [{
	*                 field: "providedModelName"
	*             }],
	*         metrics: [{
	*                 measure: "totalCost",
	*                 agg: "sum"
	*             }],
	*         filters: [],
	*         chartType: "HORIZONTAL_BAR",
	*         chartConfig: {
	*             row_limit: 10
	*         }
	*     })
	*/
	create(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__create(request, requestOptions));
	}
	async __create(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/unstable/dashboard-widgets"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new unstable_exports.BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new unstable_exports.UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new unstable_exports.AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new unstable_exports.MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new unstable_exports.TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new unstable_exports.InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/unstable/dashboard-widgets.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get a dashboard widget by id.
	*
	* The response may use `view: traces` for legacy widgets.
	*
	* @param {string} widgetId
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {DashboardWidgets.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.unstable.BadRequestError}
	* @throws {@link LangfuseAPI.unstable.UnauthorizedError}
	* @throws {@link LangfuseAPI.unstable.AccessDeniedError}
	* @throws {@link LangfuseAPI.unstable.NotFoundError}
	* @throws {@link LangfuseAPI.unstable.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.unstable.TooManyRequestsError}
	* @throws {@link LangfuseAPI.unstable.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.dashboardWidgets.get("widgetId")
	*/
	get(widgetId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__get(widgetId, requestOptions));
	}
	async __get(widgetId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/unstable/dashboard-widgets/${encodeURIComponent(widgetId)}`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new unstable_exports.BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new unstable_exports.UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new unstable_exports.AccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new unstable_exports.NotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new unstable_exports.MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new unstable_exports.TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new unstable_exports.InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/unstable/dashboard-widgets/{widgetId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Update a dashboard widget.
	*
	* All fields are optional; at least one field is required.
	* Changing `chartType` without sending `chartConfig` resets the config
	* to the new chart type's defaults. When `chartConfig.type` is given
	* it must match the widget's (possibly updated) `chartType`.
	*
	* `view` cannot be changed to the legacy `traces` value. Existing
	* `traces` widgets may be updated on other fields.
	*
	* @param {string} widgetId
	* @param {LangfuseAPI.unstable.UpdateDashboardWidgetRequest} request
	* @param {DashboardWidgets.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.unstable.BadRequestError}
	* @throws {@link LangfuseAPI.unstable.UnauthorizedError}
	* @throws {@link LangfuseAPI.unstable.AccessDeniedError}
	* @throws {@link LangfuseAPI.unstable.NotFoundError}
	* @throws {@link LangfuseAPI.unstable.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.unstable.TooManyRequestsError}
	* @throws {@link LangfuseAPI.unstable.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.dashboardWidgets.update("widgetId", {
	*         name: undefined,
	*         description: undefined,
	*         view: undefined,
	*         dimensions: undefined,
	*         metrics: undefined,
	*         filters: undefined,
	*         chartType: undefined,
	*         chartConfig: undefined
	*     })
	*/
	update(widgetId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__update(widgetId, request, requestOptions));
	}
	async __update(widgetId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/unstable/dashboard-widgets/${encodeURIComponent(widgetId)}`),
			method: "PATCH",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new unstable_exports.BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new unstable_exports.UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new unstable_exports.AccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new unstable_exports.NotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new unstable_exports.MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new unstable_exports.TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new unstable_exports.InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PATCH /api/public/unstable/dashboard-widgets/{widgetId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete a dashboard widget.
	*
	* The API returns `409` while the widget is still placed on a dashboard.
	* Remove those placements first.
	*
	* @param {string} widgetId
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {DashboardWidgets.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.unstable.BadRequestError}
	* @throws {@link LangfuseAPI.unstable.UnauthorizedError}
	* @throws {@link LangfuseAPI.unstable.AccessDeniedError}
	* @throws {@link LangfuseAPI.unstable.NotFoundError}
	* @throws {@link LangfuseAPI.unstable.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.unstable.ConflictError}
	* @throws {@link LangfuseAPI.unstable.TooManyRequestsError}
	* @throws {@link LangfuseAPI.unstable.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.dashboardWidgets.delete("widgetId")
	*/
	delete(widgetId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__delete(widgetId, requestOptions));
	}
	async __delete(widgetId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/unstable/dashboard-widgets/${encodeURIComponent(widgetId)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new unstable_exports.BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new unstable_exports.UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new unstable_exports.AccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new unstable_exports.NotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new unstable_exports.MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 409: throw new unstable_exports.ConflictError(_response.error.body, _response.rawResponse);
			case 429: throw new unstable_exports.TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new unstable_exports.InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/unstable/dashboard-widgets/{widgetId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Dashboards = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* List dashboards in the project, ordered by most recently updated
	* first.
	*
	* @param {LangfuseAPI.unstable.ListDashboardsRequest} request
	* @param {Dashboards.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.unstable.BadRequestError}
	* @throws {@link LangfuseAPI.unstable.UnauthorizedError}
	* @throws {@link LangfuseAPI.unstable.AccessDeniedError}
	* @throws {@link LangfuseAPI.unstable.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.unstable.TooManyRequestsError}
	* @throws {@link LangfuseAPI.unstable.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.dashboards.list()
	*/
	list(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__list(request, requestOptions));
	}
	async __list(request = {}, requestOptions) {
		const { page, limit } = request;
		const _queryParams = {};
		if (page != null) _queryParams["page"] = page.toString();
		if (limit != null) _queryParams["limit"] = limit.toString();
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/unstable/dashboards"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new unstable_exports.BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new unstable_exports.UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new unstable_exports.AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new unstable_exports.MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new unstable_exports.TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new unstable_exports.InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/unstable/dashboards.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create a dashboard.
	*
	* @param {LangfuseAPI.unstable.CreateDashboardRequest} request
	* @param {Dashboards.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.unstable.BadRequestError}
	* @throws {@link LangfuseAPI.unstable.UnauthorizedError}
	* @throws {@link LangfuseAPI.unstable.AccessDeniedError}
	* @throws {@link LangfuseAPI.unstable.NotFoundError}
	* @throws {@link LangfuseAPI.unstable.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.unstable.TooManyRequestsError}
	* @throws {@link LangfuseAPI.unstable.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.dashboards.create({
	*         name: "name",
	*         description: undefined,
	*         definition: undefined,
	*         filters: undefined
	*     })
	*/
	create(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__create(request, requestOptions));
	}
	async __create(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/unstable/dashboards"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new unstable_exports.BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new unstable_exports.UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new unstable_exports.AccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new unstable_exports.NotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new unstable_exports.MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new unstable_exports.TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new unstable_exports.InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/unstable/dashboards.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Get a dashboard by id.
	*
	* @param {string} dashboardId
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Dashboards.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.unstable.BadRequestError}
	* @throws {@link LangfuseAPI.unstable.UnauthorizedError}
	* @throws {@link LangfuseAPI.unstable.AccessDeniedError}
	* @throws {@link LangfuseAPI.unstable.NotFoundError}
	* @throws {@link LangfuseAPI.unstable.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.unstable.TooManyRequestsError}
	* @throws {@link LangfuseAPI.unstable.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.dashboards.get("dashboardId")
	*/
	get(dashboardId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__get(dashboardId, requestOptions));
	}
	async __get(dashboardId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/unstable/dashboards/${encodeURIComponent(dashboardId)}`),
			method: "GET",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new unstable_exports.BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new unstable_exports.UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new unstable_exports.AccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new unstable_exports.NotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new unstable_exports.MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new unstable_exports.TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new unstable_exports.InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/unstable/dashboards/{dashboardId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Update a dashboard's name, description, definition, or filters.
	*
	* @param {string} dashboardId
	* @param {LangfuseAPI.unstable.UpdateDashboardRequest} request
	* @param {Dashboards.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.unstable.BadRequestError}
	* @throws {@link LangfuseAPI.unstable.UnauthorizedError}
	* @throws {@link LangfuseAPI.unstable.AccessDeniedError}
	* @throws {@link LangfuseAPI.unstable.NotFoundError}
	* @throws {@link LangfuseAPI.unstable.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.unstable.TooManyRequestsError}
	* @throws {@link LangfuseAPI.unstable.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.dashboards.update("dashboardId", {
	*         name: undefined,
	*         description: undefined,
	*         definition: undefined,
	*         filters: undefined
	*     })
	*/
	update(dashboardId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__update(dashboardId, request, requestOptions));
	}
	async __update(dashboardId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/unstable/dashboards/${encodeURIComponent(dashboardId)}`),
			method: "PATCH",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new unstable_exports.BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new unstable_exports.UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new unstable_exports.AccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new unstable_exports.NotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new unstable_exports.MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new unstable_exports.TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new unstable_exports.InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PATCH /api/public/unstable/dashboards/{dashboardId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete a dashboard.
	*
	* @param {string} dashboardId
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Dashboards.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.unstable.BadRequestError}
	* @throws {@link LangfuseAPI.unstable.UnauthorizedError}
	* @throws {@link LangfuseAPI.unstable.AccessDeniedError}
	* @throws {@link LangfuseAPI.unstable.NotFoundError}
	* @throws {@link LangfuseAPI.unstable.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.unstable.TooManyRequestsError}
	* @throws {@link LangfuseAPI.unstable.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.dashboards.delete("dashboardId")
	*/
	delete(dashboardId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__delete(dashboardId, requestOptions));
	}
	async __delete(dashboardId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/unstable/dashboards/${encodeURIComponent(dashboardId)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new unstable_exports.BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new unstable_exports.UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new unstable_exports.AccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new unstable_exports.NotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new unstable_exports.MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new unstable_exports.TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new unstable_exports.InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/unstable/dashboards/{dashboardId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Add a placement to a dashboard grid (see `DashboardPlacement` for
	* grid semantics).
	*
	* `id` and the position fields are optional: when omitted, the
	* placement gets a server-generated id and is appended below all
	* existing tiles as a 6x6 tile. Returns the created placement.
	*
	* The referenced widget must exist in the same project or be a
	* Langfuse-managed widget. The API returns `409` if a placement with
	* the same `id` already exists on the dashboard.
	*
	* @param {string} dashboardId
	* @param {LangfuseAPI.unstable.CreateDashboardPlacementRequest} request
	* @param {Dashboards.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.unstable.BadRequestError}
	* @throws {@link LangfuseAPI.unstable.UnauthorizedError}
	* @throws {@link LangfuseAPI.unstable.AccessDeniedError}
	* @throws {@link LangfuseAPI.unstable.NotFoundError}
	* @throws {@link LangfuseAPI.unstable.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.unstable.ConflictError}
	* @throws {@link LangfuseAPI.unstable.TooManyRequestsError}
	* @throws {@link LangfuseAPI.unstable.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.dashboards.addPlacement("dashboardId", {
	*         type: "widget",
	*         id: undefined,
	*         widgetId: "widgetId",
	*         x: undefined,
	*         y: undefined,
	*         width: undefined,
	*         height: undefined
	*     })
	*/
	addPlacement(dashboardId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__addPlacement(dashboardId, request, requestOptions));
	}
	async __addPlacement(dashboardId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/unstable/dashboards/${encodeURIComponent(dashboardId)}/placements`),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new unstable_exports.BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new unstable_exports.UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new unstable_exports.AccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new unstable_exports.NotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new unstable_exports.MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 409: throw new unstable_exports.ConflictError(_response.error.body, _response.rawResponse);
			case 429: throw new unstable_exports.TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new unstable_exports.InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/unstable/dashboards/{dashboardId}/placements.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Move or resize a placement. All fields are optional; at least one is
	* required. Omitted fields keep their current value. The placement's
	* content (widget/preset reference) and id cannot change — delete and
	* re-add the placement to swap content. Returns the updated placement.
	*
	* @param {string} dashboardId
	* @param {string} placementId
	* @param {LangfuseAPI.unstable.UpdateDashboardPlacementRequest} request
	* @param {Dashboards.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.unstable.BadRequestError}
	* @throws {@link LangfuseAPI.unstable.UnauthorizedError}
	* @throws {@link LangfuseAPI.unstable.AccessDeniedError}
	* @throws {@link LangfuseAPI.unstable.NotFoundError}
	* @throws {@link LangfuseAPI.unstable.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.unstable.TooManyRequestsError}
	* @throws {@link LangfuseAPI.unstable.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.dashboards.updatePlacement("dashboardId", "placementId", {
	*         x: undefined,
	*         y: undefined,
	*         width: undefined,
	*         height: undefined
	*     })
	*/
	updatePlacement(dashboardId, placementId, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__updatePlacement(dashboardId, placementId, request, requestOptions));
	}
	async __updatePlacement(dashboardId, placementId, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/unstable/dashboards/${encodeURIComponent(dashboardId)}/placements/${encodeURIComponent(placementId)}`),
			method: "PATCH",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new unstable_exports.BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new unstable_exports.UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new unstable_exports.AccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new unstable_exports.NotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new unstable_exports.MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new unstable_exports.TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new unstable_exports.InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PATCH /api/public/unstable/dashboards/{dashboardId}/placements/{placementId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Remove a placement from a dashboard grid without deleting the referenced widget.
	*
	* @param {string} dashboardId
	* @param {string} placementId
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Dashboards.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.unstable.BadRequestError}
	* @throws {@link LangfuseAPI.unstable.UnauthorizedError}
	* @throws {@link LangfuseAPI.unstable.AccessDeniedError}
	* @throws {@link LangfuseAPI.unstable.NotFoundError}
	* @throws {@link LangfuseAPI.unstable.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.unstable.TooManyRequestsError}
	* @throws {@link LangfuseAPI.unstable.InternalServerError}
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.dashboards.deletePlacement("dashboardId", "placementId")
	*/
	deletePlacement(dashboardId, placementId, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__deletePlacement(dashboardId, placementId, requestOptions));
	}
	async __deletePlacement(dashboardId, placementId, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/unstable/dashboards/${encodeURIComponent(dashboardId)}/placements/${encodeURIComponent(placementId)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new unstable_exports.BadRequestError(_response.error.body, _response.rawResponse);
			case 401: throw new unstable_exports.UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new unstable_exports.AccessDeniedError(_response.error.body, _response.rawResponse);
			case 404: throw new unstable_exports.NotFoundError(_response.error.body, _response.rawResponse);
			case 405: throw new unstable_exports.MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 429: throw new unstable_exports.TooManyRequestsError(_response.error.body, _response.rawResponse);
			case 500: throw new unstable_exports.InternalServerError(_response.error.body, _response.rawResponse);
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/unstable/dashboards/{dashboardId}/placements/{placementId}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Skills = class {
	_options;
	constructor(_options) {
		this._options = _options;
	}
	/**
	* List skills with metadata and timestamps from their latest version, shared tags, and the version assigned to production when present.
	*
	* @param {LangfuseAPI.unstable.ListSkillsRequest} request
	* @param {Skills.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.skills.list()
	*/
	list(request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__list(request, requestOptions));
	}
	async __list(request = {}, requestOptions) {
		const { name, search, tag, page, limit, fromUpdatedAt, toUpdatedAt } = request;
		const _queryParams = {};
		if (name != null) _queryParams["name"] = name;
		if (search != null) _queryParams["search"] = search;
		if (tag != null) _queryParams["tag"] = tag;
		if (page != null) _queryParams["page"] = page.toString();
		if (limit != null) _queryParams["limit"] = limit.toString();
		if (fromUpdatedAt != null) _queryParams["fromUpdatedAt"] = fromUpdatedAt;
		if (toUpdatedAt != null) _queryParams["toUpdatedAt"] = toUpdatedAt;
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/unstable/skills"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/unstable/skills.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Create skill version
	*
	* @param {LangfuseAPI.unstable.CreateSkillVersionRequest} request
	* @param {Skills.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.skills.createVersion({
	*         files: [{
	*                 path: "path",
	*                 content: "content"
	*             }, {
	*                 path: "path",
	*                 content: "content"
	*             }],
	*         commitMessage: undefined
	*     })
	*/
	createVersion(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__createVersion(request, requestOptions));
	}
	async __createVersion(request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/unstable/skills"),
			method: "POST",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling POST /api/public/unstable/skills.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Resolve a skill's metadata and file manifest by version or label. Defaults to the production label. Use each file's sha256Hash with getFileContents, individually or in batches across manifests.
	*
	* @param {string} skillName
	* @param {LangfuseAPI.unstable.GetSkillRequest} request
	* @param {Skills.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.skills.get("skillName")
	*/
	get(skillName, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__get(skillName, request, requestOptions));
	}
	async __get(skillName, request = {}, requestOptions) {
		const { version, label } = request;
		const _queryParams = {};
		if (version != null) _queryParams["version"] = version.toString();
		if (label != null) _queryParams["label"] = label;
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/unstable/skills/${encodeURIComponent(skillName)}`),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/unstable/skills/{skillName}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Replace the shared tags across all versions of a skill. An empty tags list clears all tags. Returns the latest skill version with the updated tags.
	*
	* @param {string} skillName
	* @param {LangfuseAPI.unstable.UpdateSkillRequest} request
	* @param {Skills.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.skills.update("skillName", {
	*         tags: ["tags", "tags"]
	*     })
	*/
	update(skillName, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__update(skillName, request, requestOptions));
	}
	async __update(skillName, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/unstable/skills/${encodeURIComponent(skillName)}`),
			method: "PATCH",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PATCH /api/public/unstable/skills/{skillName}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Read a batch of text contents by canonical base64-encoded SHA-256 hashes.
	*
	* @param {LangfuseAPI.unstable.GetSkillFileContentsRequest} request
	* @param {Skills.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.skills.getFileContents({
	*         sha256Hashes: "sha256Hashes"
	*     })
	*/
	getFileContents(request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__getFileContents(request, requestOptions));
	}
	async __getFileContents(request, requestOptions) {
		const { sha256Hashes } = request;
		const _queryParams = {};
		_queryParams["sha256Hashes"] = sha256Hashes;
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), "/api/public/unstable/skills/files/content"),
			method: "GET",
			headers: _headers,
			queryParameters: {
				..._queryParams,
				...requestOptions?.queryParams
			},
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling GET /api/public/unstable/skills/files/content.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Replace the labels on a skill version and atomically move them from other versions.
	*
	* @param {string} skillName
	* @param {number} skillVersion
	* @param {LangfuseAPI.unstable.UpdateSkillLabelsRequest} request
	* @param {Skills.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.skills.setLabels("skillName", 1, {
	*         labels: ["labels", "labels"]
	*     })
	*/
	setLabels(skillName, skillVersion, request, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__setLabels(skillName, skillVersion, request, requestOptions));
	}
	async __setLabels(skillName, skillVersion, request, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/unstable/skills/${encodeURIComponent(skillName)}/versions/${encodeURIComponent(skillVersion)}`),
			method: "PATCH",
			headers: _headers,
			contentType: "application/json",
			queryParameters: requestOptions?.queryParams,
			requestType: "json",
			body: request,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling PATCH /api/public/unstable/skills/{skillName}/versions/{skillVersion}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	/**
	* Delete one immutable skill version. Unreferenced blobs are retained for asynchronous cleanup.
	*
	* @param {string} skillName
	* @param {number} skillVersion
	* @param {Record<string, never>} request - Takes no fields yet. Reserves the position for query parameters that later API versions may add, so `requestOptions` never moves.
	* @param {Skills.RequestOptions} requestOptions - Request-specific configuration.
	*
	* @throws {@link LangfuseAPI.Error}
	* @throws {@link LangfuseAPI.UnauthorizedError}
	* @throws {@link LangfuseAPI.AccessDeniedError}
	* @throws {@link LangfuseAPI.MethodNotAllowedError}
	* @throws {@link LangfuseAPI.NotFoundError}
	*
	* @example
	*     await client.unstable.skills.deleteVersion("skillName", 1)
	*/
	deleteVersion(skillName, skillVersion, request = {}, requestOptions) {
		return HttpResponsePromise.fromPromise(this.__deleteVersion(skillName, skillVersion, requestOptions));
	}
	async __deleteVersion(skillName, skillVersion, requestOptions) {
		let _headers = mergeHeaders(this._options?.headers, mergeOnlyDefinedHeaders({
			Authorization: await this._getAuthorizationHeader(),
			"X-Langfuse-Sdk-Name": requestOptions?.xLangfuseSdkName ?? this._options?.xLangfuseSdkName,
			"X-Langfuse-Sdk-Version": requestOptions?.xLangfuseSdkVersion ?? this._options?.xLangfuseSdkVersion,
			"X-Langfuse-Public-Key": requestOptions?.xLangfusePublicKey ?? this._options?.xLangfusePublicKey
		}), requestOptions?.headers);
		const _response = await fetcher({
			url: url_exports.join(await Supplier.get(this._options.baseUrl) ?? await Supplier.get(this._options.environment), `/api/public/unstable/skills/${encodeURIComponent(skillName)}/versions/${encodeURIComponent(skillVersion)}`),
			method: "DELETE",
			headers: _headers,
			queryParameters: requestOptions?.queryParams,
			timeoutMs: requestOptions?.timeoutInSeconds != null ? requestOptions.timeoutInSeconds * 1e3 : 6e4,
			maxRetries: requestOptions?.maxRetries,
			abortSignal: requestOptions?.abortSignal
		});
		if (_response.ok) return {
			data: _response.body,
			rawResponse: _response.rawResponse
		};
		if (_response.error.reason === "status-code") switch (_response.error.statusCode) {
			case 400: throw new Error2(_response.error.body, _response.rawResponse);
			case 401: throw new UnauthorizedError(_response.error.body, _response.rawResponse);
			case 403: throw new AccessDeniedError(_response.error.body, _response.rawResponse);
			case 405: throw new MethodNotAllowedError(_response.error.body, _response.rawResponse);
			case 404: throw new NotFoundError(_response.error.body, _response.rawResponse);
			default: throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.body,
				rawResponse: _response.rawResponse
			});
		}
		switch (_response.error.reason) {
			case "non-json": throw new LangfuseAPIError({
				statusCode: _response.error.statusCode,
				body: _response.error.rawBody,
				rawResponse: _response.rawResponse
			});
			case "timeout": throw new LangfuseAPITimeoutError("Timeout exceeded when calling DELETE /api/public/unstable/skills/{skillName}/versions/{skillVersion}.");
			case "unknown": throw new LangfuseAPIError({
				message: _response.error.errorMessage,
				rawResponse: _response.rawResponse
			});
		}
	}
	async _getAuthorizationHeader() {
		const username = await Supplier.get(this._options.username);
		const password = await Supplier.get(this._options.password);
		if (username != null && password != null) return BasicAuth.toAuthorizationHeader({
			username,
			password
		});
	}
};
var Unstable = class {
	_options;
	_dashboardWidgets;
	_dashboards;
	_skills;
	constructor(_options) {
		this._options = _options;
	}
	get dashboardWidgets() {
		return this._dashboardWidgets ??= new DashboardWidgets(this._options);
	}
	get dashboards() {
		return this._dashboards ??= new Dashboards(this._options);
	}
	get skills() {
		return this._skills ??= new Skills(this._options);
	}
};
var LangfuseAPIClient = class {
	_options;
	_annotationQueues;
	_blobStorageIntegrations;
	_comments;
	_datasetItems;
	_datasets;
	_evaluationRules;
	_evaluators;
	_experiments;
	_feedback;
	_health;
	_llmConnections;
	_media;
	_metrics;
	_models;
	_observations;
	_opentelemetry;
	_organizations;
	_projects;
	_promptVersion;
	_prompts;
	_scim;
	_scoreConfigs;
	_scores;
	_trace;
	_unstable;
	constructor(_options) {
		this._options = {
			..._options,
			headers: mergeHeaders({
				"X-Langfuse-Sdk-Name": _options?.xLangfuseSdkName,
				"X-Langfuse-Sdk-Version": _options?.xLangfuseSdkVersion,
				"X-Langfuse-Public-Key": _options?.xLangfusePublicKey
			}, _options?.headers)
		};
	}
	get annotationQueues() {
		return this._annotationQueues ??= new AnnotationQueues(this._options);
	}
	get blobStorageIntegrations() {
		return this._blobStorageIntegrations ??= new BlobStorageIntegrations(this._options);
	}
	get comments() {
		return this._comments ??= new Comments(this._options);
	}
	get datasetItems() {
		return this._datasetItems ??= new DatasetItems(this._options);
	}
	get datasets() {
		return this._datasets ??= new Datasets(this._options);
	}
	get evaluationRules() {
		return this._evaluationRules ??= new EvaluationRules(this._options);
	}
	get evaluators() {
		return this._evaluators ??= new Evaluators(this._options);
	}
	get experiments() {
		return this._experiments ??= new Experiments(this._options);
	}
	get feedback() {
		return this._feedback ??= new Feedback(this._options);
	}
	get health() {
		return this._health ??= new Health(this._options);
	}
	get llmConnections() {
		return this._llmConnections ??= new LlmConnections(this._options);
	}
	get media() {
		return this._media ??= new Media(this._options);
	}
	get metrics() {
		return this._metrics ??= new Metrics(this._options);
	}
	get models() {
		return this._models ??= new Models(this._options);
	}
	get observations() {
		return this._observations ??= new Observations(this._options);
	}
	get opentelemetry() {
		return this._opentelemetry ??= new Opentelemetry(this._options);
	}
	get organizations() {
		return this._organizations ??= new Organizations(this._options);
	}
	get projects() {
		return this._projects ??= new Projects(this._options);
	}
	get promptVersion() {
		return this._promptVersion ??= new PromptVersion(this._options);
	}
	get prompts() {
		return this._prompts ??= new Prompts(this._options);
	}
	get scim() {
		return this._scim ??= new Scim(this._options);
	}
	get scoreConfigs() {
		return this._scoreConfigs ??= new ScoreConfigs(this._options);
	}
	get scores() {
		return this._scores ??= new Scores(this._options);
	}
	get trace() {
		return this._trace ??= new Trace(this._options);
	}
	get unstable() {
		return this._unstable ??= new Unstable(this._options);
	}
};
var LangfuseMedia = class {
	_contentBytes;
	_contentType;
	_source;
	/**
	* Creates a new LangfuseMedia instance.
	*
	* @param params - Media parameters specifying the source and content
	*
	* @example
	* ```typescript
	* // Create from base64 data URI
	* const media = new LangfuseMedia({
	*   source: "base64_data_uri",
	*   base64DataUri: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQ..."
	* });
	* ```
	*/
	constructor(params) {
		const { source } = params;
		this._source = source;
		if (source === "base64_data_uri") {
			const [contentBytesParsed, contentTypeParsed] = this.parseBase64DataUri(params.base64DataUri);
			this._contentBytes = contentBytesParsed;
			this._contentType = contentTypeParsed;
		} else {
			this._contentBytes = params.contentBytes;
			this._contentType = params.contentType;
		}
	}
	/**
	* Parses a base64 data URI to extract content bytes and type.
	*
	* @param data - The base64 data URI string
	* @returns Tuple of [contentBytes, contentType] or [undefined, undefined] on error
	* @private
	*/
	parseBase64DataUri(data) {
		try {
			if (!data || typeof data !== "string") throw new Error("Data URI is not a string");
			if (!data.startsWith("data:")) throw new Error("Data URI does not start with 'data:'");
			const [header, actualData] = data.slice(5).split(",", 2);
			if (!header || !actualData) throw new Error("Invalid URI");
			const headerParts = header.split(";");
			if (!headerParts.includes("base64")) throw new Error("Data is not base64 encoded");
			const contentType = headerParts[0];
			if (!contentType) throw new Error("Content type is empty");
			return [base64ToBytes(actualData), contentType];
		} catch (error) {
			getGlobalLogger().error("Error parsing base64 data URI", error);
			return [void 0, void 0];
		}
	}
	/**
	* Gets a unique identifier for this media based on its content hash.
	*
	* The ID is derived from the first 22 characters of the URL-safe base64-encoded
	* SHA-256 hash of the content.
	*
	* @returns The unique media ID, or null if hash generation failed
	*
	* @example
	* ```typescript
	* const media = new LangfuseMedia({...});
	* console.log(media.id); // "A1B2C3D4E5F6G7H8I9J0K1"
	* ```
	*/
	async getId() {
		const contentSha256Hash = await this.getSha256Hash();
		if (!contentSha256Hash) return null;
		return contentSha256Hash.replaceAll("+", "-").replaceAll("/", "_").slice(0, 22);
	}
	/**
	* Gets the length of the media content in bytes.
	*
	* @returns The content length in bytes, or undefined if no content is available
	*/
	get contentLength() {
		return this._contentBytes?.length;
	}
	/**
	* Gets the SHA-256 hash of the media content.
	*
	* The hash is used for content integrity verification and generating unique media IDs.
	* Returns undefined if crypto is not available or hash generation fails.
	*
	* @returns The base64-encoded SHA-256 hash, or undefined if unavailable
	*/
	async getSha256Hash() {
		if (!this._contentBytes) return;
		try {
			const hash = await crypto.subtle.digest("SHA-256", this._contentBytes);
			return bytesToBase64(new Uint8Array(hash));
		} catch (error) {
			getGlobalLogger().warn("[Langfuse] Failed to generate SHA-256 hash for media content:", error);
			return;
		}
	}
	/**
	* Gets the media reference tag for embedding in trace data.
	*
	* The tag format is: `@@@langfuseMedia:type=<contentType>|id=<mediaId>|source=<source>@@@`
	* This tag can be embedded in trace attributes and will be replaced with actual
	* media content when the trace is viewed in Langfuse.
	*
	* @returns The media reference tag, or null if required data is missing
	*
	* @example
	* ```typescript
	* const media = new LangfuseMedia({...});
	* console.log(media.tag);
	* // "@@@langfuseMedia:type=image/png|id=A1B2C3D4E5F6G7H8I9J0K1|source=base64_data_uri@@@"
	* ```
	*/
	async getTag() {
		const id = await this.getId();
		if (!this._contentType || !this._source || !id) return null;
		return `@@@langfuseMedia:type=${this._contentType}|id=${id}|source=${this._source}@@@`;
	}
	/**
	* Gets the media content as a base64 data URI.
	*
	* @returns The complete data URI string, or null if no content is available
	*
	* @example
	* ```typescript
	* const media = new LangfuseMedia({...});
	* console.log(media.base64DataUri);
	* // "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAB..."
	* ```
	*/
	get base64DataUri() {
		if (!this._contentBytes) return null;
		return `data:${this._contentType};base64,${bytesToBase64(this._contentBytes)}`;
	}
	/**
	* Serializes the media to JSON (returns the base64 data URI).
	*
	* @returns The base64 data URI, or null if no content is available
	*/
	toJSON() {
		return this.base64DataUri;
	}
};
var LangfuseMediaReference = class {
	mediaId;
	contentType;
	url;
	urlExpiry;
	contentLength;
	referenceString;
	constructor(params) {
		Object.assign(this, params);
	}
	/**
	* Serializes to the original `@@@langfuseMedia:…@@@` reference string.
	*
	* This makes resolved references round-trip losslessly through anything that
	* serializes with `JSON.stringify` — the dataset item API, experiment/trace
	* span attributes — so a re-used item links back to its media instead of
	* persisting a JSON object with a soon-to-expire signed URL.
	*/
	toJSON() {
		return this.referenceString;
	}
	/**
	* Returns whether the signed download URL is expired or near expiry.
	*
	* @param thresholdSeconds - Treat the URL as expired this many seconds before
	*   its actual expiry to account for clock skew and download time (default: 60).
	* @returns true if the URL is expired or within the threshold of expiry. If
	*   the expiry is unknown or unparseable, returns false.
	*/
	isUrlExpired(thresholdSeconds = 60) {
		if (!this.urlExpiry) return false;
		const expiryMs = Date.parse(this.urlExpiry);
		if (Number.isNaN(expiryMs)) return false;
		return expiryMs - Date.now() <= thresholdSeconds * 1e3;
	}
	/**
	* Fetches the media content from the signed URL over the network.
	*
	* Useful for local evaluators / image libraries, manual base64 conversion, or
	* the Vercel AI SDK (`{ type: "image", image: await media.fetchBytes() }`).
	*
	* @returns The media content as raw bytes
	* @throws {Error} If the download fails
	*/
	async fetchBytes() {
		const response = await fetch(this.url, {
			method: "GET",
			headers: {}
		});
		if (!response.ok) throw new Error(`Failed to fetch media ${this.mediaId}: HTTP ${response.status}`);
		return new Uint8Array(await response.arrayBuffer());
	}
	/**
	* Fetches the media over the network and returns raw base64 (no data URI prefix).
	*
	* Useful for Anthropic (`{ source: { type: "base64", media_type: media.contentType, data: await media.fetchBase64() } }`)
	* or LangChain (`{ type: "image", base64: await media.fetchBase64(), mime_type: media.contentType }`).
	*
	* @returns The media content as a base64 string
	* @throws {Error} If the download fails
	*/
	async fetchBase64() {
		return bytesToBase64(await this.fetchBytes());
	}
	/**
	* Fetches the media over the network and returns a `data:<contentType>;base64,...` URI.
	*
	* Useful for OpenAI (`{ type: "input_image", image_url: await media.fetchDataUri() }`).
	*
	* @returns The media content as a base64 data URI
	* @throws {Error} If the download fails
	*/
	async fetchDataUri() {
		return `data:${this.contentType};base64,${await this.fetchBase64()}`;
	}
};
async function uploadMedia(params) {
	const { apiClient, media, traceId, observationId, datasetId, datasetItemId, field, maxRetries = 3, baseDelay = 1e3 } = params;
	const logger = params.logger ?? getGlobalLogger();
	const contentSha256Hash = await media.getSha256Hash();
	if (!media.contentLength || !media._contentType || !contentSha256Hash || !media._contentBytes) throw new Error("Cannot upload media: media content is incomplete.");
	const { uploadUrl, mediaId } = await apiClient.media.getUploadUrl({
		contentLength: media.contentLength,
		traceId,
		observationId,
		datasetId,
		datasetItemId,
		field,
		contentType: media._contentType,
		sha256Hash: contentSha256Hash
	});
	if (!uploadUrl) {
		logger.debug(`Media status: Media with ID ${mediaId} already uploaded. Skipping duplicate upload.`);
		return;
	}
	const clientSideMediaId = await media.getId();
	if (clientSideMediaId !== mediaId) throw new Error(`Media integrity error: Media ID mismatch between SDK (${clientSideMediaId}) and Server (${mediaId}). Upload cancelled.`);
	logger.debug(`Uploading media ${mediaId}...`);
	const startTime = Date.now();
	const uploadResponse = await uploadWithBackoff({
		uploadUrl,
		contentBytes: media._contentBytes,
		contentType: media._contentType,
		contentSha256Hash,
		maxRetries,
		baseDelay
	});
	if (!uploadResponse) throw new Error("Media upload process failed");
	const uploadSucceeded = uploadResponse.status === 200 || uploadResponse.status === 201;
	await apiClient.media.patch(mediaId, {
		uploadedAt: (/* @__PURE__ */ new Date()).toISOString(),
		uploadHttpStatus: uploadResponse.status,
		uploadHttpError: await uploadResponse.text(),
		uploadTimeMs: Date.now() - startTime
	});
	logger.debug(`Media upload status reported for ${mediaId}`);
	if (!uploadSucceeded) throw new Error(`Media upload failed with HTTP ${uploadResponse.status} after ${maxRetries} retries.`);
}
async function uploadWithBackoff(params) {
	const { uploadUrl, contentType, contentSha256Hash, contentBytes, maxRetries, baseDelay } = params;
	for (let attempt = 0; attempt <= maxRetries; attempt++) try {
		let parsedHostname;
		try {
			parsedHostname = new URL(uploadUrl).hostname;
		} catch {
			parsedHostname = "";
		}
		const headers = parsedHostname === "storage.googleapis.com" || parsedHostname.endsWith(".storage.googleapis.com") ? { "Content-Type": contentType } : {
			"Content-Type": contentType,
			"x-amz-checksum-sha256": contentSha256Hash,
			"x-ms-blob-type": "BlockBlob"
		};
		const uploadResponse = await fetch(uploadUrl, {
			method: "PUT",
			body: contentBytes,
			headers
		});
		if (attempt < maxRetries && uploadResponse.status !== 200 && uploadResponse.status !== 201) throw new Error(`Upload failed with status ${uploadResponse.status}`);
		return uploadResponse;
	} catch (e) {
		if (attempt === maxRetries) throw e;
		const delay = baseDelay * Math.pow(2, attempt);
		const jitter = Math.random() * 1e3;
		await new Promise((resolve) => setTimeout(resolve, delay + jitter));
	}
}
var experimentKeys = [
	"experimentId",
	"experimentName",
	"experimentMetadata",
	"experimentDatasetId",
	"experimentItemId",
	"experimentItemMetadata",
	"experimentItemRootObservationId"
];
var LangfuseOtelContextKeys = {
	userId: (0, import_src.createContextKey)("langfuse_user_id"),
	sessionId: (0, import_src.createContextKey)("langfuse_session_id"),
	metadata: (0, import_src.createContextKey)("langfuse_metadata"),
	version: (0, import_src.createContextKey)("langfuse_version"),
	tags: (0, import_src.createContextKey)("langfuse_tags"),
	traceName: (0, import_src.createContextKey)("langfuse_trace_name"),
	environment: (0, import_src.createContextKey)("langfuse_environment"),
	promptName: (0, import_src.createContextKey)("langfuse_prompt_name"),
	promptVersion: (0, import_src.createContextKey)("langfuse_prompt_version"),
	experimentId: (0, import_src.createContextKey)("langfuse_experiment_id"),
	experimentName: (0, import_src.createContextKey)("langfuse_experiment_name"),
	experimentMetadata: (0, import_src.createContextKey)("langfuse_experiment_metadata"),
	experimentDatasetId: (0, import_src.createContextKey)("langfuse_experiment_dataset_id"),
	experimentItemId: (0, import_src.createContextKey)("langfuse_experiment_item_id"),
	experimentItemMetadata: (0, import_src.createContextKey)("langfuse_experiment_item_metadata"),
	experimentItemRootObservationId: (0, import_src.createContextKey)("langfuse_experiment_item_root_observation_id")
};
var LANGFUSE_BAGGAGE_PREFIX = "langfuse_";
var LANGFUSE_BAGGAGE_TAGS_SEPARATOR = ",";
var LANGFUSE_TRACE_ID_BAGGAGE_KEY = "langfuse_trace_id";
function getLangfuseTraceIdFromBaggage(context) {
	const entry = import_src.propagation.getBaggage(context)?.getEntry(LANGFUSE_TRACE_ID_BAGGAGE_KEY);
	if (!entry?.value) return void 0;
	return entry.value.toLowerCase();
}
function setLangfuseTraceIdInBaggage(context, traceId) {
	const normalized = traceId.toLowerCase();
	if (getLangfuseTraceIdFromBaggage(context) === normalized) return context;
	const updated = (import_src.propagation.getBaggage(context) ?? import_src.propagation.createBaggage()).setEntry(LANGFUSE_TRACE_ID_BAGGAGE_KEY, { value: normalized });
	return import_src.propagation.setBaggage(context, updated);
}
function propagateAttributes(params, fn) {
	let context = import_src.context.active();
	const span = import_src.trace.getActiveSpan();
	const asBaggage = params.asBaggage ?? false;
	const { userId, sessionId, metadata, version, tags, traceName, environment, prompt, _internalExperiment } = params;
	if (userId) {
		if (isValidPropagatedString({
			value: userId,
			attributeName: "userId"
		})) context = setPropagatedAttribute({
			key: "userId",
			value: userId,
			context,
			span,
			asBaggage
		});
	}
	if (sessionId) {
		if (isValidPropagatedString({
			value: sessionId,
			attributeName: "sessionId"
		})) context = setPropagatedAttribute({
			key: "sessionId",
			value: sessionId,
			context,
			span,
			asBaggage
		});
	}
	if (version) {
		if (isValidPropagatedString({
			value: version,
			attributeName: "version"
		})) context = setPropagatedAttribute({
			key: "version",
			value: version,
			context,
			span,
			asBaggage
		});
	}
	if (traceName) {
		if (isValidPropagatedString({
			value: traceName,
			attributeName: "traceName"
		})) context = setPropagatedAttribute({
			key: "traceName",
			value: traceName,
			context,
			span,
			asBaggage
		});
	}
	if (environment !== void 0 && isValidEnvironment(environment)) context = setPropagatedAttribute({
		key: "environment",
		value: environment,
		context,
		span,
		asBaggage
	});
	if (tags && tags.length > 0) {
		const validTags = tags.filter((tag) => isValidPropagatedString({
			value: tag,
			attributeName: "tag"
		}));
		if (validTags.length > 0) context = setPropagatedAttribute({
			key: "tags",
			value: validTags,
			context,
			span,
			asBaggage
		});
	}
	if (metadata) {
		const validatedMetadata = {};
		for (const [key, value] of Object.entries(metadata)) {
			const serialized = serializePropagatedMetadataValue(key, value);
			if (serialized !== void 0 && isValidPropagatedString({
				value: serialized,
				attributeName: `metadata.${key}`
			})) validatedMetadata[key] = serialized;
		}
		if (Object.keys(validatedMetadata).length > 0) context = setPropagatedAttribute({
			key: "metadata",
			value: validatedMetadata,
			context,
			span,
			asBaggage
		});
	}
	if (prompt) {
		const propagatedPrompt = extractPropagatedPrompt(prompt);
		if (propagatedPrompt) {
			context = setPropagatedAttribute({
				key: "promptName",
				value: propagatedPrompt.name,
				context,
				span,
				asBaggage
			});
			context = setPropagatedAttribute({
				key: "promptVersion",
				value: propagatedPrompt.version,
				context,
				span,
				asBaggage
			});
		}
	}
	if (_internalExperiment) {
		for (const [key, value] of Object.entries(_internalExperiment)) if (value !== void 0) context = setPropagatedAttribute({
			key,
			value,
			context,
			span,
			asBaggage
		});
	}
	return import_src.context.with(context, fn);
}
function extractPropagatedPrompt(prompt) {
	const logger = getGlobalLogger();
	const { name, version: rawVersion, isFallback } = prompt;
	if (isFallback) {
		logger.debug("Propagated prompt is a fallback prompt. Skipping prompt linking.");
		return null;
	}
	if (typeof name !== "string" || name.length === 0) {
		logger.warn("Propagated 'prompt' has no valid 'name' (non-empty string required). Dropping prompt link.");
		return null;
	}
	const version = typeof rawVersion === "string" && /^\d+$/.test(rawVersion) ? Number(rawVersion) : rawVersion;
	if (typeof version !== "number" || !Number.isInteger(version)) {
		logger.warn("Propagated 'prompt' has no valid 'version' (integer required). Dropping prompt link.");
		return null;
	}
	return {
		name,
		version
	};
}
function getPropagatedAttributesFromContext(context) {
	const propagatedAttributes = {};
	const baggage = import_src.propagation.getBaggage(context);
	if (baggage) baggage.getAllEntries().forEach(([baggageKey, baggageEntry]) => {
		if (baggageKey === "langfuse_trace_id") return;
		if (baggageKey.startsWith(LANGFUSE_BAGGAGE_PREFIX)) {
			const spanKey = getSpanKeyFromBaggageKey(baggageKey);
			if (spanKey) {
				if (spanKey === "langfuse.environment") {
					if (isValidEnvironment(baggageEntry.value)) propagatedAttributes[spanKey] = baggageEntry.value;
					return;
				}
				if (spanKey === "langfuse.observation.prompt.version" && /^\d+$/.test(baggageEntry.value)) {
					propagatedAttributes[spanKey] = Number(baggageEntry.value);
					return;
				}
				const isMergedTags = baggageKey == getBaggageKeyForPropagatedKey("tags");
				propagatedAttributes[spanKey] = isMergedTags ? baggageEntry.value.split(LANGFUSE_BAGGAGE_TAGS_SEPARATOR) : baggageEntry.value;
			}
		}
	});
	const userId = context.getValue(LangfuseOtelContextKeys["userId"]);
	if (userId && typeof userId === "string") {
		const spanKey = getSpanKeyForPropagatedKey("userId");
		propagatedAttributes[spanKey] = userId;
	}
	const sessionId = context.getValue(LangfuseOtelContextKeys["sessionId"]);
	if (sessionId && typeof sessionId === "string") {
		const spanKey = getSpanKeyForPropagatedKey("sessionId");
		propagatedAttributes[spanKey] = sessionId;
	}
	const version = context.getValue(LangfuseOtelContextKeys["version"]);
	if (version && typeof version === "string") {
		const spanKey = getSpanKeyForPropagatedKey("version");
		propagatedAttributes[spanKey] = version;
	}
	const traceName = context.getValue(LangfuseOtelContextKeys["traceName"]);
	if (traceName && typeof traceName === "string") {
		const spanKey = getSpanKeyForPropagatedKey("traceName");
		propagatedAttributes[spanKey] = traceName;
	}
	const environment = context.getValue(LangfuseOtelContextKeys["environment"]);
	if (isValidEnvironment(environment)) propagatedAttributes["langfuse.environment"] = environment;
	const tags = context.getValue(LangfuseOtelContextKeys["tags"]);
	if (tags && Array.isArray(tags)) {
		const spanKey = getSpanKeyForPropagatedKey("tags");
		propagatedAttributes[spanKey] = tags;
	}
	const promptName = context.getValue(LangfuseOtelContextKeys["promptName"]);
	if (promptName && typeof promptName === "string") {
		const spanKey = getSpanKeyForPropagatedKey("promptName");
		propagatedAttributes[spanKey] = promptName;
	}
	const promptVersion = context.getValue(LangfuseOtelContextKeys["promptVersion"]);
	if (typeof promptVersion === "number") {
		const spanKey = getSpanKeyForPropagatedKey("promptVersion");
		propagatedAttributes[spanKey] = promptVersion;
	}
	const metadata = context.getValue(LangfuseOtelContextKeys["metadata"]);
	if (metadata && typeof metadata === "object" && metadata !== null) for (const [k, v] of Object.entries(metadata)) {
		const spanKey = `langfuse.trace.metadata.${k}`;
		propagatedAttributes[spanKey] = String(v);
	}
	for (const key of experimentKeys) {
		const contextKey = LangfuseOtelContextKeys[key];
		const value = context.getValue(contextKey);
		if (value && typeof value === "string") {
			const spanKey = getSpanKeyForPropagatedKey(key);
			propagatedAttributes[spanKey] = value;
		}
	}
	if (propagatedAttributes[getSpanKeyForPropagatedKey("experimentItemRootObservationId")]) propagatedAttributes["langfuse.environment"] = LANGFUSE_SDK_EXPERIMENT_ENVIRONMENT;
	return propagatedAttributes;
}
function setPropagatedAttribute(params) {
	const { key, value, span, asBaggage } = params;
	let context = params.context;
	let mergedMetadata = key === "metadata" ? getContextMergedMetadata(context, value) : {};
	let mergedTags = key === "tags" ? getContextMergedTags(context, value) : [];
	const contextKey = getContextKeyForPropagatedKey(key);
	if (key === "metadata") context = context.setValue(contextKey, mergedMetadata);
	else if (key === "tags") context = context.setValue(contextKey, mergedTags);
	else context = context.setValue(contextKey, value);
	if (span && span.isRecording()) {
		if (key === "metadata") for (const [k, v] of Object.entries(mergedMetadata)) span.setAttribute(`langfuse.trace.metadata.${k}`, v);
		else if (key === "tags") {
			const spanKey = getSpanKeyForPropagatedKey(key);
			span.setAttribute(spanKey, mergedTags);
		} else {
			const spanKey = getSpanKeyForPropagatedKey(key);
			span.setAttribute(spanKey, value);
		}
	}
	if (asBaggage) {
		const baggageKey = getBaggageKeyForPropagatedKey(key);
		let baggage = import_src.propagation.getBaggage(context) || import_src.propagation.createBaggage();
		if (key === "metadata") for (const [k, v] of Object.entries(mergedMetadata)) baggage = baggage.setEntry(`${baggageKey}_${k}`, { value: v });
		else if (key === "tags") baggage = baggage.setEntry(baggageKey, { value: mergedTags.join(LANGFUSE_BAGGAGE_TAGS_SEPARATOR) });
		else baggage = baggage.setEntry(baggageKey, { value: String(value) });
		context = import_src.propagation.setBaggage(context, baggage);
	}
	return context;
}
function getContextMergedTags(context, newTags) {
	const existingTags = context.getValue(LangfuseOtelContextKeys["tags"]);
	if (existingTags && Array.isArray(existingTags)) return [.../* @__PURE__ */ new Set([...existingTags, ...newTags])];
	else return newTags;
}
function getContextMergedMetadata(context, newMetadata) {
	const existingMetadata = context.getValue(LangfuseOtelContextKeys["metadata"]);
	if (existingMetadata && typeof existingMetadata === "object" && existingMetadata !== null && !Array.isArray(existingMetadata)) return {
		...existingMetadata,
		...newMetadata
	};
	else return newMetadata;
}
function serializePropagatedMetadataValue(key, value) {
	const serialized = serializeMetadataValue(value);
	if (serialized === void 0) getGlobalLogger().warn(`Propagated attribute 'metadata.${key}' is ${value == null ? String(value) : "not JSON-serializable"}. Dropping value.`);
	return serialized;
}
function isValidPropagatedString(params) {
	const logger = getGlobalLogger();
	const { value, attributeName } = params;
	if (typeof value !== "string") {
		logger.warn(`Propagated attribute '${attributeName}' must be a string. Dropping value.`);
		return false;
	}
	if (value.length > 200) {
		logger.warn(`Propagated attribute '${attributeName}' value is over 200 characters (${value.length} chars). Dropping value.`);
		return false;
	}
	return true;
}
var ENVIRONMENT_VALUE_PATTERN = /^(?!langfuse)[a-z0-9_-]+$/;
function isValidEnvironment(value) {
	const logger = getGlobalLogger();
	if (typeof value !== "string") {
		if (value !== void 0) logger.warn("Propagated attribute 'environment' must be a string. Dropping value.");
		return false;
	}
	if (value.length > 40) {
		logger.warn(`Propagated attribute 'environment' value is over 40 characters (${value.length} chars). Dropping value.`);
		return false;
	}
	if (!ENVIRONMENT_VALUE_PATTERN.test(value)) {
		logger.warn("Propagated attribute 'environment' must be a lowercase alphanumeric string with optional hyphens or underscores and must not start with 'langfuse'. Dropping value.");
		return false;
	}
	return true;
}
function getContextKeyForPropagatedKey(key) {
	return LangfuseOtelContextKeys[key];
}
function getSpanKeyForPropagatedKey(key) {
	switch (key) {
		case "userId": return "user.id";
		case "sessionId": return "session.id";
		case "version": return "langfuse.version";
		case "traceName": return "langfuse.trace.name";
		case "environment": return "langfuse.environment";
		case "metadata": return "langfuse.trace.metadata";
		case "tags": return "langfuse.trace.tags";
		case "promptName": return "langfuse.observation.prompt.name";
		case "promptVersion": return "langfuse.observation.prompt.version";
		case "experimentId": return "langfuse.experiment.id";
		case "experimentName": return "langfuse.experiment.name";
		case "experimentMetadata": return "langfuse.experiment.metadata";
		case "experimentDatasetId": return "langfuse.experiment.dataset.id";
		case "experimentItemId": return "langfuse.experiment.item.id";
		case "experimentItemMetadata": return "langfuse.experiment.item.metadata";
		case "experimentItemRootObservationId": return "langfuse.experiment.item.root_observation_id";
		default: throw Error("Unhandled propagated key", key);
	}
}
function getBaggageKeyForPropagatedKey(key) {
	switch (key) {
		case "userId": return `${LANGFUSE_BAGGAGE_PREFIX}user_id`;
		case "sessionId": return `${LANGFUSE_BAGGAGE_PREFIX}session_id`;
		case "version": return `${LANGFUSE_BAGGAGE_PREFIX}version`;
		case "traceName": return `${LANGFUSE_BAGGAGE_PREFIX}trace_name`;
		case "environment": return `${LANGFUSE_BAGGAGE_PREFIX}environment`;
		case "metadata": return `${LANGFUSE_BAGGAGE_PREFIX}metadata`;
		case "tags": return `${LANGFUSE_BAGGAGE_PREFIX}tags`;
		case "promptName": return `${LANGFUSE_BAGGAGE_PREFIX}prompt_name`;
		case "promptVersion": return `${LANGFUSE_BAGGAGE_PREFIX}prompt_version`;
		case "experimentId": return `${LANGFUSE_BAGGAGE_PREFIX}experiment_id`;
		case "experimentName": return `${LANGFUSE_BAGGAGE_PREFIX}experiment_name`;
		case "experimentMetadata": return `${LANGFUSE_BAGGAGE_PREFIX}experiment_metadata`;
		case "experimentDatasetId": return `${LANGFUSE_BAGGAGE_PREFIX}experiment_dataset_id`;
		case "experimentItemId": return `${LANGFUSE_BAGGAGE_PREFIX}experiment_item_id`;
		case "experimentItemMetadata": return `${LANGFUSE_BAGGAGE_PREFIX}experiment_item_metadata`;
		case "experimentItemRootObservationId": return `${LANGFUSE_BAGGAGE_PREFIX}experiment_item_root_observation_id`;
		default: throw Error("Unhandled propagated key", key);
	}
}
function getSpanKeyFromBaggageKey(baggageKey) {
	if (!baggageKey.startsWith(LANGFUSE_BAGGAGE_PREFIX)) return;
	const suffix = baggageKey.slice(LANGFUSE_BAGGAGE_PREFIX.length);
	if (suffix.startsWith("metadata_")) return `langfuse.trace.metadata.${suffix.slice(9)}`;
	switch (suffix) {
		case "user_id": return getSpanKeyForPropagatedKey("userId");
		case "session_id": return getSpanKeyForPropagatedKey("sessionId");
		case "version": return getSpanKeyForPropagatedKey("version");
		case "trace_name": return getSpanKeyForPropagatedKey("traceName");
		case "environment": return getSpanKeyForPropagatedKey("environment");
		case "tags": return getSpanKeyForPropagatedKey("tags");
		case "prompt_name": return getSpanKeyForPropagatedKey("promptName");
		case "prompt_version": return getSpanKeyForPropagatedKey("promptVersion");
		case "experiment_id": return getSpanKeyForPropagatedKey("experimentId");
		case "experiment_name": return getSpanKeyForPropagatedKey("experimentName");
		case "experiment_metadata": return getSpanKeyForPropagatedKey("experimentMetadata");
		case "experiment_dataset_id": return getSpanKeyForPropagatedKey("experimentDatasetId");
		case "experiment_item_id": return getSpanKeyForPropagatedKey("experimentItemId");
		case "experiment_item_metadata": return getSpanKeyForPropagatedKey("experimentItemMetadata");
		case "experiment_item_root_observation_id": return getSpanKeyForPropagatedKey("experimentItemRootObservationId");
	}
}
//#endregion
//#region node_modules/@langfuse/tracing/dist/index.mjs
function createObservationAttributes(type, attributes) {
	const { metadata, input, output, level, statusMessage, version, environment, completionStartTime, model, modelParameters, usageDetails, costDetails, prompt } = attributes;
	let otelAttributes = {
		[LangfuseOtelSpanAttributes.OBSERVATION_TYPE]: type,
		[LangfuseOtelSpanAttributes.OBSERVATION_LEVEL]: level,
		[LangfuseOtelSpanAttributes.OBSERVATION_STATUS_MESSAGE]: statusMessage,
		[LangfuseOtelSpanAttributes.VERSION]: version,
		[LangfuseOtelSpanAttributes.ENVIRONMENT]: environment,
		[LangfuseOtelSpanAttributes.OBSERVATION_INPUT]: _serialize(input),
		[LangfuseOtelSpanAttributes.OBSERVATION_OUTPUT]: _serialize(output),
		[LangfuseOtelSpanAttributes.OBSERVATION_MODEL]: model,
		[LangfuseOtelSpanAttributes.OBSERVATION_USAGE_DETAILS]: _serialize(usageDetails),
		[LangfuseOtelSpanAttributes.OBSERVATION_COST_DETAILS]: _serialize(costDetails),
		[LangfuseOtelSpanAttributes.OBSERVATION_COMPLETION_START_TIME]: _serialize(completionStartTime),
		[LangfuseOtelSpanAttributes.OBSERVATION_MODEL_PARAMETERS]: _serialize(modelParameters),
		...prompt && !prompt.isFallback ? {
			[LangfuseOtelSpanAttributes.OBSERVATION_PROMPT_NAME]: prompt.name,
			[LangfuseOtelSpanAttributes.OBSERVATION_PROMPT_VERSION]: prompt.version
		} : {},
		..._flattenAndSerializeMetadata(metadata, "observation")
	};
	return Object.fromEntries(Object.entries(otelAttributes).filter(([_, v]) => v != null));
}
var RESERVED_OBSERVATION_ATTRIBUTE_KEYS = [
	LangfuseOtelSpanAttributes.OBSERVATION_TYPE,
	LangfuseOtelSpanAttributes.OBSERVATION_LEVEL,
	LangfuseOtelSpanAttributes.OBSERVATION_STATUS_MESSAGE,
	LangfuseOtelSpanAttributes.VERSION,
	LangfuseOtelSpanAttributes.ENVIRONMENT,
	LangfuseOtelSpanAttributes.OBSERVATION_INPUT,
	LangfuseOtelSpanAttributes.OBSERVATION_OUTPUT
];
var RESERVED_GENERATION_ATTRIBUTE_KEYS = [
	...RESERVED_OBSERVATION_ATTRIBUTE_KEYS,
	LangfuseOtelSpanAttributes.OBSERVATION_MODEL,
	LangfuseOtelSpanAttributes.OBSERVATION_USAGE_DETAILS,
	LangfuseOtelSpanAttributes.OBSERVATION_COST_DETAILS,
	LangfuseOtelSpanAttributes.OBSERVATION_COMPLETION_START_TIME,
	LangfuseOtelSpanAttributes.OBSERVATION_MODEL_PARAMETERS,
	LangfuseOtelSpanAttributes.OBSERVATION_PROMPT_NAME,
	LangfuseOtelSpanAttributes.OBSERVATION_PROMPT_VERSION
];
function setObservationAttributes(span, type, attributes, options) {
	const otelAttributes = createObservationAttributes(type, attributes);
	if (options?.omitType) delete otelAttributes[LangfuseOtelSpanAttributes.OBSERVATION_TYPE];
	const reservedKeys = options?.omitType || type === "generation" || type === "embedding" ? RESERVED_GENERATION_ATTRIBUTE_KEYS : RESERVED_OBSERVATION_ATTRIBUTE_KEYS;
	span.setAttributes(dropMetadataOverSpanAttributeLimit(span, otelAttributes, reservedKeys));
}
function _serialize(obj) {
	try {
		if (typeof obj === "string") return obj;
		return obj != null ? JSON.stringify(obj) : void 0;
	} catch {
		return "<failed to serialize>";
	}
}
function _flattenAndSerializeMetadata(metadata, type) {
	const prefix = type === "observation" ? LangfuseOtelSpanAttributes.OBSERVATION_METADATA : LangfuseOtelSpanAttributes.TRACE_METADATA;
	const metadataAttributes = {};
	if (metadata === void 0 || metadata === null) return metadataAttributes;
	if (typeof metadata !== "object" || Array.isArray(metadata)) {
		const serialized = serializeMetadataValue(metadata);
		if (serialized !== void 0) metadataAttributes[prefix] = serialized;
		else getGlobalLogger().debug("Observation metadata was not written because its value is not JSON-serializable");
	} else for (const [key, value] of Object.entries(metadata)) {
		const serialized = serializeMetadataValue(value);
		if (serialized !== void 0) metadataAttributes[`${prefix}.${key}`] = serialized;
		else getGlobalLogger().debug(`Observation metadata key "${key}" was not written because its value is ${value == null ? String(value) : "not JSON-serializable"}`);
	}
	return metadataAttributes;
}
var LANGFUSE_GLOBAL_SYMBOL = /* @__PURE__ */ Symbol.for("langfuse");
function createState() {
	return { isolatedTracerProvider: null };
}
function getGlobalState() {
	const initialState = createState();
	try {
		const g = globalThis;
		if (typeof g !== "object" || g === null) {
			getGlobalLogger().warn("globalThis is not available, using fallback state");
			return initialState;
		}
		if (!g[LANGFUSE_GLOBAL_SYMBOL]) Object.defineProperty(g, LANGFUSE_GLOBAL_SYMBOL, {
			value: initialState,
			writable: false,
			configurable: false,
			enumerable: false
		});
		return g[LANGFUSE_GLOBAL_SYMBOL];
	} catch (err) {
		if (err instanceof Error) getGlobalLogger().error(`Failed to access global state: ${err.message}`);
		else getGlobalLogger().error(`Failed to access global state: ${String(err)}`);
		return initialState;
	}
}
function getLangfuseTracerProvider() {
	const { isolatedTracerProvider } = getGlobalState();
	if (isolatedTracerProvider) return isolatedTracerProvider;
	return import_src.trace.getTracerProvider();
}
function getLangfuseTracer() {
	return getLangfuseTracerProvider().getTracer(LANGFUSE_TRACER_NAME, LANGFUSE_SDK_VERSION);
}
var LangfuseBaseObservation = class {
	/** The underlying OpenTelemetry span */
	otelSpan;
	/** The underlying OpenTelemetry span */
	type;
	/** The span ID from the OpenTelemetry span context */
	id;
	/** The trace ID from the OpenTelemetry span context */
	traceId;
	constructor(params) {
		this.otelSpan = params.otelSpan;
		this.id = params.otelSpan.spanContext().spanId;
		this.traceId = params.otelSpan.spanContext().traceId;
		this.type = params.type;
		setObservationAttributes(this.otelSpan, params.type, params.attributes ?? {});
	}
	/** Gets the Langfuse OpenTelemetry tracer instance */
	get tracer() {
		return getLangfuseTracer();
	}
	/**
	* Ends the observation, marking it as complete.
	*
	* @param endTime - Optional end time, defaults to current time
	*/
	end(endTime) {
		this.otelSpan.end(endTime);
	}
	updateOtelSpanAttributes(attributes) {
		setObservationAttributes(this.otelSpan, this.type, attributes);
	}
	/**
	* Make the trace this observation belongs to publicly accessible via its URL.
	*
	* When a trace is published, anyone with the trace link can view the full trace
	* without needing to be logged in to Langfuse. This action cannot be undone
	* programmatically - once any span in a trace is published, the entire trace
	* becomes public.
	*
	* @returns The observation instance for method chaining
	*
	* @example
	* ```typescript
	* const span = startObservation('my-operation');
	* span.setTraceAsPublic();
	* ```
	*/
	setTraceAsPublic() {
		this.otelSpan.setAttributes({ [LangfuseOtelSpanAttributes.TRACE_PUBLIC]: true });
		return this;
	}
	startObservation(name, attributes, options) {
		const { asType = "span" } = options || {};
		return startObservation(name, attributes, {
			asType,
			parentSpanContext: this.otelSpan.spanContext()
		});
	}
};
var LangfuseSpan = class extends LangfuseBaseObservation {
	constructor(params) {
		super({
			...params,
			type: "span"
		});
	}
	/**
	* Updates this span with new attributes.
	*
	* @param attributes - Span attributes to set
	* @returns This span for method chaining
	*
	* @example
	* ```typescript
	* span.update({
	*   output: { result: 'success' },
	*   level: 'DEFAULT',
	*   metadata: { duration: 150 }
	* });
	* ```
	*/
	update(attributes) {
		super.updateOtelSpanAttributes(attributes);
		return this;
	}
};
var LangfuseAgent = class extends LangfuseBaseObservation {
	constructor(params) {
		super({
			...params,
			type: "agent"
		});
	}
	/**
	* Updates this agent observation with new attributes.
	*
	* @param attributes - Agent attributes to set
	* @returns This agent for method chaining
	*
	* @example
	* ```typescript
	* agent.update({
	*   output: {
	*     taskCompleted: true,
	*     iterationsUsed: 5,
	*     toolsInvoked: ['web-search', 'calculator', 'summarizer'],
	*     finalResult: 'Research completed with high confidence'
	*   },
	*   metadata: {
	*     efficiency: 0.85,
	*     qualityScore: 0.92,
	*     resourcesConsumed: { tokens: 15000, apiCalls: 12 }
	*   }
	* });
	* ```
	*/
	update(attributes) {
		super.updateOtelSpanAttributes(attributes);
		return this;
	}
};
var LangfuseTool = class extends LangfuseBaseObservation {
	constructor(params) {
		super({
			...params,
			type: "tool"
		});
	}
	/**
	* Updates this tool observation with new attributes.
	*
	* @param attributes - Tool attributes to set
	* @returns This tool for method chaining
	*
	* @example
	* ```typescript
	* tool.update({
	*   output: {
	*     result: searchResults,
	*     count: searchResults.length,
	*     relevanceScore: 0.89,
	*     executionTime: 1250
	*   },
	*   metadata: {
	*     cacheHit: false,
	*     apiCost: 0.025,
	*     rateLimitRemaining: 950
	*   }
	* });
	* ```
	*/
	update(attributes) {
		super.updateOtelSpanAttributes(attributes);
		return this;
	}
};
var LangfuseChain = class extends LangfuseBaseObservation {
	constructor(params) {
		super({
			...params,
			type: "chain"
		});
	}
	/**
	* Updates this chain observation with new attributes.
	*
	* @param attributes - Chain attributes to set
	* @returns This chain for method chaining
	*
	* @example
	* ```typescript
	* chain.update({
	*   output: {
	*     stepsCompleted: 5,
	*     stepsSuccessful: 4,
	*     finalResult: processedData,
	*     pipelineEfficiency: 0.87
	*   },
	*   metadata: {
	*     bottleneckStep: 'data-validation',
	*     parallelizationOpportunities: ['step-2', 'step-3'],
	*     optimizationSuggestions: ['cache-intermediate-results']
	*   }
	* });
	* ```
	*/
	update(attributes) {
		super.updateOtelSpanAttributes(attributes);
		return this;
	}
};
var LangfuseRetriever = class extends LangfuseBaseObservation {
	constructor(params) {
		super({
			...params,
			type: "retriever"
		});
	}
	/**
	* Updates this retriever observation with new attributes.
	*
	* @param attributes - Retriever attributes to set
	* @returns This retriever for method chaining
	*/
	update(attributes) {
		super.updateOtelSpanAttributes(attributes);
		return this;
	}
};
var LangfuseEvaluator = class extends LangfuseBaseObservation {
	constructor(params) {
		super({
			...params,
			type: "evaluator"
		});
	}
	/**
	* Updates this evaluator observation with new attributes.
	*
	* @param attributes - Evaluator attributes to set
	* @returns This evaluator for method chaining
	*/
	update(attributes) {
		super.updateOtelSpanAttributes(attributes);
		return this;
	}
};
var LangfuseGuardrail = class extends LangfuseBaseObservation {
	constructor(params) {
		super({
			...params,
			type: "guardrail"
		});
	}
	/**
	* Updates this guardrail observation with new attributes.
	*
	* @param attributes - Guardrail attributes to set
	* @returns This guardrail for method chaining
	*/
	update(attributes) {
		super.updateOtelSpanAttributes(attributes);
		return this;
	}
};
var LangfuseGeneration = class extends LangfuseBaseObservation {
	constructor(params) {
		super({
			...params,
			type: "generation"
		});
	}
	update(attributes) {
		this.updateOtelSpanAttributes(attributes);
		return this;
	}
};
var LangfuseEmbedding = class extends LangfuseBaseObservation {
	constructor(params) {
		super({
			...params,
			type: "embedding"
		});
	}
	/**
	* Updates this embedding observation with new attributes.
	*
	* @param attributes - Embedding attributes to set
	* @returns This embedding for method chaining
	*/
	update(attributes) {
		this.updateOtelSpanAttributes(attributes);
		return this;
	}
};
var LangfuseEvent = class extends LangfuseBaseObservation {
	constructor(params) {
		super({
			...params,
			type: "event"
		});
		this.otelSpan.end(params.timestamp);
	}
};
function createOtelSpan(params) {
	return getLangfuseTracer().startSpan(params.name, { startTime: params.startTime }, createParentContext(params.parentSpanContext));
}
function createParentContext(parentSpanContext) {
	if (!parentSpanContext) return;
	return import_src.trace.setSpanContext(import_src.context.active(), parentSpanContext);
}
function wrapPromise(promise, span, endOnExit) {
	return promise.then((value) => {
		if (endOnExit !== false) span.end();
		return value;
	}, (err) => {
		span.setStatus({
			code: import_src.SpanStatusCode.ERROR,
			message: err instanceof Error ? err.message : "Unknown error"
		});
		if (endOnExit !== false) span.end();
		throw err;
	});
}
function startObservation(name, attributes, options) {
	const { asType = "span", ...observationOptions } = options || {};
	const otelSpan = createOtelSpan({
		name,
		...observationOptions
	});
	switch (asType) {
		case "generation": return new LangfuseGeneration({
			otelSpan,
			attributes
		});
		case "embedding": return new LangfuseEmbedding({
			otelSpan,
			attributes
		});
		case "agent": return new LangfuseAgent({
			otelSpan,
			attributes
		});
		case "tool": return new LangfuseTool({
			otelSpan,
			attributes
		});
		case "chain": return new LangfuseChain({
			otelSpan,
			attributes
		});
		case "retriever": return new LangfuseRetriever({
			otelSpan,
			attributes
		});
		case "evaluator": return new LangfuseEvaluator({
			otelSpan,
			attributes
		});
		case "guardrail": return new LangfuseGuardrail({
			otelSpan,
			attributes
		});
		case "event": return new LangfuseEvent({
			otelSpan,
			attributes,
			timestamp: observationOptions?.startTime ?? /* @__PURE__ */ new Date()
		});
		default: return new LangfuseSpan({
			otelSpan,
			attributes
		});
	}
}
function startActiveObservation(name, fn, options) {
	const { asType = "span", ...observationOptions } = options || {};
	return getLangfuseTracer().startActiveSpan(name, { startTime: observationOptions?.startTime }, createParentContext(observationOptions?.parentSpanContext) ?? import_src.context.active(), (span) => {
		const claimContext = setLangfuseTraceIdInBaggage(import_src.context.active(), span.spanContext().traceId);
		return import_src.context.with(claimContext, () => {
			try {
				let observation;
				switch (asType) {
					case "generation":
						observation = new LangfuseGeneration({ otelSpan: span });
						break;
					case "embedding":
						observation = new LangfuseEmbedding({ otelSpan: span });
						break;
					case "agent":
						observation = new LangfuseAgent({ otelSpan: span });
						break;
					case "tool":
						observation = new LangfuseTool({ otelSpan: span });
						break;
					case "chain":
						observation = new LangfuseChain({ otelSpan: span });
						break;
					case "retriever":
						observation = new LangfuseRetriever({ otelSpan: span });
						break;
					case "evaluator":
						observation = new LangfuseEvaluator({ otelSpan: span });
						break;
					case "guardrail":
						observation = new LangfuseGuardrail({ otelSpan: span });
						break;
					case "event":
						observation = new LangfuseEvent({
							otelSpan: span,
							timestamp: observationOptions?.startTime ?? /* @__PURE__ */ new Date()
						});
						break;
					default: observation = new LangfuseSpan({ otelSpan: span });
				}
				const result = fn(observation);
				if (result instanceof Promise) return wrapPromise(result, span, observationOptions?.endOnExit);
				else {
					if (observationOptions?.endOnExit !== false) span.end();
					return result;
				}
			} catch (err) {
				span.setStatus({
					code: import_src.SpanStatusCode.ERROR,
					message: err instanceof Error ? err.message : "Unknown error"
				});
				if (observationOptions?.endOnExit !== false) span.end();
				throw err;
			}
		});
	});
}
//#endregion
//#region node_modules/mustache/mustache.mjs
/*!
* mustache.js - Logic-less {{mustache}} templates with JavaScript
* http://github.com/janl/mustache.js
*/
var objectToString = Object.prototype.toString;
var isArray = Array.isArray || function isArrayPolyfill(object) {
	return objectToString.call(object) === "[object Array]";
};
function isFunction(object) {
	return typeof object === "function";
}
/**
* More correct typeof string handling array
* which normally returns typeof 'object'
*/
function typeStr(obj) {
	return isArray(obj) ? "array" : typeof obj;
}
function escapeRegExp(string) {
	return string.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&");
}
/**
* Null safe way of checking whether or not an object,
* including its prototype, has a given property
*/
function hasProperty(obj, propName) {
	return obj != null && typeof obj === "object" && propName in obj;
}
/**
* Safe way of detecting whether or not the given thing is a primitive and
* whether it has the given property
*/
function primitiveHasOwnProperty(primitive, propName) {
	return primitive != null && typeof primitive !== "object" && primitive.hasOwnProperty && primitive.hasOwnProperty(propName);
}
var regExpTest = RegExp.prototype.test;
function testRegExp(re, string) {
	return regExpTest.call(re, string);
}
var nonSpaceRe = /\S/;
function isWhitespace(string) {
	return !testRegExp(nonSpaceRe, string);
}
var entityMap = {
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;",
	"/": "&#x2F;",
	"`": "&#x60;",
	"=": "&#x3D;"
};
function escapeHtml(string) {
	return String(string).replace(/[&<>"'`=\/]/g, function fromEntityMap(s) {
		return entityMap[s];
	});
}
var whiteRe = /\s*/;
var spaceRe = /\s+/;
var equalsRe = /\s*=/;
var curlyRe = /\s*\}/;
var tagRe = /#|\^|\/|>|\{|&|=|!/;
/**
* Breaks up the given `template` string into a tree of tokens. If the `tags`
* argument is given here it must be an array with two string values: the
* opening and closing tags used in the template (e.g. [ "<%", "%>" ]). Of
* course, the default is to use mustaches (i.e. mustache.tags).
*
* A token is an array with at least 4 elements. The first element is the
* mustache symbol that was used inside the tag, e.g. "#" or "&". If the tag
* did not contain a symbol (i.e. {{myValue}}) this element is "name". For
* all text that appears outside a symbol this element is "text".
*
* The second element of a token is its "value". For mustache tags this is
* whatever else was inside the tag besides the opening symbol. For text tokens
* this is the text itself.
*
* The third and fourth elements of the token are the start and end indices,
* respectively, of the token in the original template.
*
* Tokens that are the root node of a subtree contain two more elements: 1) an
* array of tokens in the subtree and 2) the index in the original template at
* which the closing tag for that section begins.
*
* Tokens for partials also contain two more elements: 1) a string value of
* indendation prior to that tag and 2) the index of that tag on that line -
* eg a value of 2 indicates the partial is the third tag on this line.
*/
function parseTemplate(template, tags) {
	if (!template) return [];
	var lineHasNonSpace = false;
	var sections = [];
	var tokens = [];
	var spaces = [];
	var hasTag = false;
	var nonSpace = false;
	var indentation = "";
	var tagIndex = 0;
	function stripSpace() {
		if (hasTag && !nonSpace) while (spaces.length) delete tokens[spaces.pop()];
		else spaces = [];
		hasTag = false;
		nonSpace = false;
	}
	var openingTagRe, closingTagRe, closingCurlyRe;
	function compileTags(tagsToCompile) {
		if (typeof tagsToCompile === "string") tagsToCompile = tagsToCompile.split(spaceRe, 2);
		if (!isArray(tagsToCompile) || tagsToCompile.length !== 2) throw new Error("Invalid tags: " + tagsToCompile);
		openingTagRe = new RegExp(escapeRegExp(tagsToCompile[0]) + "\\s*");
		closingTagRe = new RegExp("\\s*" + escapeRegExp(tagsToCompile[1]));
		closingCurlyRe = new RegExp("\\s*" + escapeRegExp("}" + tagsToCompile[1]));
	}
	compileTags(tags || mustache.tags);
	var scanner = new Scanner(template);
	var start, type, value, chr, token, openSection;
	while (!scanner.eos()) {
		start = scanner.pos;
		value = scanner.scanUntil(openingTagRe);
		if (value) for (var i = 0, valueLength = value.length; i < valueLength; ++i) {
			chr = value.charAt(i);
			if (isWhitespace(chr)) {
				spaces.push(tokens.length);
				indentation += chr;
			} else {
				nonSpace = true;
				lineHasNonSpace = true;
				indentation += " ";
			}
			tokens.push([
				"text",
				chr,
				start,
				start + 1
			]);
			start += 1;
			if (chr === "\n") {
				stripSpace();
				indentation = "";
				tagIndex = 0;
				lineHasNonSpace = false;
			}
		}
		if (!scanner.scan(openingTagRe)) break;
		hasTag = true;
		type = scanner.scan(tagRe) || "name";
		scanner.scan(whiteRe);
		if (type === "=") {
			value = scanner.scanUntil(equalsRe);
			scanner.scan(equalsRe);
			scanner.scanUntil(closingTagRe);
		} else if (type === "{") {
			value = scanner.scanUntil(closingCurlyRe);
			scanner.scan(curlyRe);
			scanner.scanUntil(closingTagRe);
			type = "&";
		} else value = scanner.scanUntil(closingTagRe);
		if (!scanner.scan(closingTagRe)) throw new Error("Unclosed tag at " + scanner.pos);
		if (type == ">") token = [
			type,
			value,
			start,
			scanner.pos,
			indentation,
			tagIndex,
			lineHasNonSpace
		];
		else token = [
			type,
			value,
			start,
			scanner.pos
		];
		tagIndex++;
		tokens.push(token);
		if (type === "#" || type === "^") sections.push(token);
		else if (type === "/") {
			openSection = sections.pop();
			if (!openSection) throw new Error("Unopened section \"" + value + "\" at " + start);
			if (openSection[1] !== value) throw new Error("Unclosed section \"" + openSection[1] + "\" at " + start);
		} else if (type === "name" || type === "{" || type === "&") nonSpace = true;
		else if (type === "=") compileTags(value);
	}
	stripSpace();
	openSection = sections.pop();
	if (openSection) throw new Error("Unclosed section \"" + openSection[1] + "\" at " + scanner.pos);
	return nestTokens(squashTokens(tokens));
}
/**
* Combines the values of consecutive text tokens in the given `tokens` array
* to a single token.
*/
function squashTokens(tokens) {
	var squashedTokens = [];
	var token, lastToken;
	for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
		token = tokens[i];
		if (token) {
			if (token[0] === "text" && lastToken && lastToken[0] === "text") {
				lastToken[1] += token[1];
				lastToken[3] = token[3];
			} else {
				squashedTokens.push(token);
				lastToken = token;
			}
		}
	}
	return squashedTokens;
}
/**
* Forms the given array of `tokens` into a nested tree structure where
* tokens that represent a section have two additional items: 1) an array of
* all tokens that appear in that section and 2) the index in the original
* template that represents the end of that section.
*/
function nestTokens(tokens) {
	var nestedTokens = [];
	var collector = nestedTokens;
	var sections = [];
	var token, section;
	for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
		token = tokens[i];
		switch (token[0]) {
			case "#":
			case "^":
				collector.push(token);
				sections.push(token);
				collector = token[4] = [];
				break;
			case "/":
				section = sections.pop();
				section[5] = token[2];
				collector = sections.length > 0 ? sections[sections.length - 1][4] : nestedTokens;
				break;
			default: collector.push(token);
		}
	}
	return nestedTokens;
}
/**
* A simple string scanner that is used by the template parser to find
* tokens in template strings.
*/
function Scanner(string) {
	this.string = string;
	this.tail = string;
	this.pos = 0;
}
/**
* Returns `true` if the tail is empty (end of string).
*/
Scanner.prototype.eos = function eos() {
	return this.tail === "";
};
/**
* Tries to match the given regular expression at the current position.
* Returns the matched text if it can match, the empty string otherwise.
*/
Scanner.prototype.scan = function scan(re) {
	var match = this.tail.match(re);
	if (!match || match.index !== 0) return "";
	var string = match[0];
	this.tail = this.tail.substring(string.length);
	this.pos += string.length;
	return string;
};
/**
* Skips all text until the given regular expression can be matched. Returns
* the skipped string, which is the entire tail if no match can be made.
*/
Scanner.prototype.scanUntil = function scanUntil(re) {
	var index = this.tail.search(re), match;
	switch (index) {
		case -1:
			match = this.tail;
			this.tail = "";
			break;
		case 0:
			match = "";
			break;
		default:
			match = this.tail.substring(0, index);
			this.tail = this.tail.substring(index);
	}
	this.pos += match.length;
	return match;
};
/**
* Represents a rendering context by wrapping a view object and
* maintaining a reference to the parent context.
*/
function Context(view, parentContext) {
	this.view = view;
	this.cache = { ".": this.view };
	this.parent = parentContext;
}
/**
* Creates a new context using the given view with this context
* as the parent.
*/
Context.prototype.push = function push(view) {
	return new Context(view, this);
};
/**
* Returns the value of the given name in this context, traversing
* up the context hierarchy if the value is absent in this context's view.
*/
Context.prototype.lookup = function lookup(name) {
	var cache = this.cache;
	var value;
	if (cache.hasOwnProperty(name)) value = cache[name];
	else {
		var context = this, intermediateValue, names, index, lookupHit = false;
		while (context) {
			if (name.indexOf(".") > 0) {
				intermediateValue = context.view;
				names = name.split(".");
				index = 0;
				/**
				* Using the dot notion path in `name`, we descend through the
				* nested objects.
				*
				* To be certain that the lookup has been successful, we have to
				* check if the last object in the path actually has the property
				* we are looking for. We store the result in `lookupHit`.
				*
				* This is specially necessary for when the value has been set to
				* `undefined` and we want to avoid looking up parent contexts.
				*
				* In the case where dot notation is used, we consider the lookup
				* to be successful even if the last "object" in the path is
				* not actually an object but a primitive (e.g., a string, or an
				* integer), because it is sometimes useful to access a property
				* of an autoboxed primitive, such as the length of a string.
				**/
				while (intermediateValue != null && index < names.length) {
					if (index === names.length - 1) lookupHit = hasProperty(intermediateValue, names[index]) || primitiveHasOwnProperty(intermediateValue, names[index]);
					intermediateValue = intermediateValue[names[index++]];
				}
			} else {
				intermediateValue = context.view[name];
				/**
				* Only checking against `hasProperty`, which always returns `false` if
				* `context.view` is not an object. Deliberately omitting the check
				* against `primitiveHasOwnProperty` if dot notation is not used.
				*
				* Consider this example:
				* ```
				* Mustache.render("The length of a football field is {{#length}}{{length}}{{/length}}.", {length: "100 yards"})
				* ```
				*
				* If we were to check also against `primitiveHasOwnProperty`, as we do
				* in the dot notation case, then render call would return:
				*
				* "The length of a football field is 9."
				*
				* rather than the expected:
				*
				* "The length of a football field is 100 yards."
				**/
				lookupHit = hasProperty(context.view, name);
			}
			if (lookupHit) {
				value = intermediateValue;
				break;
			}
			context = context.parent;
		}
		cache[name] = value;
	}
	if (isFunction(value)) value = value.call(this.view);
	return value;
};
/**
* A Writer knows how to take a stream of tokens and render them to a
* string, given a context. It also maintains a cache of templates to
* avoid the need to parse the same template twice.
*/
function Writer() {
	this.templateCache = {
		_cache: {},
		set: function set(key, value) {
			this._cache[key] = value;
		},
		get: function get(key) {
			return this._cache[key];
		},
		clear: function clear() {
			this._cache = {};
		}
	};
}
/**
* Clears all cached templates in this writer.
*/
Writer.prototype.clearCache = function clearCache() {
	if (typeof this.templateCache !== "undefined") this.templateCache.clear();
};
/**
* Parses and caches the given `template` according to the given `tags` or
* `mustache.tags` if `tags` is omitted,  and returns the array of tokens
* that is generated from the parse.
*/
Writer.prototype.parse = function parse(template, tags) {
	var cache = this.templateCache;
	var cacheKey = template + ":" + (tags || mustache.tags).join(":");
	var isCacheEnabled = typeof cache !== "undefined";
	var tokens = isCacheEnabled ? cache.get(cacheKey) : void 0;
	if (tokens == void 0) {
		tokens = parseTemplate(template, tags);
		isCacheEnabled && cache.set(cacheKey, tokens);
	}
	return tokens;
};
/**
* High-level method that is used to render the given `template` with
* the given `view`.
*
* The optional `partials` argument may be an object that contains the
* names and templates of partials that are used in the template. It may
* also be a function that is used to load partial templates on the fly
* that takes a single argument: the name of the partial.
*
* If the optional `config` argument is given here, then it should be an
* object with a `tags` attribute or an `escape` attribute or both.
* If an array is passed, then it will be interpreted the same way as
* a `tags` attribute on a `config` object.
*
* The `tags` attribute of a `config` object must be an array with two
* string values: the opening and closing tags used in the template (e.g.
* [ "<%", "%>" ]). The default is to mustache.tags.
*
* The `escape` attribute of a `config` object must be a function which
* accepts a string as input and outputs a safely escaped string.
* If an `escape` function is not provided, then an HTML-safe string
* escaping function is used as the default.
*/
Writer.prototype.render = function render(template, view, partials, config) {
	var tags = this.getConfigTags(config);
	var tokens = this.parse(template, tags);
	var context = view instanceof Context ? view : new Context(view, void 0);
	return this.renderTokens(tokens, context, partials, template, config);
};
/**
* Low-level method that renders the given array of `tokens` using
* the given `context` and `partials`.
*
* Note: The `originalTemplate` is only ever used to extract the portion
* of the original template that was contained in a higher-order section.
* If the template doesn't use higher-order sections, this argument may
* be omitted.
*/
Writer.prototype.renderTokens = function renderTokens(tokens, context, partials, originalTemplate, config) {
	var buffer = "";
	var token, symbol, value;
	for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
		value = void 0;
		token = tokens[i];
		symbol = token[0];
		if (symbol === "#") value = this.renderSection(token, context, partials, originalTemplate, config);
		else if (symbol === "^") value = this.renderInverted(token, context, partials, originalTemplate, config);
		else if (symbol === ">") value = this.renderPartial(token, context, partials, config);
		else if (symbol === "&") value = this.unescapedValue(token, context);
		else if (symbol === "name") value = this.escapedValue(token, context, config);
		else if (symbol === "text") value = this.rawValue(token);
		if (value !== void 0) buffer += value;
	}
	return buffer;
};
Writer.prototype.renderSection = function renderSection(token, context, partials, originalTemplate, config) {
	var self = this;
	var buffer = "";
	var value = context.lookup(token[1]);
	function subRender(template) {
		return self.render(template, context, partials, config);
	}
	if (!value) return;
	if (isArray(value)) for (var j = 0, valueLength = value.length; j < valueLength; ++j) buffer += this.renderTokens(token[4], context.push(value[j]), partials, originalTemplate, config);
	else if (typeof value === "object" || typeof value === "string" || typeof value === "number") buffer += this.renderTokens(token[4], context.push(value), partials, originalTemplate, config);
	else if (isFunction(value)) {
		if (typeof originalTemplate !== "string") throw new Error("Cannot use higher-order sections without the original template");
		value = value.call(context.view, originalTemplate.slice(token[3], token[5]), subRender);
		if (value != null) buffer += value;
	} else buffer += this.renderTokens(token[4], context, partials, originalTemplate, config);
	return buffer;
};
Writer.prototype.renderInverted = function renderInverted(token, context, partials, originalTemplate, config) {
	var value = context.lookup(token[1]);
	if (!value || isArray(value) && value.length === 0) return this.renderTokens(token[4], context, partials, originalTemplate, config);
};
Writer.prototype.indentPartial = function indentPartial(partial, indentation, lineHasNonSpace) {
	var filteredIndentation = indentation.replace(/[^ \t]/g, "");
	var partialByNl = partial.split("\n");
	for (var i = 0; i < partialByNl.length; i++) if (partialByNl[i].length && (i > 0 || !lineHasNonSpace)) partialByNl[i] = filteredIndentation + partialByNl[i];
	return partialByNl.join("\n");
};
Writer.prototype.renderPartial = function renderPartial(token, context, partials, config) {
	if (!partials) return;
	var tags = this.getConfigTags(config);
	var value = isFunction(partials) ? partials(token[1]) : partials[token[1]];
	if (value != null) {
		var lineHasNonSpace = token[6];
		var tagIndex = token[5];
		var indentation = token[4];
		var indentedValue = value;
		if (tagIndex == 0 && indentation) indentedValue = this.indentPartial(value, indentation, lineHasNonSpace);
		var tokens = this.parse(indentedValue, tags);
		return this.renderTokens(tokens, context, partials, indentedValue, config);
	}
};
Writer.prototype.unescapedValue = function unescapedValue(token, context) {
	var value = context.lookup(token[1]);
	if (value != null) return value;
};
Writer.prototype.escapedValue = function escapedValue(token, context, config) {
	var escape = this.getConfigEscape(config) || mustache.escape;
	var value = context.lookup(token[1]);
	if (value != null) return typeof value === "number" && escape === mustache.escape ? String(value) : escape(value);
};
Writer.prototype.rawValue = function rawValue(token) {
	return token[1];
};
Writer.prototype.getConfigTags = function getConfigTags(config) {
	if (isArray(config)) return config;
	else if (config && typeof config === "object") return config.tags;
	else return;
};
Writer.prototype.getConfigEscape = function getConfigEscape(config) {
	if (config && typeof config === "object" && !isArray(config)) return config.escape;
	else return;
};
var mustache = {
	name: "mustache.js",
	version: "4.2.0",
	tags: ["{{", "}}"],
	clearCache: void 0,
	escape: void 0,
	parse: void 0,
	render: void 0,
	Scanner: void 0,
	Context: void 0,
	Writer: void 0,
	/**
	* Allows a user to override the default caching strategy, by providing an
	* object with set, get and clear methods. This can also be used to disable
	* the cache by setting it to the literal `undefined`.
	*/
	set templateCache(cache) {
		defaultWriter.templateCache = cache;
	},
	/**
	* Gets the default or overridden caching object from the default writer.
	*/
	get templateCache() {
		return defaultWriter.templateCache;
	}
};
var defaultWriter = new Writer();
/**
* Clears all cached templates in the default writer.
*/
mustache.clearCache = function clearCache() {
	return defaultWriter.clearCache();
};
/**
* Parses and caches the given template in the default writer and returns the
* array of tokens it contains. Doing this ahead of time avoids the need to
* parse templates on the fly as they are rendered.
*/
mustache.parse = function parse(template, tags) {
	return defaultWriter.parse(template, tags);
};
/**
* Renders the `template` with the given `view`, `partials`, and `config`
* using the default writer.
*/
mustache.render = function render(template, view, partials, config) {
	if (typeof template !== "string") throw new TypeError("Invalid template! Template should be a \"string\" but \"" + typeStr(template) + "\" was given as the first argument for mustache#render(template, view, partials)");
	return defaultWriter.render(template, view, partials, config);
};
mustache.escape = escapeHtml;
mustache.Scanner = Scanner;
mustache.Context = Context;
mustache.Writer = Writer;
//#endregion
//#region node_modules/@langfuse/client/dist/index.mjs
function parseJsonPath(jsonPath) {
	if (!jsonPath.startsWith("$")) throw new Error(`Invalid JSONPath: ${jsonPath}`);
	const segments = [];
	let i = 1;
	const n = jsonPath.length;
	while (i < n) {
		if (jsonPath[i] !== "[") throw new Error(`Invalid JSONPath: ${jsonPath}`);
		i += 1;
		if (jsonPath[i] === "'") {
			i += 1;
			const close = jsonPath.indexOf("']", i);
			if (close === -1) throw new Error(`Invalid JSONPath: ${jsonPath}`);
			segments.push(jsonPath.slice(i, close));
			i = close + 2;
		} else {
			const start = i;
			while (i < n && jsonPath[i] >= "0" && jsonPath[i] <= "9") i += 1;
			if (i === start || i >= n || jsonPath[i] !== "]") throw new Error(`Invalid JSONPath: ${jsonPath}`);
			segments.push(Number.parseInt(jsonPath.slice(start, i), 10));
			i += 1;
		}
	}
	return segments;
}
function setValueAtPath(value, jsonPath, replacement) {
	const segments = parseJsonPath(jsonPath);
	if (segments.length === 0) return replacement;
	let target = value;
	for (const segment of segments.slice(0, -1)) target = target[segment];
	const leaf = segments[segments.length - 1];
	if (typeof leaf === "number" && !Array.isArray(target)) throw new Error(`Cannot resolve JSONPath: ${jsonPath}`);
	target[leaf] = replacement;
	return value;
}
var MAX_MEDIA_TRAVERSAL_DEPTH = 20;
function isPlainObject(value) {
	const proto = Object.getPrototypeOf(value);
	return proto === Object.prototype || proto === null;
}
var MEDIA_REFERENCE_FIELD_TO_ITEM_KEY = {
	input: "input",
	expectedOutput: "expectedOutput",
	metadata: "metadata"
};
function hydrateDatasetItemMediaReferences(item) {
	const mediaReferences = item.mediaReferences ?? [];
	for (const mediaReference of mediaReferences) {
		const media = mediaReference.media;
		if (!media) continue;
		const itemKey = MEDIA_REFERENCE_FIELD_TO_ITEM_KEY[mediaReference.field];
		if (!itemKey) {
			getGlobalLogger().warn(`Unrecognised media reference field "${mediaReference.field}", skipping hydration.`);
			continue;
		}
		const replacement = new LangfuseMediaReference({
			mediaId: media.mediaId,
			contentType: media.contentType,
			url: media.url,
			urlExpiry: media.urlExpiry,
			contentLength: media.contentLength,
			referenceString: mediaReference.referenceString
		});
		const itemRecord = item;
		try {
			itemRecord[itemKey] = setValueAtPath(itemRecord[itemKey], mediaReference.jsonPath, replacement);
		} catch (error) {
			getGlobalLogger().warn(`Failed to hydrate dataset media reference at JSONPath ${mediaReference.jsonPath}`, error);
		}
	}
	return item;
}
var DatasetManager = class {
	langfuseClient;
	/**
	* Creates a new DatasetManager instance.
	*
	* @param params - Configuration object containing the API client
	* @internal
	*/
	constructor(params) {
		this.langfuseClient = params.langfuseClient;
	}
	/**
	* Retrieves a dataset by name with all its items and experiment functionality.
	*
	* This method fetches a dataset and all its associated items, with support
	* for automatic pagination to handle large datasets efficiently. The returned
	* dataset object includes functionality for running experiments directly
	* on the dataset.
	*
	* @param name - The name of the dataset to retrieve
	* @param options - Optional configuration for data fetching
	* @param options.fetchItemsPageSize - Number of items to fetch per page (default: 50)
	* @returns Promise resolving to enhanced dataset with items and experiment capabilities
	*
	* @example Basic dataset retrieval
	* ```typescript
	* const dataset = await langfuse.dataset.get("my-evaluation-dataset");
	* console.log(`Dataset ${dataset.name} has ${dataset.items.length} items`);
	*
	* // Access dataset properties
	* console.log(dataset.description);
	* console.log(dataset.metadata);
	* ```
	*
	* @example Working with dataset items
	* ```typescript
	* const dataset = await langfuse.dataset.get("qa-dataset");
	*
	* for (const item of dataset.items) {
	*   console.log("Question:", item.input);
	*   console.log("Expected Answer:", item.expectedOutput);
	* }
	* ```
	*
	* @example Running experiments on datasets
	* ```typescript
	* const dataset = await langfuse.dataset.get("benchmark-dataset");
	*
	* const result = await dataset.runExperiment({
	*   name: "GPT-4 Benchmark",
	*   runName: "GPT-4 Benchmark v1.2", // optional exact run name
	*   description: "Evaluating GPT-4 on our benchmark tasks",
	*   task: async ({ input }) => {
	*     const response = await openai.chat.completions.create({
	*       model: "gpt-4",
	*       messages: [{ role: "user", content: input }]
	*     });
	*     return response.choices[0].message.content;
	*   },
	*   evaluators: [
	*     async ({ output, expectedOutput }) => ({
	*       name: "exact_match",
	*       value: output === expectedOutput ? 1 : 0
	*     })
	*   ]
	* });
	*
	* console.log(await result.format());
	* ```
	*
	* @example Handling large datasets
	* ```typescript
	* // For very large datasets, use smaller page sizes
	* const largeDataset = await langfuse.dataset.get(
	*   "large-dataset",
	*   { fetchItemsPageSize: 100 }
	* );
	* ```
	*
	* @throws {Error} If the dataset does not exist or cannot be accessed
	* @see {@link FetchedDataset} for the complete return type specification
	* @see {@link RunExperimentOnDataset} for experiment execution details
	* @public
	* @since 4.0.0
	*/
	async get(name, options) {
		const dataset = await this.langfuseClient.api.datasets.get(name);
		const items = [];
		let page = 1;
		while (true) {
			const itemsResponse = await this.langfuseClient.api.datasetItems.list({
				datasetName: name,
				limit: options?.fetchItemsPageSize ?? 50,
				page,
				...options?.version && { version: options.version }
			});
			items.push(...itemsResponse.data.map(hydrateDatasetItemMediaReferences));
			if (itemsResponse.meta.totalPages <= page) break;
			page++;
		}
		const runExperiment = (params) => {
			return this.langfuseClient.experiment.run({
				data: items,
				datasetVersion: options?.version,
				...params
			});
		};
		return {
			...dataset,
			items,
			version: options?.version,
			runExperiment
		};
	}
	/**
	* Creates (or upserts) a dataset item, handling media upload.
	*
	* Any {@link LangfuseMedia} found in `input`, `expectedOutput`, or `metadata`
	* (including nested in objects and arrays) is uploaded to Langfuse and
	* replaced with a media reference string before the item is created. The same
	* media is uploaded at most once per call.
	*
	* @param request - The dataset item to create
	* @returns The created dataset item
	*
	* @example Creating an item with media
	* ```typescript
	* await langfuse.dataset.createItem({
	*   datasetName: "vision-eval",
	*   input: {
	*     question: "Compare the candidate image against the reference image.",
	*     candidate: new LangfuseMedia({
	*       source: "bytes",
	*       contentBytes: candidateBytes,
	*       contentType: "image/png",
	*     }),
	*   },
	*   expectedOutput: {
	*     reference: new LangfuseMedia({
	*       source: "bytes",
	*       contentBytes: referenceBytes,
	*       contentType: "image/png",
	*     }),
	*     label: "match",
	*   },
	* });
	* ```
	*
	* @public
	*/
	async createItem(request) {
		const datasetItemId = request.id ?? generateUUID();
		const toUpload = /* @__PURE__ */ new Map();
		const [input, expectedOutput, metadata] = await Promise.all([
			replaceDatasetItemMedia(request.input, "input", toUpload),
			replaceDatasetItemMedia(request.expectedOutput, "expectedOutput", toUpload),
			replaceDatasetItemMedia(request.metadata, "metadata", toUpload)
		]);
		if (toUpload.size > 0) {
			const datasetId = (await this.langfuseClient.api.datasets.get(request.datasetName)).id;
			await Promise.all([...toUpload.values()].map(({ media, field }) => uploadMedia({
				apiClient: this.langfuseClient.api,
				media,
				datasetId,
				datasetItemId,
				field
			})));
		}
		return await this.langfuseClient.api.datasetItems.create({
			...request,
			id: datasetItemId,
			input,
			expectedOutput,
			metadata
		});
	}
};
async function replaceDatasetItemMedia(data, field, collected, level = 1, ancestors = /* @__PURE__ */ new Set()) {
	if (data instanceof LangfuseMedia) {
		const [referenceString, mediaId] = await Promise.all([data.getTag(), data.getId()]);
		if (!referenceString || !mediaId) throw new Error("Cannot create dataset item with invalid LangfuseMedia.");
		if (!collected.has(mediaId)) collected.set(mediaId, {
			media: data,
			field
		});
		return referenceString;
	}
	if (data instanceof LangfuseMediaReference) return data.referenceString;
	const isArray = Array.isArray(data);
	if (data === null || typeof data !== "object" || !isArray && !isPlainObject(data)) return data;
	if (ancestors.has(data)) return data;
	if (level > MAX_MEDIA_TRAVERSAL_DEPTH) {
		getGlobalLogger().warn(`Dataset item media traversal exceeded ${MAX_MEDIA_TRAVERSAL_DEPTH} levels; any LangfuseMedia nested deeper will not be uploaded.`);
		return data;
	}
	const nextAncestors = new Set(ancestors).add(data);
	const recurse = (value) => replaceDatasetItemMedia(value, field, collected, level + 1, nextAncestors);
	if (isArray) return Promise.all(data.map(recurse));
	const entries = await Promise.all(Object.entries(data).map(async ([key, value]) => [key, await recurse(value)]));
	return Object.fromEntries(entries);
}
var ExperimentManager = class {
	langfuseClient;
	/**
	* Creates a new ExperimentManager instance.
	*
	* @param params - Configuration object
	* @param params.langfuseClient - The Langfuse client instance for API communication
	* @internal
	*/
	constructor(params) {
		this.langfuseClient = params.langfuseClient;
	}
	/**
	* Gets the global logger instance for experiment-related logging.
	*
	* @returns The global logger instance
	* @internal
	*/
	get logger() {
		return getGlobalLogger();
	}
	/**
	* Executes an experiment by running a task on each data item and evaluating the results.
	*
	* This method orchestrates the complete experiment lifecycle:
	* 1. Executes the task function on each data item with proper tracing
	* 2. Runs item-level evaluators on each task output
	* 3. Executes run-level evaluators on the complete result set
	* 4. Groups all items into one Langfuse experiment (stable per dataset and run name)
	* 5. Stores all scores and traces in Langfuse
	*
	* @param config - The experiment configuration
	* @param config.name - Human-readable name for the experiment
	* @param config.runName - Optional exact name for the experiment run (defaults to name + timestamp)
	* @param config.experimentId - Optional ID of the experiment to record into, so several runs (e.g. parallel workers or resumed runs) share one experiment
	* @param config.description - Optional description of the experiment's purpose
	* @param config.metadata - Optional metadata to attach to the experiment run
	* @param config.data - Array of data items to process (ExperimentItem[] or DatasetItem[])
	* @param config.task - Function that processes each data item and returns output
	* @param config.evaluators - Optional array of functions to evaluate each item's output
	* @param config.runEvaluators - Optional array of functions to evaluate the entire run
	* @param config.maxConcurrency - Maximum number of concurrent task executions (default: 50)
	*
	* @returns Promise that resolves to experiment results including:
	*   - experimentId: Identifier of the experiment in Langfuse
	*   - experimentUrl: Link to the experiment results in the Langfuse UI
	*   - runName: The experiment run name (either provided or generated)
	*   - itemResults: Results for each processed data item
	*   - runEvaluations: Results from run-level evaluators
	*   - datasetRunId: ID of the dataset run (if using Langfuse datasets)
	*   - format: Function to format results for display
	*
	* @throws {Error} When task execution fails and cannot be handled gracefully
	* @throws {Error} When required evaluators fail critically
	*
	* @example Simple experiment
	* ```typescript
	* const result = await langfuse.experiment.run({
	*   name: "Translation Quality Test",
	*   data: [
	*     { input: "Hello world", expectedOutput: "Hola mundo" },
	*     { input: "Good morning", expectedOutput: "Buenos días" }
	*   ],
	*   task: async ({ input }) => translateText(input, 'es'),
	*   evaluators: [
	*     async ({ output, expectedOutput }) => ({
	*       name: "bleu_score",
	*       value: calculateBleuScore(output, expectedOutput)
	*     })
	*   ]
	* });
	* ```
	*
	* @example Experiment with concurrency control
	* ```typescript
	* const result = await langfuse.experiment.run({
	*   name: "Large Scale Evaluation",
	*   data: largeBatchOfItems,
	*   task: expensiveModelCall,
	*   maxConcurrency: 5, // Process max 5 items simultaneously
	*   evaluators: [myEvaluator],
	*   runEvaluators: [
	*     async ({ itemResults }) => ({
	*       name: "average_score",
	*       value: itemResults.reduce((acc, r) => acc + r.evaluations[0].value, 0) / itemResults.length
	*     })
	*   ]
	* });
	* ```
	*
	* @see {@link ExperimentParams} for detailed parameter documentation
	* @see {@link ExperimentResult} for detailed return value documentation
	* @see {@link Evaluator} for evaluator function specifications
	* @see {@link RunEvaluator} for run evaluator function specifications
	*
	* @public
	*/
	async run(config) {
		const { data, evaluators, task, name, runName: providedRunName, experimentId: providedExperimentId, description, metadata, maxConcurrency = 50, runEvaluators } = config;
		if (providedExperimentId !== void 0 && !providedExperimentId.trim()) throw new Error("`experimentId` must be a non-empty string. Omit it to generate one.");
		const runName = this.createExperimentRunName({
			name,
			runName: providedRunName
		});
		const datasetIds = [...new Set(data.flatMap((item) => "datasetId" in item && item.datasetId ? [item.datasetId] : []))];
		const datasetId = datasetIds[0];
		const tracingEnabled = this.isOtelRegistered();
		if (!tracingEnabled) this.logger.warn("OpenTelemetry has not been set up. Traces will not be sent to Langfuse.See our docs on how to set up OpenTelemetry: https://langfuse.com/docs/observability/sdk/typescript/setup#tracing-setup");
		const projectIdPromise = tracingEnabled ? this.resolveProjectId() : Promise.resolve(void 0);
		const experimentIdsByDatasetId = /* @__PURE__ */ new Map();
		if (!providedExperimentId) {
			const projectId = datasetId ? await projectIdPromise : void 0;
			for (const id of datasetIds) experimentIdsByDatasetId.set(id, await this.createRunExperimentId({
				projectId,
				datasetId: id,
				runName
			}));
		}
		const experimentId = providedExperimentId || (datasetId ? experimentIdsByDatasetId.get(datasetId) : await createExperimentId());
		if (datasetIds.length > 1 && !providedExperimentId) this.logger.warn(`Experiment data contains items from ${datasetIds.length} datasets. Each dataset's items form a separate experiment; the result and run evaluator scores use the experiment of dataset ${datasetId}.`);
		const itemResultsByIndex = new Array(data.length);
		let nextIndex = 0;
		const runNextItem = async () => {
			while (nextIndex < data.length) {
				const index = nextIndex++;
				const item = data[index];
				try {
					const itemResult = await this.runItem({
						item,
						evaluators,
						task,
						experimentName: name,
						experimentRunName: runName,
						experimentDescription: description,
						experimentMetadata: metadata,
						experimentId: "datasetId" in item && item.datasetId && experimentIdsByDatasetId.get(item.datasetId) || experimentId,
						datasetVersion: config.datasetVersion
					});
					itemResultsByIndex[index] = itemResult;
				} catch (reason) {
					const errorMessage = reason instanceof Error ? reason.message : String(reason);
					this.logger.error(`Task failed with error: ${errorMessage}. Skipping item.`);
				}
			}
		};
		const workers = Array.from({ length: Math.min(maxConcurrency, data.length) }, runNextItem);
		await Promise.all(workers);
		const itemResults = itemResultsByIndex.filter((result) => result !== void 0);
		const datasetRunId = datasetId ? experimentId : void 0;
		const experimentUrl = await projectIdPromise ? await this.langfuseClient.getExperimentUrl(experimentId) : void 0;
		const datasetRunUrl = datasetRunId ? experimentUrl : void 0;
		let runEvaluations = [];
		if (runEvaluators && runEvaluators?.length > 0) {
			const promises = runEvaluators.map(async (runEvaluator) => {
				return runEvaluator({ itemResults }).then((result) => {
					return Array.isArray(result) ? result : [result];
				}).catch((err) => {
					this.logger.error("Run evaluator failed with error ", err);
					throw err;
				});
			});
			runEvaluations = (await Promise.allSettled(promises)).reduce((acc, settledPromise) => {
				if (settledPromise.status === "fulfilled") acc.push(...settledPromise.value);
				return acc;
			}, []);
			runEvaluations.forEach((runEval) => this.langfuseClient.score.create({
				datasetRunId: experimentId,
				...runEval
			}));
		}
		await this.langfuseClient.score.flush();
		return {
			experimentId,
			experimentUrl,
			runName,
			itemResults,
			datasetRunId,
			datasetRunUrl,
			runEvaluations,
			format: async (options) => await this.prettyPrintResults({
				experimentUrl,
				itemResults,
				originalData: data,
				runEvaluations,
				name: config.name,
				runName,
				description: config.description,
				includeItemResults: options?.includeItemResults ?? false
			})
		};
	}
	/**
	* Executes the task and evaluators for a single data item.
	*
	* This method handles the complete processing pipeline for one data item:
	* 1. Executes the task within a traced observation span
	* 2. Tags the observation with the experiment and dataset item attributes
	* 3. Runs all item-level evaluators on the output
	* 4. Stores evaluation scores in Langfuse
	* 5. Handles errors gracefully by continuing with remaining evaluators
	*
	* @param params - Parameters for item execution
	* @param params.experimentName - Name of the parent experiment
	* @param params.experimentRunName - Run name for the parent experiment
	* @param params.experimentDescription - Description of the parent experiment
	* @param params.experimentMetadata - Metadata for the parent experiment
	* @param params.item - The data item to process
	* @param params.task - The task function to execute
	* @param params.evaluators - Optional evaluators to run on the output
	*
	* @returns Promise resolving to the item result with output, evaluations, and trace info
	*
	* @throws {Error} When task execution fails (propagated from task function)
	*
	* @internal
	*/
	async runItem(params) {
		const { item, evaluators = [], task, experimentMetadata } = params;
		const { output, traceId, observationId, datasetRunId } = await startActiveObservation("experiment-item-run", async (span) => {
			const input = item.input;
			const expectedOutput = item.expectedOutput;
			const itemMetadata = item.metadata;
			const datasetId = "datasetId" in item ? item.datasetId : void 0;
			const datasetItemId = "id" in item ? item.id : void 0;
			const traceId2 = span.traceId;
			const observationId2 = span.id;
			if (input === void 0) throw new Error("Experiment item is missing input. Skipping item.");
			const datasetRunId2 = datasetId && datasetItemId ? params.experimentId : void 0;
			const experimentItemId = datasetItemId || await createExperimentItemId(input);
			const experimentId = params.experimentId;
			const rootSpanAttributes = { [LangfuseOtelSpanAttributes.ENVIRONMENT]: LANGFUSE_SDK_EXPERIMENT_ENVIRONMENT };
			if (params.experimentDescription) rootSpanAttributes[LangfuseOtelSpanAttributes.EXPERIMENT_DESCRIPTION] = params.experimentDescription;
			if (datasetItemId && params.datasetVersion) rootSpanAttributes[LangfuseOtelSpanAttributes.EXPERIMENT_ITEM_VERSION] = params.datasetVersion;
			if (expectedOutput !== void 0) {
				const serialized = serializeValue(expectedOutput);
				if (serialized) rootSpanAttributes[LangfuseOtelSpanAttributes.EXPERIMENT_ITEM_EXPECTED_OUTPUT] = serialized;
			}
			span.otelSpan.setAttributes(rootSpanAttributes);
			const output2 = await propagateAttributes({ _internalExperiment: {
				experimentId,
				experimentName: params.experimentRunName,
				experimentMetadata: serializeValue(experimentMetadata),
				experimentDatasetId: datasetId,
				experimentItemId,
				experimentItemMetadata: serializeValue(itemMetadata),
				experimentItemRootObservationId: span.id
			} }, async () => await task(item));
			const experimentRunMetadata = {
				experiment_name: params.experimentName,
				experiment_run_name: params.experimentRunName,
				...datasetId && datasetItemId ? {
					dataset_id: datasetId,
					dataset_item_id: datasetItemId
				} : {}
			};
			span.update({
				input,
				output: output2,
				metadata: {
					...experimentRunMetadata,
					...itemMetadata ?? {},
					...experimentMetadata,
					...experimentRunMetadata
				}
			});
			return {
				output: output2,
				traceId: traceId2,
				observationId: observationId2,
				datasetRunId: datasetRunId2
			};
		});
		const evalPromises = evaluators.map(async (evaluator) => {
			const params2 = {
				input: item.input,
				expectedOutput: item.expectedOutput,
				output,
				metadata: item.metadata
			};
			return evaluator(params2).then((result) => {
				return Array.isArray(result) ? result : [result];
			}).catch((err) => {
				this.logger.error(`Evaluator '${evaluator.name}' failed for params 

${JSON.stringify(params2)}

 with error: ${err}`);
				throw err;
			});
		});
		const evals = (await Promise.allSettled(evalPromises)).reduce((acc, promiseResult) => {
			if (promiseResult.status === "fulfilled") acc.push(...promiseResult.value.flat());
			return acc;
		}, []);
		for (const ev of evals) this.langfuseClient.score.create({
			traceId,
			observationId,
			...ev
		});
		return {
			output,
			evaluations: evals,
			traceId,
			datasetRunId,
			item
		};
	}
	/**
	* Formats experiment results into a human-readable string representation.
	*
	* Creates a comprehensive, nicely formatted summary of the experiment including:
	* - Individual item results with inputs, outputs, expected values, and scores
	* - Dataset item and trace links (when available)
	* - Experiment overview with aggregate statistics
	* - Average scores across all evaluations
	* - Run-level evaluation results
	* - Link to the experiment in the Langfuse UI
	*
	* @param params - Formatting parameters
	* @param params.experimentUrl - Optional URL to the experiment in the Langfuse UI
	* @param params.itemResults - Results from processing each data item
	* @param params.originalData - The original input data items
	* @param params.runEvaluations - Results from run-level evaluators
	* @param params.name - Name of the experiment
	* @param params.description - Optional description of the experiment
	* @param params.includeItemResults - Whether to include individual item details (default: false)
	*
	* @returns Promise resolving to formatted string representation
	*
	* @example Output format
	* ```
	* 1. Item 1:
	*    Input:    What is the capital of France?
	*    Expected: Paris
	*    Actual:   Paris
	*    Scores:
	*      • exact_match: 1.000
	*      • similarity: 0.95
	*        💭 Very close match with expected output
	*
	*    Dataset Item:
	*    https://cloud.langfuse.com/project/123/datasets/456/items/789
	*
	*    Trace:
	*    https://cloud.langfuse.com/project/123/traces/abc123
	*
	* ──────────────────────────────────────────────────
	* 📊 Translation Quality Test - Testing model accuracy
	* 2 items
	* Evaluations:
	*   • exact_match
	*   • similarity
	*
	* Average Scores:
	*   • exact_match: 0.850
	*   • similarity: 0.923
	*
	* Run Evaluations:
	*   • overall_quality: 0.887
	*     💭 Good performance with room for improvement
	*
	* 🔗 Experiment:
	*    https://cloud.langfuse.com/project/123/experiments/results?baseline=def456
	* ```
	*
	* @internal
	*/
	async prettyPrintResults(params) {
		const { itemResults, originalData, runEvaluations, name, runName, description, includeItemResults = false } = params;
		if (itemResults.length === 0) return "No experiment results to display.";
		let output = "";
		if (includeItemResults) for (let index = 0; index < itemResults.length; index++) {
			const result = itemResults[index];
			const originalItem = originalData[index];
			output += `
${index + 1}. Item ${index + 1}:
`;
			if (originalItem?.input !== void 0) output += `   Input:    ${this.formatValue(originalItem.input)}
`;
			const expectedOutput = originalItem?.expectedOutput ?? result.expectedOutput ?? null;
			output += `   Expected: ${expectedOutput !== null ? this.formatValue(expectedOutput) : "null"}
`;
			output += `   Actual:   ${this.formatValue(result.output)}
`;
			if (result.evaluations.length > 0) {
				output += `   Scores:
`;
				result.evaluations.forEach((evaluation) => {
					const score = typeof evaluation.value === "number" ? evaluation.value.toFixed(3) : evaluation.value;
					output += `     \u2022 ${evaluation.name}: ${score}`;
					if (evaluation.comment) output += `
       \u{1F4AD} ${evaluation.comment}`;
					output += "\n";
				});
			}
			if (originalItem && "id" in originalItem && "datasetId" in originalItem) {
				const datasetItemUrl = `${(await this.langfuseClient.getTraceUrl("mock")).split("/traces")[0]}/datasets/${originalItem.datasetId}/items/${originalItem.id}`;
				output += `
   Dataset Item:
   ${datasetItemUrl}
`;
			}
			if (result.traceId) {
				const traceUrl = await this.langfuseClient.getTraceUrl(result.traceId);
				output += `
   Trace:
   ${traceUrl}
`;
			}
		}
		else {
			output += `Individual Results: Hidden (${itemResults.length} items)
`;
			output += "💡 Call format({ includeItemResults: true }) to view them\n";
		}
		const totalItems = itemResults.length;
		const evaluationNames = new Set(itemResults.flatMap((r) => r.evaluations.map((e) => e.name)));
		output += `
${"─".repeat(50)}
`;
		output += `\u{1F9EA} Experiment: ${name}`;
		output += `
\u{1F4CB} Run name: ${runName}`;
		if (description) output += ` - ${description}`;
		output += `
${totalItems} items`;
		if (evaluationNames.size > 0) {
			output += `
Evaluations:`;
			Array.from(evaluationNames).forEach((evalName) => {
				output += `
  \u2022 ${evalName}`;
			});
			output += "\n";
		}
		if (evaluationNames.size > 0) {
			output += `
Average Scores:`;
			for (const evalName of evaluationNames) {
				const scores = itemResults.flatMap((r) => r.evaluations).filter((e) => e.name === evalName && typeof e.value === "number").map((e) => e.value);
				if (scores.length > 0) {
					const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
					output += `
  \u2022 ${evalName}: ${avg.toFixed(3)}`;
				}
			}
			output += "\n";
		}
		if (runEvaluations.length > 0) {
			output += `
Run Evaluations:`;
			runEvaluations.forEach((runEval) => {
				const score = typeof runEval.value === "number" ? runEval.value.toFixed(3) : runEval.value;
				output += `
  \u2022 ${runEval.name}: ${score}`;
				if (runEval.comment) output += `
    \u{1F4AD} ${runEval.comment}`;
			});
			output += "\n";
		}
		if (params.experimentUrl) output += `
\u{1F517} Experiment:
   ${params.experimentUrl}`;
		return output;
	}
	/**
	* Formats a value for display in pretty-printed output.
	*
	* Handles different value types appropriately:
	* - Strings: Truncates long strings to 50 characters with "..."
	* - Objects/Arrays: Converts to JSON string representation
	* - Primitives: Uses toString() representation
	*
	* @param value - The value to format
	* @returns Formatted string representation suitable for display
	*
	* @internal
	*/
	formatValue(value) {
		if (typeof value === "string") return value.length > 50 ? `${value.substring(0, 47)}...` : value;
		return JSON.stringify(value);
	}
	/**
	* Resolves the project ID for experiment IDs and URLs. Returns `undefined`
	* and logs a warning when the lookup fails, so the experiment still runs.
	*
	* @internal
	*/
	async resolveProjectId() {
		try {
			return await this.langfuseClient.getProjectId();
		} catch (err) {
			this.logger.warn("Failed to fetch the Langfuse project ID. The experiment URL is unavailable and runs on a dataset get a random experiment ID.", err);
			return;
		}
	}
	/**
	* Creates the experiment ID shared by all items of a run.
	*
	* Runs on a Langfuse dataset get an ID derived from project, dataset and run
	* name, so re-running or sharding a run with the same name continues the
	* same experiment. Runs on local data get a random ID.
	*
	* @internal
	*/
	async createRunExperimentId(params) {
		const { projectId, datasetId, runName } = params;
		if (datasetId && projectId) return await createStableExperimentId({
			projectId,
			datasetId,
			runName
		});
		return await createExperimentId();
	}
	isOtelRegistered() {
		let tracerProvider = import_src.trace.getTracerProvider();
		if (tracerProvider instanceof import_src.ProxyTracerProvider) tracerProvider = tracerProvider.getDelegate();
		return tracerProvider.constructor.name !== "NoopTracerProvider";
	}
	/**
	* Creates an experiment run name based on provided parameters.
	*
	* If runName is provided, returns it directly. Otherwise, generates
	* a name by combining the experiment name with an ISO timestamp.
	*
	* @param params - Parameters for run name creation
	* @param params.name - The experiment name
	* @param params.runName - Optional provided run name
	* @returns The final run name to use
	*
	* @internal
	*/
	createExperimentRunName(params) {
		if (params.runName) return params.runName;
		const isoTimestamp = (/* @__PURE__ */ new Date()).toISOString();
		return `${params.name} - ${isoTimestamp}`;
	}
};
async function readBody(response, onProgress) {
	if (!response.body) return new Uint8Array(await response.arrayBuffer());
	const reader = response.body.getReader();
	const chunks = [];
	let length = 0;
	for (;;) {
		const { done, value } = await reader.read();
		if (done) break;
		chunks.push(value);
		length += value.byteLength;
		onProgress();
	}
	const bytes = new Uint8Array(length);
	let offset = 0;
	for (const chunk of chunks) {
		bytes.set(chunk, offset);
		offset += chunk.byteLength;
	}
	return bytes;
}
var MediaManager = class _MediaManager {
	apiClient;
	timeoutSeconds;
	/**
	* Creates a new MediaManager instance.
	*
	* @param params - Configuration object containing the API client and the
	*   per-request timeout in seconds for media API requests
	* @internal
	*/
	constructor(params) {
		this.apiClient = params.apiClient;
		this.timeoutSeconds = params.timeoutSeconds;
	}
	/**
	* Replaces media reference strings in an object with base64 data URIs.
	*
	* This method recursively traverses an object looking for media reference strings
	* in the format "@@@langfuseMedia:...@@@". When found, it fetches the actual media
	* content from Langfuse and replaces the reference string with a base64 data URI.
	*
	* If fetching media content fails for a reference string, a warning is logged
	* and the reference string is left unchanged.
	*
	* @param params - Configuration object
	* @returns A deep copy of the input object with media references resolved
	*
	* @example
	* ```typescript
	* const obj = {
	*   image: "@@@langfuseMedia:type=image/jpeg|id=123|source=bytes@@@",
	*   nested: {
	*     pdf: "@@@langfuseMedia:type=application/pdf|id=456|source=bytes@@@"
	*   }
	* };
	*
	* const result = await langfuse.media.resolveReferences({
	*   obj,
	*   resolveWith: "base64DataUri"
	* });
	*
	* // Result:
	* // {
	* //   image: "data:image/jpeg;base64,/9j/4AAQSkZJRg...",
	* //   nested: {
	* //     pdf: "data:application/pdf;base64,JVBERi0xLjcK..."
	* //   }
	* // }
	* ```
	*/
	async resolveReferences(params) {
		const { obj, maxDepth = 10 } = params;
		const traverse = async (obj2, depth) => {
			if (depth > maxDepth) return obj2;
			if (typeof obj2 === "string") {
				const referenceStringMatches = obj2.match(/@@@langfuseMedia:.+?@@@/g);
				if (!referenceStringMatches) return obj2;
				let result = obj2;
				const referenceStringToMediaContentMap = /* @__PURE__ */ new Map();
				await Promise.all(referenceStringMatches.map(async (referenceString) => {
					try {
						const parsedMediaReference = _MediaManager.parseReferenceString(referenceString);
						const mediaData = await this.apiClient.media.get(parsedMediaReference.mediaId, {}, { timeoutInSeconds: this.timeoutSeconds });
						const controller = new AbortController();
						const timeoutSeconds = this.timeoutSeconds;
						let timer;
						const armTimer = () => {
							if (timeoutSeconds === void 0) return;
							clearTimeout(timer);
							timer = setTimeout(() => controller.abort(/* @__PURE__ */ new Error(`Media download timed out after ${timeoutSeconds}s without progress`)), timeoutSeconds * 1e3);
						};
						let uint8Content;
						try {
							armTimer();
							const mediaContent = await fetch(mediaData.url, {
								method: "GET",
								headers: {},
								signal: controller.signal
							});
							if (mediaContent.status !== 200) throw new Error("Failed to fetch media content");
							uint8Content = await readBody(mediaContent, armTimer);
						} finally {
							clearTimeout(timer);
						}
						const base64MediaContent = bytesToBase64(uint8Content);
						const base64DataUri = `data:${mediaData.contentType};base64,${base64MediaContent}`;
						referenceStringToMediaContentMap.set(referenceString, base64DataUri);
					} catch (error) {
						getGlobalLogger().warn("Error fetching media content for reference string", referenceString, error);
					}
				}));
				for (const [referenceString, base64MediaContent] of referenceStringToMediaContentMap.entries()) result = result.replaceAll(referenceString, base64MediaContent);
				return result;
			}
			if (Array.isArray(obj2)) return Promise.all(obj2.map(async (item) => await traverse(item, depth + 1)));
			if (typeof obj2 === "object" && obj2 !== null) return Object.fromEntries(await Promise.all(Object.entries(obj2).map(async ([key, value]) => [key, await traverse(value, depth + 1)])));
			return obj2;
		};
		return traverse(obj, 0);
	}
	/**
	* Parses a media reference string into a ParsedMediaReference.
	*
	* Example reference string:
	*     "@@@langfuseMedia:type=image/jpeg|id=some-uuid|source=base64DataUri@@@"
	*
	* @param referenceString - The reference string to parse.
	* @returns An object with the mediaId, source, and contentType.
	*
	* @throws Error if the reference string is invalid or missing required fields.
	*/
	static parseReferenceString(referenceString) {
		const prefix = "@@@langfuseMedia:";
		const suffix = "@@@";
		if (!referenceString.startsWith(prefix)) throw new Error("Reference string does not start with '@@@langfuseMedia:type='");
		if (!referenceString.endsWith(suffix)) throw new Error("Reference string does not end with '@@@'");
		const pairs = referenceString.slice(17, -3).split("|");
		const parsedData = {};
		for (const pair of pairs) {
			const [key, value] = pair.split("=", 2);
			parsedData[key] = value;
		}
		if (!("type" in parsedData && "id" in parsedData && "source" in parsedData)) throw new Error("Missing required fields in reference string");
		return {
			mediaId: parsedData["id"],
			source: parsedData["source"],
			contentType: parsedData["type"]
		};
	}
};
var DEFAULT_PROMPT_CACHE_TTL_SECONDS = 60;
var LangfusePromptCacheItem = class {
	constructor(value, ttlSeconds) {
		this.value = value;
		this._expiry = Date.now() + ttlSeconds * 1e3;
	}
	value;
	_expiry;
	get isExpired() {
		return Date.now() > this._expiry;
	}
};
var LangfusePromptCache = class {
	_cache;
	_defaultTtlSeconds;
	_refreshingKeys;
	constructor() {
		this._cache = /* @__PURE__ */ new Map();
		this._defaultTtlSeconds = DEFAULT_PROMPT_CACHE_TTL_SECONDS;
		this._refreshingKeys = /* @__PURE__ */ new Map();
	}
	getIncludingExpired(key) {
		return this._cache.get(key) ?? null;
	}
	createKey(params) {
		const { name, version, label } = params;
		const parts = [name];
		if (version !== void 0) parts.push("version:" + version.toString());
		else if (label !== void 0) parts.push("label:" + label);
		else parts.push("label:production");
		return parts.join("-");
	}
	set(key, value, ttlSeconds) {
		const effectiveTtlSeconds = ttlSeconds ?? this._defaultTtlSeconds;
		this._cache.set(key, new LangfusePromptCacheItem(value, effectiveTtlSeconds));
	}
	addRefreshingPromise(key, promise) {
		this._refreshingKeys.set(key, promise);
		promise.then(() => {
			this._refreshingKeys.delete(key);
		}).catch(() => {
			this._refreshingKeys.delete(key);
		});
	}
	isRefreshing(key) {
		return this._refreshingKeys.has(key);
	}
	invalidate(promptName) {
		getGlobalLogger().debug("Invalidating cache keys for", promptName, this._cache.keys());
		for (const key of this._cache.keys()) if (key.startsWith(promptName)) this._cache.delete(key);
	}
};
mustache.escape = function(text) {
	return text;
};
var BasePromptClient = class {
	/** The name of the prompt */
	name;
	/** The version number of the prompt */
	version;
	/** Configuration object associated with the prompt */
	config;
	/** Labels associated with the prompt */
	labels;
	/** Tags associated with the prompt */
	tags;
	/** Whether this prompt client is using fallback content */
	isFallback;
	/** The type of prompt ("text" or "chat") */
	type;
	/** Optional commit message for the prompt version */
	commitMessage;
	/**
	* Creates a new BasePromptClient instance.
	*
	* @param prompt - The base prompt data
	* @param isFallback - Whether this is fallback content
	* @param type - The prompt type
	* @internal
	*/
	constructor(prompt, isFallback = false, type) {
		this.name = prompt.name;
		this.version = prompt.version;
		this.config = prompt.config;
		this.labels = prompt.labels;
		this.tags = prompt.tags;
		this.isFallback = isFallback;
		this.type = type;
		this.commitMessage = prompt.commitMessage;
	}
	_transformToLangchainVariables(content) {
		return this.escapeJsonForLangchain(content).replace(/\{\{(\w+)\}\}/g, "{$1}");
	}
	/**
	* Escapes every curly brace that is part of a JSON object by doubling it.
	*
	* A curly brace is considered “JSON-related” when, after skipping any immediate
	* whitespace, the next non-whitespace character is a single (') or double (") quote.
	*
	* Braces that are already doubled (e.g. `{{variable}}` placeholders) are left untouched.
	*
	* @param text - Input string that may contain JSON snippets.
	* @returns The string with JSON-related braces doubled.
	*/
	escapeJsonForLangchain(text) {
		const out = [];
		const stack = [];
		let i = 0;
		const n = text.length;
		while (i < n) {
			const ch = text[i];
			if (ch === "{") {
				if (i + 1 < n && text[i + 1] === "{") {
					out.push("{{");
					i += 2;
					continue;
				}
				let j = i + 1;
				while (j < n && /\s/.test(text[j])) j++;
				const isJson = j < n && (text[j] === "'" || text[j] === "\"");
				out.push(isJson ? "{{" : "{");
				stack.push(isJson);
				i += 1;
				continue;
			}
			if (ch === "}") {
				if (i + 1 < n && text[i + 1] === "}") {
					out.push("}}");
					i += 2;
					continue;
				}
				const isJson = stack.pop() ?? false;
				out.push(isJson ? "}}" : "}");
				i += 1;
				continue;
			}
			out.push(ch);
			i += 1;
		}
		return out.join("");
	}
};
var TextPromptClient = class extends BasePromptClient {
	/** The original prompt response from the API */
	promptResponse;
	/** The text content of the prompt */
	prompt;
	/**
	* Creates a new TextPromptClient instance.
	*
	* @param prompt - The text prompt data
	* @param isFallback - Whether this is fallback content
	*/
	constructor(prompt, isFallback = false) {
		super(prompt, isFallback, "text");
		this.promptResponse = prompt;
		this.prompt = prompt.prompt;
	}
	/**
	* Compiles the text prompt by substituting variables.
	*
	* Uses Mustache templating to replace {{variable}} placeholders with provided values.
	*
	* @param variables - Key-value pairs for variable substitution
	* @param _placeholders - Ignored for text prompts
	* @returns The compiled text with variables substituted
	*
	* @example
	* ```typescript
	* const prompt = await langfuse.prompt.get("greeting", { type: "text" });
	* const compiled = prompt.compile({ name: "Alice" });
	* // If prompt is "Hello {{name}}!", result is "Hello Alice!"
	* ```
	*/
	compile(variables, _placeholders) {
		return mustache.render(this.promptResponse.prompt, variables ?? {});
	}
	/**
	* Converts the prompt to LangChain PromptTemplate format.
	*
	* Transforms Mustache-style {{variable}} syntax to LangChain's {variable} format.
	*
	* @param _options - Ignored for text prompts
	* @returns The prompt string compatible with LangChain PromptTemplate
	*
	* @example
	* ```typescript
	* const prompt = await langfuse.prompt.get("greeting", { type: "text" });
	* const langchainFormat = prompt.getLangchainPrompt();
	* // Transforms "Hello {{name}}!" to "Hello {name}!"
	* ```
	*/
	getLangchainPrompt(_options) {
		return this._transformToLangchainVariables(this.prompt);
	}
	toJSON() {
		return JSON.stringify({
			name: this.name,
			prompt: this.prompt,
			version: this.version,
			isFallback: this.isFallback,
			tags: this.tags,
			labels: this.labels,
			type: this.type,
			config: this.config
		});
	}
};
var ChatPromptClient = class _ChatPromptClient extends BasePromptClient {
	/** The original prompt response from the API */
	promptResponse;
	/** The chat messages that make up the prompt */
	prompt;
	/**
	* Creates a new ChatPromptClient instance.
	*
	* @param prompt - The chat prompt data
	* @param isFallback - Whether this is fallback content
	*/
	constructor(prompt, isFallback = false) {
		const normalizedPrompt = _ChatPromptClient.normalizePrompt(prompt.prompt);
		const typedPrompt = {
			...prompt,
			prompt: normalizedPrompt
		};
		super(typedPrompt, isFallback, "chat");
		this.promptResponse = typedPrompt;
		this.prompt = normalizedPrompt;
	}
	static normalizePrompt(prompt) {
		return prompt.map((item) => {
			if ("type" in item) return item;
			else return {
				type: "chatmessage",
				...item
			};
		});
	}
	/**
	* Compiles the chat prompt by replacing placeholders and variables.
	*
	* First resolves placeholders with provided values, then applies variable substitution
	* to message content using Mustache templating. Unresolved placeholders remain
	* as placeholder objects in the output.
	*
	* @param variables - Key-value pairs for Mustache variable substitution in message content
	* @param placeholders - Key-value pairs where keys are placeholder names and values are ChatMessage arrays
	* @returns Array of ChatMessage objects and unresolved placeholder objects
	*
	* @example
	* ```typescript
	* const prompt = await langfuse.prompt.get("conversation", { type: "chat" });
	* const compiled = prompt.compile(
	*   { user_name: "Alice" },
	*   { examples: [{ role: "user", content: "Hello" }, { role: "assistant", content: "Hi!" }] }
	* );
	* ```
	*/
	compile(variables, placeholders) {
		const messagesWithPlaceholdersReplaced = [];
		const placeholderValues = placeholders ?? {};
		for (const item of this.prompt) if ("type" in item && item.type === "placeholder") {
			const placeholderValue = placeholderValues[item.name];
			if (Array.isArray(placeholderValue) && placeholderValue.length > 0 && placeholderValue.every((msg) => typeof msg === "object" && "role" in msg && "content" in msg)) messagesWithPlaceholdersReplaced.push(...placeholderValue);
			else if (Array.isArray(placeholderValue) && placeholderValue.length === 0) {} else if (placeholderValue !== void 0) messagesWithPlaceholdersReplaced.push(JSON.stringify(placeholderValue));
			else messagesWithPlaceholdersReplaced.push(item);
		} else if ("role" in item && "content" in item && item.type === "chatmessage") messagesWithPlaceholdersReplaced.push({
			role: item.role,
			content: item.content
		});
		return messagesWithPlaceholdersReplaced.map((item) => {
			if (typeof item === "object" && item !== null && "role" in item && "content" in item && typeof item.content === "string") return {
				...item,
				content: mustache.render(item.content, variables ?? {})
			};
			else return item;
		});
	}
	/**
	* Converts the prompt to LangChain ChatPromptTemplate format.
	*
	* Resolves placeholders with provided values and converts unresolved ones
	* to LangChain MessagesPlaceholder objects. Transforms variables from
	* {{var}} to {var} format without rendering them.
	*
	* @param options - Configuration object
	* @param options.placeholders - Key-value pairs for placeholder resolution
	* @returns Array of ChatMessage objects and LangChain MessagesPlaceholder objects
	*
	* @example
	* ```typescript
	* const prompt = await langfuse.prompt.get("conversation", { type: "chat" });
	* const langchainFormat = prompt.getLangchainPrompt({
	*   placeholders: { examples: [{ role: "user", content: "Hello" }] }
	* });
	* ```
	*/
	getLangchainPrompt(options) {
		const messagesWithPlaceholdersReplaced = [];
		const placeholderValues = options?.placeholders ?? {};
		for (const item of this.prompt) if ("type" in item && item.type === "placeholder") {
			const placeholderValue = placeholderValues[item.name];
			if (Array.isArray(placeholderValue) && placeholderValue.length > 0 && placeholderValue.every((msg) => typeof msg === "object" && "role" in msg && "content" in msg)) messagesWithPlaceholdersReplaced.push(...placeholderValue.map((msg) => {
				return {
					role: msg.role,
					content: this._transformToLangchainVariables(msg.content)
				};
			}));
			else if (Array.isArray(placeholderValue) && placeholderValue.length === 0) {} else if (placeholderValue !== void 0) messagesWithPlaceholdersReplaced.push(JSON.stringify(placeholderValue));
			else messagesWithPlaceholdersReplaced.push(["placeholder", `{${item.name}}`]);
		} else if ("role" in item && "content" in item && item.type === "chatmessage") messagesWithPlaceholdersReplaced.push({
			role: item.role,
			content: this._transformToLangchainVariables(item.content)
		});
		return messagesWithPlaceholdersReplaced;
	}
	toJSON() {
		return JSON.stringify({
			name: this.name,
			prompt: this.promptResponse.prompt.map((item) => {
				if ("type" in item && item.type === "chatmessage") {
					const { type: _, ...messageWithoutType } = item;
					return messageWithoutType;
				}
				return item;
			}),
			version: this.version,
			isFallback: this.isFallback,
			tags: this.tags,
			labels: this.labels,
			type: this.type,
			config: this.config
		});
	}
};
var PromptManager = class {
	cache;
	apiClient;
	timeoutSeconds;
	/**
	* Creates a new PromptManager instance.
	*
	* @param params - Configuration object containing the API client and the
	*   default per-request timeout in seconds for prompt API requests
	* @internal
	*/
	constructor(params) {
		const { apiClient, timeoutSeconds } = params;
		this.apiClient = apiClient;
		this.timeoutSeconds = timeoutSeconds;
		this.cache = new LangfusePromptCache();
	}
	get logger() {
		return getGlobalLogger();
	}
	/**
	* Creates a new prompt in Langfuse.
	*
	* Supports both text and chat prompts. Chat prompts can include placeholders
	* for dynamic content insertion.
	*
	* @param body - The prompt data to create
	* @returns Promise that resolves to the appropriate prompt client
	*
	* @example
	* ```typescript
	* // Create a text prompt
	* const textPrompt = await langfuse.prompt.create({
	*   name: "greeting",
	*   prompt: "Hello {{name}}!",
	*   type: "text"
	* });
	*
	* // Create a chat prompt
	* const chatPrompt = await langfuse.prompt.create({
	*   name: "conversation",
	*   type: "chat",
	*   prompt: [
	*     { role: "system", content: "You are a helpful assistant." },
	*     { role: "user", content: "{{user_message}}" }
	*   ]
	* });
	* ```
	*/
	async create(body) {
		const requestBody = body.type === "chat" ? {
			...body,
			prompt: body.prompt.map((item) => {
				if ("type" in item && item.type === "placeholder") return {
					type: "placeholder",
					name: item.name
				};
				else return {
					...item,
					type: "chatmessage"
				};
			})
		} : {
			...body,
			type: body.type ?? "text"
		};
		const promptResponse = await this.apiClient.prompts.create(requestBody, { timeoutInSeconds: this.timeoutSeconds });
		if (promptResponse.type === "chat") return new ChatPromptClient(promptResponse);
		return new TextPromptClient(promptResponse);
	}
	/**
	* Updates the labels of an existing prompt version.
	*
	* @param params - Update parameters
	* @param params.name - Name of the prompt to update
	* @param params.version - Version number of the prompt to update
	* @param params.newLabels - New labels to apply to the prompt version
	*
	* @returns Promise that resolves to the updated prompt
	*
	* @example
	* ```typescript
	* const updatedPrompt = await langfuse.prompt.update({
	*   name: "my-prompt",
	*   version: 1,
	*   newLabels: ["production", "v2"]
	* });
	* ```
	*/
	async update(params) {
		const { name, version, newLabels } = params;
		const newPrompt = await this.apiClient.promptVersion.update(name, version, { newLabels }, { timeoutInSeconds: this.timeoutSeconds });
		this.cache.invalidate(name);
		return newPrompt;
	}
	/**
	* Delete prompt versions. If neither version nor label is specified, all versions of the prompt are deleted.
	*
	* The Langfuse SDK prompt cache is invalidated for all cached versions with the specified name.
	*
	* @param name - Name of the prompt to delete
	* @param options - Optional deletion configuration
	* @param options.version - Optional version to delete. If specified, deletes only this specific version
	* @param options.label - Optional label to filter deletion. If specified, deletes all prompt versions with this label
	*
	* @returns Promise that resolves when deletion is complete
	*
	* @throws {LangfuseAPI.NotFoundError} If the prompt does not exist
	* @throws {LangfuseAPI.Error} If the API request fails
	*
	* @example
	* ```typescript
	* // Delete all versions of a prompt
	* await langfuse.prompt.delete("my-prompt");
	*
	* // Delete specific version
	* await langfuse.prompt.delete("my-prompt", { version: 2 });
	*
	* // Delete all versions with a specific label
	* await langfuse.prompt.delete("my-prompt", { label: "staging" });
	* ```
	*/
	async delete(name, options) {
		await this.apiClient.prompts.delete(name, {
			version: options?.version,
			label: options?.label
		}, { timeoutInSeconds: this.timeoutSeconds });
		this.cache.invalidate(name);
	}
	/**
	* Retrieves a prompt by name with intelligent caching.
	*
	* This method implements sophisticated caching behavior:
	* - Fresh prompts are returned immediately from cache
	* - Expired prompts are returned from cache while being refreshed in background
	* - Cache misses trigger immediate fetch with optional fallback support
	*
	* @param name - Name of the prompt to retrieve
	* @param options - Optional retrieval configuration
	* @returns Promise that resolves to the appropriate prompt client
	*
	* @example
	* ```typescript
	* // Get latest version with caching
	* const prompt = await langfuse.prompt.get("my-prompt");
	*
	* // Get specific version
	* const v2Prompt = await langfuse.prompt.get("my-prompt", {
	*   version: 2
	* });
	*
	* // Get with label filter
	* const prodPrompt = await langfuse.prompt.get("my-prompt", {
	*   label: "production"
	* });
	*
	* // Get with fallback
	* const promptWithFallback = await langfuse.prompt.get("my-prompt", {
	*   type: "text",
	*   fallback: "Hello {{name}}!"
	* });
	* ```
	*/
	async get(name, options) {
		const cacheKey = this.cache.createKey({
			name,
			label: options?.label,
			version: options?.version
		});
		const cachedPrompt = this.cache.getIncludingExpired(cacheKey);
		if (!cachedPrompt || options?.cacheTtlSeconds === 0) try {
			return await this.fetchPromptAndUpdateCache({
				name,
				version: options?.version,
				label: options?.label,
				cacheTtlSeconds: options?.cacheTtlSeconds,
				maxRetries: options?.maxRetries,
				fetchTimeoutMs: options?.fetchTimeoutMs
			});
		} catch (err) {
			if (options?.fallback) {
				const sharedFallbackParams = {
					name,
					version: options?.version ?? 0,
					labels: options.label ? [options.label] : [],
					cacheTtlSeconds: options?.cacheTtlSeconds,
					config: {},
					tags: []
				};
				if (options.type === "chat") return new ChatPromptClient({
					...sharedFallbackParams,
					type: "chat",
					prompt: options.fallback.map((msg) => ({
						...msg,
						type: "chatmessage"
					}))
				}, true);
				else return new TextPromptClient({
					...sharedFallbackParams,
					type: "text",
					prompt: options.fallback
				}, true);
			}
			throw err;
		}
		if (cachedPrompt.isExpired) {
			if (!this.cache.isRefreshing(cacheKey)) {
				const refreshPromptPromise = this.fetchPromptAndUpdateCache({
					name,
					version: options?.version,
					label: options?.label,
					cacheTtlSeconds: options?.cacheTtlSeconds,
					maxRetries: options?.maxRetries,
					fetchTimeoutMs: options?.fetchTimeoutMs
				}).catch(() => {
					this.logger.warn(`Failed to refresh prompt cache '${cacheKey}', stale cache will be used until next refresh succeeds.`);
				});
				this.cache.addRefreshingPromise(cacheKey, refreshPromptPromise);
			}
			return cachedPrompt.value;
		}
		return cachedPrompt.value;
	}
	async fetchPromptAndUpdateCache(params) {
		const cacheKey = this.cache.createKey(params);
		try {
			const { name, version, cacheTtlSeconds, label, maxRetries, fetchTimeoutMs } = params;
			const data = await this.apiClient.prompts.get(name, {
				version,
				label
			}, {
				maxRetries,
				timeoutInSeconds: fetchTimeoutMs ? fetchTimeoutMs / 1e3 : this.timeoutSeconds
			});
			let prompt;
			if (data.type === "chat") prompt = new ChatPromptClient(data);
			else prompt = new TextPromptClient(data);
			this.cache.set(cacheKey, prompt, cacheTtlSeconds);
			return prompt;
		} catch (error) {
			this.logger.error(`Error fetching prompt '${cacheKey}':`, error);
			throw error;
		}
	}
};
var MAX_QUEUE_SIZE = 1e5;
var MAX_BATCH_SIZE = 100;
var MAX_BATCH_ATTEMPTS_ON_TIMEOUT = 2;
function isPartialBatchResult(response) {
	return typeof response === "object" && response !== null && "rejected" in response && "errors" in response;
}
function getScoreValidationError(data) {
	if (typeof data !== "object" || data === null) return "score data must be an object";
	const { name, value } = data;
	if (typeof name !== "string" || name.length === 0) return "'name' must be a non-empty string";
	if (!(typeof value === "string" || typeof value === "number" && Number.isFinite(value))) return `'value' of score '${name}' must be a finite number or a string`;
}
var ScoreManager = class {
	apiClient;
	scoreQueue = [];
	flushPromise = null;
	flushTimer = null;
	flushAtCount;
	flushIntervalSeconds;
	timeoutSeconds;
	/**
	* Creates a new ScoreManager instance.
	*
	* @param params - Configuration object containing the API client and the
	*   per-request timeout in seconds for score requests
	* @internal
	*/
	constructor(params) {
		this.apiClient = params.apiClient;
		this.timeoutSeconds = params.timeoutSeconds;
		const envFlushAtCount = getEnv("LANGFUSE_FLUSH_AT");
		const envFlushIntervalSeconds = getEnv("LANGFUSE_FLUSH_INTERVAL");
		this.flushAtCount = envFlushAtCount ? Number(envFlushAtCount) : 10;
		this.flushIntervalSeconds = envFlushIntervalSeconds ? Number(envFlushIntervalSeconds) : 1;
	}
	get logger() {
		return getGlobalLogger();
	}
	/**
	* Creates a new score and adds it to the processing queue.
	*
	* Scores are queued and sent in batches for efficiency. The score will be
	* automatically sent when the queue reaches the flush threshold or after
	* the flush interval expires.
	*
	* This method never throws. Invalid scores (missing or empty `name`, or a
	* `value` that is neither a finite number nor a string) are logged at error
	* level and dropped. Unexpected errors are logged as well.
	*
	* @param data - The score data to create
	*
	* @example
	* ```typescript
	* langfuse.score.create({
	*   name: "quality",
	*   value: 0.85,
	*   traceId: "trace-123",
	*   comment: "High quality response"
	* });
	* ```
	*/
	create(data) {
		try {
			this.enqueue(data);
		} catch (err) {
			this.logger.error("Failed to create score. Dropping score.", err);
		}
	}
	enqueue(data) {
		const validationError = getScoreValidationError(data);
		if (validationError) {
			this.logger.error(`Invalid score: ${validationError}. Dropping score.`);
			return;
		}
		const score = {
			...data,
			id: data.id ?? generateUUID(),
			environment: data.environment ?? getEnv("LANGFUSE_TRACING_ENVIRONMENT"),
			timestamp: data.timestamp ?? (/* @__PURE__ */ new Date()).toISOString()
		};
		if (this.scoreQueue.length >= MAX_QUEUE_SIZE) {
			this.logger.error(`Score queue is at max size ${MAX_QUEUE_SIZE}. Dropping score.`);
			return;
		}
		if (this.logger.isLevelEnabled(LogLevel.DEBUG)) this.logger.debug("Adding score to queue:\n", JSON.stringify(score, null, 2));
		this.scoreQueue.push(score);
		if (this.scoreQueue.length >= this.flushAtCount) this.flushPromise = this.flush();
		else if (!this.flushTimer) this.flushTimer = safeSetTimeout(() => {
			this.flushPromise = this.flush();
		}, this.flushIntervalSeconds * 1e3);
	}
	/**
	* Creates a score for a specific observation using its OpenTelemetry span.
	*
	* This method automatically extracts the trace ID and observation ID from
	* the provided span context.
	*
	* @param observation - Object containing the OpenTelemetry span
	* @param data - Score data (traceId and observationId will be auto-populated)
	*
	* @example
	* ```typescript
	* import { startSpan } from '@langfuse/tracing';
	*
	* const span = startSpan({ name: "my-operation" });
	* langfuse.score.observation(
	*   { otelSpan: span },
	*   { name: "accuracy", value: 0.92 }
	* );
	* ```
	*/
	observation(observation, data) {
		try {
			const { spanId, traceId } = observation.otelSpan.spanContext();
			this.create({
				...data,
				traceId,
				observationId: spanId
			});
		} catch (err) {
			this.logger.error("Failed to score observation. Dropping score.", err);
		}
	}
	/**
	* Creates a score for a trace using an OpenTelemetry span.
	*
	* This method automatically extracts the trace ID from the provided
	* span context and creates a trace-level score.
	*
	* @param observation - Object containing the OpenTelemetry span
	* @param data - Score data (traceId will be auto-populated)
	*
	* @example
	* ```typescript
	* import { startSpan } from '@langfuse/tracing';
	*
	* const span = startSpan({ name: "my-operation" });
	* langfuse.score.trace(
	*   { otelSpan: span },
	*   { name: "overall_quality", value: 0.88 }
	* );
	* ```
	*/
	trace(observation, data) {
		try {
			const { traceId } = observation.otelSpan.spanContext();
			this.create({
				...data,
				traceId
			});
		} catch (err) {
			this.logger.error("Failed to score trace. Dropping score.", err);
		}
	}
	/**
	* Creates a score for the currently active observation.
	*
	* This method automatically detects the active OpenTelemetry span and
	* creates an observation-level score. If no active span is found,
	* a warning is logged and the operation is skipped.
	*
	* @param data - Score data (traceId and observationId will be auto-populated)
	*
	* @example
	* ```typescript
	* import { startActiveSpan } from '@langfuse/tracing';
	*
	* startActiveSpan({ name: "my-operation" }, (span) => {
	*   // Inside the active span
	*   langfuse.score.activeObservation({
	*     name: "relevance",
	*     value: 0.95
	*   });
	* });
	* ```
	*/
	activeObservation(data) {
		try {
			const currentOtelSpan = import_src.trace.getActiveSpan();
			if (!currentOtelSpan) {
				this.logger.warn("No active span in context to score.");
				return;
			}
			const { spanId, traceId } = currentOtelSpan.spanContext();
			this.create({
				...data,
				traceId,
				observationId: spanId
			});
		} catch (err) {
			this.logger.error("Failed to score active observation. Dropping score.", err);
		}
	}
	/**
	* Creates a score for the currently active trace.
	*
	* This method automatically detects the active OpenTelemetry span and
	* creates a trace-level score. If no active span is found,
	* a warning is logged and the operation is skipped.
	*
	* @param data - Score data (traceId will be auto-populated)
	*
	* @example
	* ```typescript
	* import { startActiveSpan } from '@langfuse/tracing';
	*
	* startActiveSpan({ name: "my-operation" }, (span) => {
	*   // Inside the active span
	*   langfuse.score.activeTrace({
	*     name: "user_satisfaction",
	*     value: 4,
	*     comment: "User rated 4 out of 5 stars"
	*   });
	* });
	* ```
	*/
	activeTrace(data) {
		try {
			const currentOtelSpan = import_src.trace.getActiveSpan();
			if (!currentOtelSpan) {
				this.logger.warn("No active span in context to score trace.");
				return;
			}
			const { traceId } = currentOtelSpan.spanContext();
			this.create({
				...data,
				traceId
			});
		} catch (err) {
			this.logger.error("Failed to score active trace. Dropping score.", err);
		}
	}
	/**
	* Sends one batch to `POST /api/public/scores`. The API client does not
	* retry requests that time out, so a timed-out batch is sent once more
	* before its scores are dropped. A partially accepted batch (HTTP 207) is
	* not retried: the rejected scores failed validation and would fail again.
	*/
	async sendBatch(batch) {
		for (let attempt = 1;; attempt++) try {
			const res = await this.apiClient.scores.create(batch, { timeoutInSeconds: this.timeoutSeconds });
			if (isPartialBatchResult(res) && res.rejected > 0) this.logger.error(`Langfuse rejected ${res.rejected} of ${batch.length} scores in batch:`, res.errors);
			return;
		} catch (err) {
			if (err instanceof LangfuseAPITimeoutError && attempt < MAX_BATCH_ATTEMPTS_ON_TIMEOUT) {
				this.logger.warn("Score batch request timed out. Retrying once.");
				continue;
			}
			this.logger.error("Failed to export score batch:", err);
			return;
		}
	}
	async handleFlush() {
		try {
			if (this.flushTimer) {
				clearTimeout(this.flushTimer);
				this.flushTimer = null;
			}
			const promises = [];
			while (this.scoreQueue.length > 0) {
				const batch = this.scoreQueue.splice(0, MAX_BATCH_SIZE);
				promises.push(this.sendBatch(batch));
			}
			await Promise.all(promises);
		} catch (err) {
			this.logger.error("Error flushing Score Manager: ", err);
		} finally {
			this.flushPromise = null;
		}
	}
	/**
	* Flushes all pending scores to the Langfuse API.
	*
	* This method ensures all queued scores are sent immediately rather than
	* waiting for the automatic flush interval or batch size threshold.
	*
	* @returns Promise that resolves when all pending scores have been sent
	*
	* @example
	* ```typescript
	* langfuse.score.create({ name: "quality", value: 0.8 });
	* await langfuse.score.flush(); // Ensures the score is sent immediately
	* ```
	*/
	async flush() {
		return this.flushPromise ?? this.handleFlush();
	}
	/**
	* Gracefully shuts down the score manager by flushing all pending scores.
	*
	* This method should be called before your application exits to ensure
	* all score data is sent to Langfuse.
	*
	* @returns Promise that resolves when shutdown is complete
	*
	* @example
	* ```typescript
	* // Before application exit
	* await langfuse.score.shutdown();
	* ```
	*/
	async shutdown() {
		await this.flush();
	}
};
var LangfuseClient = class {
	/**
	* Direct access to the underlying Langfuse API client.
	* Use this for advanced API operations not covered by the high-level managers.
	*/
	api;
	/**
	* Manager for prompt operations including creation, retrieval, and caching.
	*/
	prompt;
	/**
	* Manager for dataset operations including retrieval and item linking.
	*/
	dataset;
	/**
	* Manager for score creation and batch processing.
	*/
	score;
	/**
	* Manager for media upload and reference resolution.
	*/
	media;
	/**
	* Manager for running experiments on datasets and data items.
	*
	* The experiment manager provides comprehensive functionality for:
	* - Running tasks on datasets or custom data arrays
	* - Evaluating outputs with custom or pre-built evaluators
	* - Tracking experiment runs with automatic tracing
	* - Generating formatted result summaries
	* - Integrating with AutoEvals library evaluators
	*
	* @example Basic experiment execution
	* ```typescript
	* const langfuse = new LangfuseClient();
	*
	* const result = await langfuse.experiment.run({
	*   name: "Model Evaluation",
	*   description: "Testing model performance on Q&A tasks",
	*   data: [
	*     { input: "What is 2+2?", expectedOutput: "4" },
	*     { input: "What is the capital of France?", expectedOutput: "Paris" }
	*   ],
	*   task: async ({ input }) => {
	*     // Your model/task implementation
	*     const response = await myModel.generate(input);
	*     return response;
	*   },
	*   evaluators: [
	*     async ({ output, expectedOutput }) => ({
	*       name: "exact_match",
	*       value: output.trim().toLowerCase() === expectedOutput.toLowerCase() ? 1 : 0
	*     })
	*   ]
	* });
	*
	* console.log(await result.format());
	* ```
	*
	* @example Using with datasets
	* ```typescript
	* const dataset = await langfuse.dataset.get("my-test-dataset");
	* const result = await dataset.runExperiment({
	*   name: "Production Readiness Test",
	*   task: myTask,
	*   evaluators: [accuracyEvaluator, latencyEvaluator],
	*   runEvaluators: [overallQualityEvaluator]
	* });
	* ```
	*
	* @see {@link ExperimentManager} for detailed API documentation
	* @see {@link ExperimentParams} for configuration options
	* @see {@link ExperimentResult} for result structure
	* @public
	* @since 4.0.0
	*/
	experiment;
	baseUrl;
	projectId = null;
	/**
	* Creates a new LangfuseClient instance.
	*
	* @param params - Configuration parameters. If not provided, will use environment variables.
	*
	* @throws Will log warnings if required credentials are not provided
	*
	* @example
	* ```typescript
	* // With explicit configuration
	* const client = new LangfuseClient({
	*   publicKey: "pk_...",
	*   secretKey: "sk_...",
	*   baseUrl: "https://your-instance.langfuse.com"
	* });
	*
	* // Using environment variables
	* const client = new LangfuseClient();
	* ```
	*/
	constructor(params) {
		const logger = getGlobalLogger();
		const publicKey = params?.publicKey ?? getEnv("LANGFUSE_PUBLIC_KEY");
		const secretKey = params?.secretKey ?? getEnv("LANGFUSE_SECRET_KEY");
		this.baseUrl = params?.baseUrl ?? getEnv("LANGFUSE_BASE_URL") ?? getEnv("LANGFUSE_BASEURL") ?? "https://cloud.langfuse.com";
		if (!publicKey) logger.warn("No public key provided in constructor or as LANGFUSE_PUBLIC_KEY env var. Client operations will fail.");
		if (!secretKey) logger.warn("No secret key provided in constructor or as LANGFUSE_SECRET_KEY env var. Client operations will fail.");
		const configuredTimeoutSeconds = params?.timeout ?? Number(getEnv("LANGFUSE_TIMEOUT") ?? 5);
		const timeoutSeconds = Number.isFinite(configuredTimeoutSeconds) && configuredTimeoutSeconds > 0 ? configuredTimeoutSeconds : 5;
		if (timeoutSeconds !== configuredTimeoutSeconds) logger.warn(`Invalid timeout '${configuredTimeoutSeconds}'. Falling back to ${timeoutSeconds} seconds.`);
		this.api = new LangfuseAPIClient({
			baseUrl: this.baseUrl,
			username: publicKey,
			password: secretKey,
			xLangfusePublicKey: publicKey,
			xLangfuseSdkVersion: LANGFUSE_SDK_VERSION,
			xLangfuseSdkName: "javascript",
			environment: "",
			headers: params?.additionalHeaders
		});
		logger.debug("Initialized LangfuseClient with params:", {
			publicKey,
			baseUrl: this.baseUrl,
			timeoutSeconds
		});
		this.prompt = new PromptManager({
			apiClient: this.api,
			timeoutSeconds
		});
		this.dataset = new DatasetManager({ langfuseClient: this });
		this.score = new ScoreManager({
			apiClient: this.api,
			timeoutSeconds
		});
		this.media = new MediaManager({
			apiClient: this.api,
			timeoutSeconds
		});
		this.experiment = new ExperimentManager({ langfuseClient: this });
	}
	/**
	* Flushes any pending score events to the Langfuse API.
	*
	* This method ensures all queued scores are sent immediately rather than
	* waiting for the automatic flush interval or batch size threshold.
	*
	* @returns Promise that resolves when all pending scores have been sent
	*
	* @example
	* ```typescript
	* langfuse.score.create({ name: "quality", value: 0.8 });
	* await langfuse.flush(); // Ensures the score is sent immediately
	* ```
	*/
	async flush() {
		return this.score.flush();
	}
	/**
	* Gracefully shuts down the client by flushing all pending data.
	*
	* This method should be called before your application exits to ensure
	* all data is sent to Langfuse.
	*
	* @returns Promise that resolves when shutdown is complete
	*
	* @example
	* ```typescript
	* // Before application exit
	* await langfuse.shutdown();
	* ```
	*/
	async shutdown() {
		return this.score.shutdown();
	}
	/**
	* Generates a URL to view a specific trace in the Langfuse UI.
	*
	* @param traceId - The ID of the trace to generate a URL for
	* @returns Promise that resolves to the trace URL
	*
	* @example
	* ```typescript
	* const traceId = "trace-123";
	* const url = await langfuse.getTraceUrl(traceId);
	* console.log(`View trace at: ${url}`);
	* ```
	*/
	async getTraceUrl(traceId) {
		const projectId = await this.getProjectId();
		return `${this.baseUrl}/project/${projectId}/traces/${traceId}`;
	}
	/**
	* Generates a URL to view an experiment in the Langfuse UI.
	*
	* @param experimentId - The ID of the experiment, e.g. `ExperimentResult.experimentId`
	* @returns Promise that resolves to the experiment results URL
	*/
	async getExperimentUrl(experimentId) {
		const projectId = await this.getProjectId();
		return `${this.baseUrl}/project/${projectId}/experiments/results?baseline=${encodeURIComponent(experimentId)}`;
	}
	/**
	* Returns the ID of the project the API keys belong to. Cached after the
	* first successful lookup.
	*
	* @internal
	*/
	async getProjectId() {
		if (!this.projectId) this.projectId = (await this.api.projects.get()).data[0].id;
		return this.projectId;
	}
};
//#endregion
export { uploadMedia as _, LangfuseAPIClient as a, LogLevel as c, getEnv as d, getGlobalLogger as f, serializeMetadataValue as g, propagateAttributes as h, LANGFUSE_TRACER_NAME as i, base64Encode as l, getPropagatedAttributesFromContext as m, startActiveObservation as n, LangfuseMedia as o, getLangfuseTraceIdFromBaggage as p, LANGFUSE_SDK_VERSION as r, LangfuseOtelSpanAttributes as s, LangfuseClient as t, base64ToBytes as u, require_src as v };
