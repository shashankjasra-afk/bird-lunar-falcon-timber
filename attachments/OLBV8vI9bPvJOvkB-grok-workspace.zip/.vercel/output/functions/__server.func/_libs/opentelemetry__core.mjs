import { u as require_src } from "./@langfuse/otel+[...].mjs";
//#region node_modules/@opentelemetry/core/build/esm/version.js
var VERSION = "2.2.0";
//#endregion
//#region node_modules/@opentelemetry/core/build/esm/semconv.js
var import_src = require_src();
/**
* The name of the runtime of this process.
*
* @example OpenJDK Runtime Environment
*
* @experimental This attribute is experimental and is subject to breaking changes in minor releases of `@opentelemetry/semantic-conventions`.
*/
var ATTR_PROCESS_RUNTIME_NAME = "process.runtime.name";
//#endregion
//#region node_modules/@opentelemetry/core/build/esm/platform/node/sdk-info.js
/** Constants describing the SDK in use */
var SDK_INFO = {
	[import_src.ATTR_TELEMETRY_SDK_NAME]: "opentelemetry",
	[ATTR_PROCESS_RUNTIME_NAME]: "node",
	[import_src.ATTR_TELEMETRY_SDK_LANGUAGE]: import_src.TELEMETRY_SDK_LANGUAGE_VALUE_NODEJS,
	[import_src.ATTR_TELEMETRY_SDK_VERSION]: VERSION
};
//#endregion
export { SDK_INFO as t };
